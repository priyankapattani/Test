//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : KG_Info.aspx.cs
//
// Description  : Einstiegsmaske Anzeige Einsatzberichte, Reiseabrechnung,
//                Mitarbeiterliste des Genehmigers
//
//=============== V1.0.0049 ===============================================
//
// Date         : 08.September 2009
// Author       : Joldic Dzevad
// Defect#      : BAF 530023 
//                BERMON hinzugef�gt
//
//=============== V1.0.0037 ===============================================
//
// Date         : 13.Februar 2008
// Author       : Wolfgang Patrman
// Defect#      : 5821, 5829
//                select Statement zur Darstellung
//                des Link-Buttons 'Reisen' korr.
//
//=============== V1.0.0037 ===============================================
//
// Date         : 15.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
// Date         : 10.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5716
//                Zuletzt eingestellte Werte f�r Berichtsmonat, Status und
//                Seite in der Session merken
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//=============== V1.0.0034 ===============================================
//
// Date         : 30.August 2007
// Author       : Adam Kiefer
// Defect#      : 5416
//                Anzeige Kopfdaten
//
//=============== V1.0.0029 ===============================================
//
// Date         : 19.Juli 2007
// Author       : WP
// Defect#      : 5224
//                Ausgabe einer Fehlermeldung, wenn Personalnummer = null
//
//=============== 1.0.0028 ===============================================
//
// Date         : 24.Mai 2007
// Author       : Adam Kiefer
// Defect#      : 4121
//                Neues Login-Konzept
//
//=============== V1.0.0022 ===============================================
//
// Date         : 20.Februar 2007
// Author       : WP
// Defect#      : 4655
//                Neuerstellung Anzeige EB und RA
//
// Defect#      : 4683
//                Selektiertes Berichtsmonat und Status Mitarbeiter merken 
//
//=========================================================================

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.Pdf;
using TapMontage.dbObjects;
using TapMontage.Misc;
using System.Windows.Forms;

public partial class Genehmigung_KG_Info : System.Web.UI.Page
{
    dbBearbeiter Bearbeiter;
    string Argument = "";

    protected void Page_LoadComplete(object sender, EventArgs e)
    {
        // Beginn #5416 - Anzeige Kopfdaten
        /* Kopfdaten einstellen */
        try
        {
            if (Session["headData"] == null)
                Session.Add("headData", "");

            Session["headData"] = "<span style=\"font-size: 20px;\">Anzeige - Auswahl Mitarbeiter</span>";
        }
        catch
        {/* Nicht behandelt! */}
        // Ende #5416

        if (!IsPostBack)
        {
            // Beginn CR 4683: gespeicherte Sessionvariablen auslesen,
            // um die MAUebersicht mit der vorherigen Selektion aufzubauen
            if (Session["AnzBerichtsmonat"] != null)
            {
                DDLMonat.DDL.SelectedIndex = (int)Session["AnzBerichtsmonat"];
            }
            if (Session["MAStatus"] != null)
            {
                DDLMAStatus.DDL.SelectedIndex = (int)Session["MAStatus"];
            }
            // Ende CR 4683
            phMAListe.Controls.Clear();
            phMAListe.Controls.Add(MAUebersicht());

            // Beginn CR 4683: selektierter Index in Sessionvariablen merken
            Session["MAStatus"] = DDLMAStatus.DDL.SelectedIndex;
            Session["AnzBerichtsmonat"] = DDLMonat.DDL.SelectedIndex;
            // Ende CR 4683
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        // Beginn Defect 5716, Session Variablen nicht l�schen
        // Beginn CR 4683: Sessionvariable AnzBerichtsmonat und MAStatus nicht l�schen
        // Beginn #4121 - Neues Login-Konzept
        // SessionMgr.ClearSession(Page, new string[] { "Bearbeiter", "AnzBerichtsmonat", "MAStatus", "loginName", "loginAccount", "loginRole" }); Defect 5716, Code �berfl�ssig
        // Ende #4121
        // SessionMgr.ClearSession(Page, new string[] { "Bearbeiter" });
        // Ende CR 4683
        // Ende Defect 5716

        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        Session["ChangeSAPTrip"] = false;
        if (IsPostBack)
        {
            phMAListe.Controls.Clear();
            phMAListe.Controls.Add(MAUebersicht());

            // Beginn CR 4683: selektierter Index in Sessionvariablen merken
            Session["MAStatus"] = DDLMAStatus.DDL.SelectedIndex;
            Session["AnzBerichtsmonat"] = DDLMonat.DDL.SelectedIndex;
            // Ende CR 4683
        }
    }

    // Klasse zur Darstellung einer Zeile in MAUebersicht
    private class MAUebersichtZeile
    {
        public int Perskey;
        public string Nachname;
        public string Vorname;
        public string Persnr;
        public double NormStunden = 0;
        public double SummeStunden = 0;
        public double UE50 = 0;
        public double UE100 = 0;
        public string Firmenkennung;
        public string Mandant;
        public int CountEB;
        public ArrayList KtobjListe = new ArrayList();
        public ArrayList ATage = new ArrayList();

        public MAUebersichtZeile(int perskey, string nachname, string vorname, string persnr, string firmenkennung, string mandant, int countEB)
        {
            Perskey = perskey;
            Nachname = nachname;
            Vorname = vorname;
            Persnr = persnr;
            Firmenkennung = firmenkennung;
            Mandant = mandant;
            CountEB = countEB;
        }
    }

    // Erzeugung der Uebersichtsmaske mit allen Mitarbeitern
    private Table MAUebersicht()
    {
        //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "001210" + "MAUebersicht(): Start", null);

        if (DDLMonat.DDL.SelectedIndex >= 0 &&
            DDLMAStatus.DDL.SelectedIndex >= 0)
        {
            xxID = 0;

            tabListe.Rows.Clear();

            tabListe.Width = Unit.Percentage(100);
            TableRow HeaderRow = new TableRow();
            TableCell c1 = new TableCell();
            c1.CssClass = "TabHeader";
            c1.Text = "Name";
            c1.Font.Bold = true;
            c1.HorizontalAlign = HorizontalAlign.Center;
            TableCell c2 = new TableCell();
            c2.Text = "Vorname";
            c2.Font.Bold = true;
            c2.HorizontalAlign = HorizontalAlign.Center;
            c2.CssClass = "TabHeader";
            TableCell c3 = new TableCell();
            c3.Text = "Personalnummer";
            c3.Font.Bold = true;
            c3.HorizontalAlign = HorizontalAlign.Center;
            c3.CssClass = "TabHeader";
            TableCell c4 = new TableCell();
            c4.Text = "Einsatzberichte";
            c4.Font.Bold = true;
            c4.HorizontalAlign = HorizontalAlign.Center;
            c4.CssClass = "TabHeader";
            TableCell c5 = new TableCell();
            c5.Text = "Reisen";
            c5.Font.Bold = true;
            c5.HorizontalAlign = HorizontalAlign.Center;
            c5.CssClass = "TabHeader";

            HeaderRow.Cells.Add(c1);
            HeaderRow.Cells.Add(c2);
            HeaderRow.Cells.Add(c3);
            HeaderRow.Cells.Add(c4);
            HeaderRow.Cells.Add(c5);

            tabListe.Rows.Add(HeaderRow);
            LinkButton lnkbtn;

            ArrayList AllMA = new ArrayList(); // enthaelt alle Mitarbiter

            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    string lMAStatus = DDLMAStatus.DDL.SelectedValue;

                    DateTime d;
                    string argDate = "";
                    DateTime lbermon = Convert.ToDateTime("01-01-1900");

                    d = Convert.ToDateTime(DDLMonat.DDL.SelectedValue);
                    argDate = Convert.ToString(d.Year * 100 + d.Month);
                    lbermon = Convert.ToDateTime("01-" + argDate.Substring(argDate.IndexOf("-") + 5, 2) + "-" + argDate.Substring(argDate.IndexOf("-") + 1, 4));

                    // Selektieren aller Mitarbeiter des angemeldeten Genehmigers
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    //using (SqlCommand cmd = new SqlCommand("SELECT b.perskey, b.persnr, b.mandant, b.vorname, b.nachname, b.status, " +
                    //                                "(SELECT COUNT(e.ebstat) " +
                    //                                " FROM einsber e " + Config.Nolock +
                    //                                " WHERE e.perskey = b.perskey " +
                    //                                " AND e.bermon = @BERMON " +
                    //                                " AND e.ebstat = 40 " +
                    //                                " AND e.projid IS NOT NULL) as CountEB, " +
                    //                                "(SELECT COUNT(r.rastat) " +
                    //                                " FROM rakopf r " + Config.Nolock + ", einsber e " + Config.Nolock +
                    //                                " WHERE r.abrnr = e.ebid " +
                    //                                " AND e.perskey = b.perskey " +
                    //                                " AND e.bermon = @BERMON " +
                    //                                " AND r.rastat >= 40 " +
                    //                                " AND e.projid IS NOT NULL) as CountRA " +
                    //                                " FROM bearbeit b " + Config.Nolock + ", bearborg bo " + Config.Nolock +
                    //                                " WHERE b.perskey = bo.perskey " +
                    //                                " AND orgkz ='V' " +
                    //                                " AND perskey_org = @PERSKEY " +
                    //                                " AND status IN (" + lMAStatus + ") " +
                    //                                " ORDER BY nachname, vorname", cnx)) // Defect 5436, using eingef�hrt

                    // Defect 5821, 5829 select korr.,
                    // die Anh�ngigkeit der Tabelle rakopf zu einsber wurde entfernt
                    using (SqlCommand cmd = new SqlCommand(
                           "SELECT b.perskey, b.persnr, b.mandant, b.vorname, b.nachname, b.status, " +
                           "(SELECT COUNT(e.ebstat) " +
                           " FROM einsber e " + Config.Nolock +
                           " WHERE e.perskey = b.perskey " +
                           " AND e.bermon = @BERMON " +
                           " AND e.ebstat = 40) as CountEB, " +
                           "(SELECT COUNT(r.rastat) " +
                           " FROM rakopf r " + Config.Nolock + //", razeile rz " + Config.Nolock +
                           " WHERE r.perskey = b.perskey " +
                           //" AND r.raid = rz.raid " +
                           //" AND DATEPART(year,rz.dat ) = @YEAR " +
                           //" AND DATEPART(month, rz.dat) = @MONTH " +
                           " AND r.bermon = @BERMON " + // BAF 530023 BERMON hinzugef�gt
                           " AND r.rastat >= 40) as CountRA " +
                           " FROM bearbeit b " + Config.Nolock + ", bearborg bo " + Config.Nolock +
                           " WHERE b.perskey = bo.perskey " +
                           " AND orgkz = 'V' " +
                           " AND perskey_org = @PERSKEY " +
                           " AND status IN (@MASTATUS) " +
                           " ORDER BY nachname, vorname", cnx))
                    {
                        //cmd.Parameters.Add(Bearbeiter.Params.PERSKEY);
                        cmd.Parameters.Add(new SqlParameter("@PERSKEY", Bearbeiter.Params.PERSKEY.Value));
                        cmd.Parameters.Add(new SqlParameter("@BERMON", lbermon));
                        //cmd.Parameters.Add(new SqlParameter("@YEAR", lbermon.Year)); // Defect 5821, 5829
                        //cmd.Parameters.Add(new SqlParameter("@MONTH", lbermon.Month)); // Defect 5821, 5829
                        cmd.Parameters.Add(new SqlParameter("@MASTATUS", lMAStatus)); // Defect 5821, 5829

                        //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005070" + "ComputeStd(): " + cmd.CommandText, null);

                        SqlDataReader rd = cmd.ExecuteReader();
                        //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005071" + "ComputeStd(): ", null);
                        cmd.Parameters.Clear();

                        int iCnt = 0;
                        lblError.Text = ""; // Defect 5224
                        lblError.Visible = false; // Defect 5224

                        while (rd.Read())
                        {
                            iCnt++;
                            // Beginn Defect 5224:
                            // MA mit persnr = null nicht anzeigen
                            if (rd.IsDBNull(1))
                            {
                                lblError.Text = "Der Mitarbeiter " +
                                                rd.GetString(3) + " " + rd.GetString(4) +
                                                " kann nicht angezeigt werden, da seine Personalnummer nicht versorgt ist.";
                                lblError.Visible = true;
                                continue;
                            }
                            // Ende Defect 5224

                            // In das Array wird jeder Mitarbeiter aufgenommnen
                            MAUebersichtZeile MAZeile = new MAUebersichtZeile(rd.GetInt32(0), rd.GetString(4), rd.GetString(3), rd.GetString(1), Bearbeiter.Firmenkennung, rd.GetString(2), rd.GetInt32(6));

                            AllMA.Add(MAZeile);

                            Argument = rd.GetInt32(0) + "-" + argDate; // im Format perskey-yyyymm

                            if (rd.GetInt32(6) > 0)
                            {
                                // Einsatzberichte vorhanden
                                Argument = Argument + "-" + "true";
                            }
                            else
                            {
                                Argument = Argument + "-" + "false";
                            }

                            if (rd.GetInt32(7) > 0)
                            {
                                // Reiseabrechnung vorhanden
                                Argument = Argument + "-" + "true";
                            }
                            else
                            {
                                Argument = Argument + "-" + "false";
                            }

                            TableRow tr = new TableRow();
                            TableCell d1 = new TableCell();
                            d1.Text = rd.GetString(4); // Nachname Mitarbeiter
                            d1.HorizontalAlign = HorizontalAlign.Center;
                            d1.CssClass = "TabNewDay";
                            tr.Cells.Add(d1);

                            TableCell d2 = new TableCell();
                            d2.Text = rd.GetString(3); // Vorname Mitarbeiter
                            d2.HorizontalAlign = HorizontalAlign.Center;
                            d2.CssClass = "TabNewDay";
                            tr.Cells.Add(d2);

                            TableCell d3 = new TableCell();
                            d3.Text = rd.GetString(1); // Persnr Mitarbeiter;
                            d3.HorizontalAlign = HorizontalAlign.Center;
                            d3.CssClass = "TabNewDay";
                            tr.Cells.Add(d3);

                            TableCell d4 = new TableCell();

                            // Button nur erzeugen, wenn es Einsatzberichte gibt
                            if (rd.GetInt32(6) > 0)
                            {
                                d4.Enabled = true;
                            }
                            else
                            {
                                d4.Enabled = false;
                            }

                            lnkbtn = NewTaskButton("Einsatzberichte", "EBAnzeige", Argument, "Klicken Sie hier um die Einsatzberichte anzusehen.", TaskButton_Click);
                            d4.Controls.Add(lnkbtn);
                            d4.HorizontalAlign = HorizontalAlign.Center;
                            d4.CssClass = "TabNewDay";
                            tr.Cells.Add(d4);

                            TableCell d5 = new TableCell();

                            // Button nur erzeugen, wenn es Reiseabrechnungen gibt
                            if (rd.GetInt32(7) > 0)
                            {
                                d5.Enabled = true;
                            }
                            else
                            {
                                d5.Enabled = false;
                            }

                            lnkbtn = NewTaskButton("Reisen", "RAAnzeige", Argument, "Klicken Sie hier um die Reiseabrechnung anzusehen.", TaskButton_Click);
                            d5.Controls.Add(lnkbtn);
                            d5.HorizontalAlign = HorizontalAlign.Center;
                            d5.CssClass = "TabNewDay";
                            tr.Cells.Add(d5);

                            if (rd.GetInt16(5) == 40)
                            {
                                // Inaktive Mitarbeiter auf Hellgrau setzen
                                tr.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(227)),
                                                                             ((System.Byte)(227)),
                                                                             ((System.Byte)(227)));
                            }
                            tabListe.Rows.Add(tr);
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
        }
        return tabListe;
    }

    // Link Button erzeugen
    private LinkButton NewTaskButton(string Text, string Command, string Argument, string ToolTip, CommandEventHandler TaskButtonClick_EventHandler)
    {
        LinkButton btn = new LinkButton();
        btn.ID = nid();
        btn.SkinID = "";
        btn.Width = Unit.Percentage(100);
        btn.Text = Text;
        btn.CommandName = Command;
        btn.CommandArgument = Argument;
        btn.ToolTip = ToolTip;
        btn.Command += new CommandEventHandler(TaskButtonClick_EventHandler);
        return btn;
    }

    public int xxID = 0;
    public string nid()
    {
        xxID++;
        return "LnkBTN->" + xxID.ToString();
    }

    // Button um Einsatzberichte, Reiseabrechnung aufzublenden
    void TaskButton_Click(object sender, CommandEventArgs e)
    {
        string cmd = (string)e.CommandName;
        string arg = (string)e.CommandArgument;
        int iPkey;
        dbBearbeiter Monteur;
        int d;
        dbKG_Monat kgmonat;
        DateTime bermon = Convert.ToDateTime("01-" + arg.Substring(arg.IndexOf("-") + 5, 2) + "-" + arg.Substring(arg.IndexOf("-") + 1, 4));

        ArrayList argList = new ArrayList();

        for (int argi = 0, cnt = 0; argi < arg.Length; cnt++)
        {
            int x = arg.IndexOf("-", argi);
            if (x == -1)
            {
                x = arg.Length - argi;
            }
            else
            {
                x = x - argi;
            }
            argList.Add(arg.Substring(argi, x));
            argi += x + 1;
        }

        iPkey = Convert.ToInt32(argList[0]);
        d = Convert.ToInt32(argList[1]);
        string EBvorh = (string)argList[2];
        string RAvorh = (string)argList[3];

        switch (cmd)
        {
            case "EBAnzeige":
                // EB mit ebstat = 40 vorhanden
                Monteur = new dbBearbeiter(iPkey);
                Monteur.Select(false);
                Monteur.BerichtsMonat = d;
                kgmonat = new dbKG_Monat(Monteur, d);
                kgmonat.Genehmiger = Bearbeiter.BearbInRole;
                Session["KGMonat"] = kgmonat;
                Session["EBvorh"] = EBvorh;
                Session["RAvorh"] = RAvorh;
                Response.Redirect("~/Genehmigung/KG_InfoEB.aspx");
                break;
            case "RAAnzeige":
                Monteur = new dbBearbeiter(iPkey);
                Monteur.Select(false);
                Monteur.BerichtsMonat = d;
                kgmonat = new dbKG_Monat(Monteur, d);
                kgmonat.Genehmiger = Bearbeiter.BearbInRole;
                Session["KGMonat"] = kgmonat;
                Session["EBvorh"] = EBvorh;
                Session["RAvorh"] = RAvorh;
                Response.Redirect("~/Genehmigung/KG_InfoRA.aspx");
                break;
            default:
                Exception ex = new Exception("Command not recognised: " + cmd);
                throw ex;
        }
    }
}
