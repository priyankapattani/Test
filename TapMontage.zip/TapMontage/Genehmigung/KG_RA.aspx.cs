//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : KG_RA.aspx.cs
//
// Description  : Kontrolle & Genehmigung Reiseabrechnung
//
//=============== V1.2.0006 ===============================================
//
// Date         : 16.August 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530042
//                Verwenden von AZMKalenderTage statt st�ndige AZM abfragen
//                
//=============== V1.0.0050 ===============================================
//
// Date         : 16.September 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500059
//                Anbindung an die neue SAP HR Schnittstelle
//
//=============== V1.0.0044 ===============================================
//
// Date         : 03.September 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-34
//                Reisen nach manuellen �ndern von RNG aktualisieren
//
//=============== V1.0.0041 ===============================================
// Date         : 28.Mai 2008
// Author       : Frantisek Sabol
// Defect#      : 6012
//                �nderung der Bereitstellung
////
// Date         : 25.Mai 2008
// Author       : Joldic Dzevad
// Defect#      : 6060
//                KFMBemerkungsfeld angedrucken
//

// Date         : 19.Mai 2008
// Author       : Joldic Dzevad
// Defect#      : 6014
//                Bemerkungsfeld wird mehrmals angedruckt
//
//=============== V1.0.0038 ===============================================
//
// Date         : 22.Februar 2008
// Author       : Joldic Dzevad
// Defect#      : 5822
//                Exceptions verhindern falls FindeReise einen nullpointer
//                zur�ckliefert.
//
// Date         : 22.Februar 2008
// Author       : Porazik Juraj
// Defect#      : 5824
//                Fehlermeldung "Reise beginnt mit Standortwechsel"
//
//=============== V1.0.0037 ===============================================
//
// Date         : 19.J�nner 2008
// Author       : Krizek Norbert
// Defect#      : 5702
//                �nderung der Kontoinformation durch Benutzer -> falsche Nr. gespeicher
//
//=============== V1.0.0036 ===============================================
//
// Date         : 3.Dezember 2007
// Author       : Georg Nebehay
// Defect#      : 5673, 5677
//                Automatische ID-Generierung von RNG-Checkbox-IDs auf selbst generierte umgestellt.
//
// Date         : 3.Dezember 2007
// Author       : Georg Nebehay
// Defect#      : 5673, 5677
//                Automatische ID-Generierung von RNG-Checkbox-IDs auf selbst generierte umgestellt.
//
//=============== V1.0.0035 ===============================================
//
// Date         : 26.November 2007
// Author       : Norbert Krizek
// Defect#      : 5390
//                keine unterbrechung der reduzierung bei eint�giger reise auf andere bs
//
//
// Date         : 06.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5589
//                Benutzerdaten im Kopf nicht mehrmals versorgen
//
//=============== V1.0.0034 ===============================================
//
// Date         : 23.Oktober 2007
// Author       : Wolfgang Patrman
// Defect#      : 5569
//                Anzeige Benutzerdaten im Kopf, wird im IE mit angedruckt
//
// Date         : 18.Oktober 2007
// Author       : Norbert Krizek
// Defect#      : 5338
//                Aenderung der Bereitstellung f�r mehr als eine Reise,
//                auch rng richtig mappen
//
// Date         : 18.Oktober 2007
// Author       : GN
// Defect#      : 5419
//                kontonummer auch r�ckschreiben bei maskenaenderung
//
//=============== V1.0.0033 ===============================================
//
// Date         : 30.August 2007
// Author       : Adam Kiefer
// Defect#      : 5416
//                Anzeige Kopfdaten
//
//=============== V1.0.0032 ===============================================
//
// Date         : 22.August 2007
// Author       : Adam Kiefer
// Defect#      : 5198
//                negative Zeiten liefern keine Meldung in der Reiseabrechnung
//
// Date         : 2.August 2007
// Author       : NK
// Defect#      : 5308
//                T-Zeilen falsch an R�ckreisetag generiert (Reduzierung bei R�ckreise)
//                Neuberechnung nach erfassung einer reisezeile in einem reiseobjekt
//
//=============== V1.0.0029 ===============================================
//
// Date         : 16.Juli 2007
// Author       : Wolfgang Patrman
// Defect#      : 5198
//                �berpr�fung ob eingegebene Abfahrtszeit <= Ankunftszeit
//
// Date         : 7. Juni 2007
// Author       : NK
// Defect#      : 5243
// Modifikation von Reisen loesung der probleme:
// - Hinzuf�gen von Standortwechsel nicht m�glich
// - Entfernen von Standortwechsel bei �nderungen von  anderen Reisezeilen
// - L�schen der R�ckreise erzeugt keine T-Zeile
//
// Date         : 7. Juni 2007
// Author       : NK
// Defect#      : 5155
// Bei Teilabrechnungen sind die Beistellungen zu ber�cksichtigen.
// die initialisierung der T-Zeilen ist fix mit 0 (keine bereitstellung vorbelegt, anstatt 
// die werte von der letzten hinreise zu nehmen
// bei modifikationen bzw neuerfassungen von reisen muss der erfasste wert f�r die ganze reise ziehen
//
//--------------- V1.0.0028 ---------------------------------------------------
//
// Date         : 6.Juni 2007
// Author       : NK
// Defect#      : 4972
//
// Reisegenerierung bei Urlaub/ZA:
// Derzeit wird bei einer Unterbrechung einer Reise durch Urlaub/Za nicht automatisch
// eine Unterbrechung generiert.
// Dieser Umstand wurde im Zuge der Gespr�che zu 
//           Defect#  : 4971 
//                      Reisegenerierung f�r Abbildung reduziertes N�chtigungsgeld Inland betrachtet und 
//                      deshalb in einer beschreibung zusammengefasst 
//
//--------------- V1.0.0027 ---------------------------------------------------
//
// Date         : 16.Mai 2007
// Author       : GN
// Defect#      : 4931, 4932
//                Die beiden neuen Felder Schwergep�ck und Anzahl Mitfahrer wurden in der Oberfl�che eingebaut.
//
//--------------- V1.0.0024 ---------------------------------------------------
//
// Date         : 17.April 2007
// Author       : CL
// Defect#      : 4728
//                Zus�tzliche Anzeige der Personalnummer im Seitenkopf
//
//--------------- V1.0.0024 ---------------------------------------------------
//
// Date         : 10.April 2007
// Author       : Georg Nebehay
// Defect#      : 4933
//                Bei Teilabrechnungen wird keine Zeit mehr angezeigt.
//
//--------------- V1.0.0023 ---------------------------------------------------
//
// Date         : 26.M�rz 2007
// Author       : Georg Nebehay
// Defect#      : 4782
//
// Die Abfahrts/Ankunftszeiten von Hin/R�ckreisen wurden immer �berschrieben.
// Dieses Problem wurde durch Zwischenspeichern behoben.
//
//
// Date         : 8.M�rz 2007
// Author       : Georg Nebehay
// Defect#      : 4698_4722_4764_4766_4778
// 
// Es wurde eine Zeile eingef�gt, die verhindert, dass die letzte Reise aus dem
// Vormonat nicht �berpr�ft wird.
//
//--------------- V1.0.0022 ---------------------------------------------------
//
// Date         : 12.Februar 2007
// Author       : Georg Nebehay
// Defect#      : 4623
//
// L�schen der Teilabrechnung am Monatsanfang verhindert, weil sie
// verpflichtend ist, wenn sie eingetragen wurde.
//
//
// Date         : 12.Februar 2007
// Author       : Georg Nebehay
// Defect#      : ????
//                Beim Hinzuf�gen einer R�ckreise am Monatsanfang kam diese vor der Teilabrechnung zu liegen.
//
//--------------- V1.0.0020 ---------------------------------------------------
//
// Date         : 30.J�nner 2007
// Author       : Wolfgang Patrman
// Defect#      : 4468
//                Fehlermeldung korrigiert
//
//--------------- V1.0.0005 ---------------------------------------------------
//
// Date         : 08.November 2006
// Author       : Georg Nebehay
// Defect#      : 3595
//                Anzeigetext in den Bereitstellungen in Reiseabrechnung falsch  
//
//-----------------------------------------------------------------------------

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using System.Diagnostics;

public partial class Genehmigung_KG_RA : System.Web.UI.Page
{
    dbBearbeiter Bearbeiter;
    dbKG_Monat KGMonat;
    dbKG_ReiseZeile KGReiseZeile;
    DateTime timer = ParamVal.Date0;

    private int cb_count; //Membervariable zum Z�hlen der Checkboxen
    private bool computeSAP = false;

    //TAPM-34 - Page_PreRender f�hrt ComputeSAP so bald aktualisierung bet�tigt ist
    protected void Page_PreRender(object sender, EventArgs e)
    {
        Debug.WriteLine("KG_RA:Page_PreRender start at " + DateTime.Now.ToLongTimeString());
        try
        {
            computeSAP = (bool)Session["computeSAP"];
        }
        catch
        {
            computeSAP = false;
        }
        if (computeSAP)
        {
            phRabTab.Controls.RemoveAt(0);
            LabelError.Text = KGMonat.Rabrech.ComputeSAP(true, false, false);
            phRabTab.Controls.Add(RabTab());
            Session["computeSAP"] = false;
        }

        /*
        LabelTimer.Text = "Diese Seite ist in " + new TimeSpan(DateTime.Now.Ticks - timer.Ticks).Seconds + " Sekunden aufgebaut";
        DateTime dtbeginn = (DateTime)Session["GenehmigungsDauer"];
        LabelGesamtDauer.Text = "Gesamtdauer bis jetzt ist " + new TimeSpan(DateTime.Now.Ticks - dtbeginn.Ticks).TotalSeconds + " Sekunden.";
        Debug.WriteLine("KG_RA:Page_PreRender end at " + DateTime.Now.ToLongTimeString());
        */
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        Debug.WriteLine("KG_RA:PageLoad Beginn at " + DateTime.Now.ToLongTimeString());
        timer = DateTime.Now;
        cb_count = 0; //Beim Laden der Seite wird der Checkboxcount zur�ckgesetzt
        LabelError.Text = "";
        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        KGMonat = (dbKG_Monat)Session["KGMonat"];
        KGReiseZeile = (dbKG_ReiseZeile)Session["KGReiseZeile"];
        // Beginn Defect # 4728: Zus�tzliche Anzeige der Personalnummer
        //Label2.Text = KGMonat.Monteur.Params.VORNAME.Value.ToString() + " " + KGMonat.Monteur.Params.NACHNAME.Value.ToString() + " (" + KGMonat.Monteur.Params.PERSNR.Value.ToString() + ") " + KGMonat.MonatText + " " + KGMonat.MinDatum.Year.ToString();

        // Beginn #5416 - Anzeige Kopfdaten
        /* Kopfdaten einstellen */
        try
        {
            if (Session["headData"] == null)
                Session.Add("headData", "");

            Session["headData"] = "<span style=\"font-size: 20px;\">Kontrolle & Genehmigung - Reiseabrechnung</span><br /><span style=\"font-size: 12px;\">";
            Session["headData"] += KGMonat.Monteur.Params.VORNAME.Value.ToString() + " " + KGMonat.Monteur.Params.NACHNAME.Value.ToString() + " (" + KGMonat.Monteur.Params.PERSNR.Value.ToString() + ") " + KGMonat.MonatText + " " + KGMonat.MinDatum.Year.ToString();
            // Defect 5569, Mitarbeiterinformationen anzeigen
            lbHeadInfo.Text = KGMonat.Monteur.Params.VORNAME.Value.ToString() + " " + KGMonat.Monteur.Params.NACHNAME.Value.ToString() + " (" + KGMonat.Monteur.Params.PERSNR.Value.ToString() + ") " + KGMonat.MonatText + " " + KGMonat.MinDatum.Year.ToString(); // Defect 5589
        }
        catch
        {/* Nicht behandelt! */}
        // Ende #5416
        bool fromAZM = false;
        try
        {
            fromAZM = (bool)Session["fromAZM"];
        }
        catch
        { }
        //CR 4931,4932 beim �ndern des Verkehrsmittel wird evtl Schwergp, Mitfahrt angezeigt
        //GN 14.5.2007
        ddlVm.DDL.SelectedIndexChanged += new EventHandler(VM_DDL_SelectedIndexChanged);
        // Ende Defect # 4728

        //BAN 500059 Beginn
        if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
        {
            BtnNext.Text = "ok, >> weiter zur SAP Reisen�bersicht";
            dbSapReise sapReisen = new dbSapReise(Convert.ToInt32(KGMonat.Monteur.Params.PERSKEY.Value), KGMonat.MinDatum, KGMonat.Monteur.Params.MANDANT.Value.ToString());
            if (sapReisen.GetTapReisen().Count > 0)
            {
                Session["ChangeSAPTrip"] = true;
                Session["KGMonat"] = KGMonat;
                Debug.WriteLine("KG_RA:PageLoad Redirect to KG_SAP_RA at " + DateTime.Now.ToLongTimeString());
                Response.Redirect("~/Genehmigung/KG_SAP_RA.aspx");
            }
        }
        //BAN 500059 Ende

        if (!Page.IsPostBack)
        {
            if (!fromAZM) //TAPM-34 - kein neues select wenn man von AZM Maske zur�ck wechselt
                LabelError.Text = KGMonat.Rabrech.Select(true, KGMonat.Monat); //returns immediately if allready initialized  // defect 5390 erro text versorgen
            ChkChangeVormonat.Checked = KGMonat.Rabrech.VormonatVer�ndert;
            ChkChangeVormonat.Visible = KGMonat.Rabrech.VormonatVer�ndert;
            ddlAuftrag = KGMonat.Rabrech.ddlAuftr�ge(ddlAuftrag, "");
            //hier fehlt das Angebot f�r die Bereinigung von Konflikten bei monatlicher Heimreise
            Session["KGMonat"] = KGMonat;
            KGReiseZeile = null;
            Session["KGReiseZeile"] = KGReiseZeile;

        }
        Session["fromAZM"] = fromAZM = false;
        phRabTab.Controls.Add(RabTab());
        phBemerkung.Controls.Add(BemerkungfuerGenehmiger());
        phKfmBemerkung.Controls.Add(KfmBemerkungfuerGenehmiger());
        enableEdit();
        Debug.WriteLine("KG_RA:PageLoad Ende at " + DateTime.Now.ToLongTimeString());
    }

    //Defect 4931,4932 GN 14.5.2007
    //Handler f�r �ndern der Verkehrsmittelliste
    void VM_DDL_SelectedIndexChanged(object sender, EventArgs e)
    {
        SchwergpCheckBox.Visible = MitfahrerDDL.Visible = VMWithExtendedOptionsSelected();
        // Beginn #4040, 4370
        SetFocus(BtnSave);
        // Ende #4040, 4370
    }

    //Defect 4931, 4932
    //GN 16.5.2007
    //Diese Funktion gibt zur�ck, ob aktuell ein Verkehrsmittel ausgew�hlt ist, bei dem Schwergep�ck oder Mitfahrt angegeben werden k�nnen
    private bool VMWithExtendedOptionsSelected()
    {
        string selectedVM = ddlVm.DDL.SelectedValue;
        bool isSpecial = false;

        //Falls kein Configeintrag existiert, gibt es auch keien erweiterte Auswahl
        try
        {
            string vmsconfig = ConfigurationManager.AppSettings["SchwergepackMitfahrtVMs"];
            string[] vms = vmsconfig.Split(' ');

            foreach (string s in vms)
            {
                if (s == selectedVM) isSpecial = true;
            }
        }
        catch (Exception) { }
        return isSpecial;

    }

    //Defect 4931, 4932
    //GN 16.5.2007
    //Diese Funktion zeigt Schwergep�ck und Mitfahrt an, wenn ein passendes VM ausgew�hlt wurde

    private void DisplayExtendedVMOptions()
    {
        //Schwergep�ckeintrag wird von der Reisezeile �bernommen
        SchwergpCheckBox.Checked = (string)KGReiseZeile.Zeile.Params.SCHWERGP.Value == "S";
        SchwergpCheckBox.Visible = VMWithExtendedOptionsSelected();

        //Ebenso Mitfahreranzahl, sollte beim ToString etwas schiefgehen, wird der Defaultvalue beibehalten
        try
        {
            MitfahrerDDL.DDL.SelectedValue = KGReiseZeile.Zeile.Params.MITFAHRER.Value.ToString();
        }
        catch (Exception) { }
        MitfahrerDDL.Visible = VMWithExtendedOptionsSelected();

    }

    private void MapData()
    {
        foreach (Control c in Panel1.Controls)
        {
            if ((c as TapWebTextBox) != null)
            {
                TapWebTextBox tb = (TapWebTextBox)c;
                foreach (SqlParameter s in KGReiseZeile.Zeile.Params.List)
                    if (tb.DataField == s.ParameterName)
                    {
                        if (((s.ParameterName == "@AB") | (s.ParameterName == "@AN")) && (tb.TextBoxType == TapWebTextBox.TapWebTextBoxType.Time))
                            tb.TextBoxText = Convert.ToDateTime(s.Value).ToShortTimeString();
                        else
                        {
                            tb.TextBoxText = ParamVal.GetParameter(s);
                            //BAN 500059 - Datum Initialisiren
                            if (tb.TextBoxType == TapWebTextBox.TapWebTextBoxType.Date)
                            {
                                tb.SelectedDate = tb.TextBoxText.ToString();
                            }

                        }
                    }
            }
            if ((c as TapWebDropDownList) != null)
            {
                TapWebDropDownList dl = (TapWebDropDownList)c;
                foreach (SqlParameter s in KGReiseZeile.Zeile.Params.List)
                    if (dl.DDLDataField == s.ParameterName)
                        dl.DDLSelectedValue = ParamVal.GetParameter(s);
            }
        }
        if (KGReiseZeile.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) rblTyp.SelectedIndex = 0;
        if (KGReiseZeile.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt) rblTyp.SelectedIndex = 1;
        if (KGReiseZeile.Typ == dbKG_ReiseZeilenTyp.StandortWechsel) rblTyp.SelectedIndex = 2;
        if (KGReiseZeile.Typ == dbKG_ReiseZeilenTyp.WechselBereitstellung) rblTyp.SelectedIndex = 3;
        if (KGReiseZeile.Typ == dbKG_ReiseZeilenTyp.FahrtAmDienstort) rblTyp.SelectedIndex = 2; // F�r alte Datens�tze, 4 gibts ja nimmer.

        //CR 4931, 4932
        //GN 16.05.2007
        //�berpr�fung auf Verkehrsmittel eingebaut
        DisplayExtendedVMOptions();

        ddlAuftrag.Items.Clear();
        ddlAuftrag = KGMonat.Rabrech.ddlAuftr�ge(ddlAuftrag, KGReiseZeile.AuftragNr);
        btnCancel.Visible = true;
        BtnSave.Text = "�nderung Speichern";
        enableEdit();
    }

    private string SaveData()
    {
        foreach (Control c in Panel1.Controls)
        {
            if ((c as TapWebTextBox) != null)
            {
                TapWebTextBox tb = (TapWebTextBox)c;
                foreach (SqlParameter s in KGReiseZeile.Zeile.Params.List)
                {
                    if (tb.DataField == s.ParameterName)
                    {
                        if ((s.ParameterName == "@AB") | (s.ParameterName == "@AN"))
                        {
                            if (s.ParameterName == "@AB")
                            {
                                s.Value = Convert.ToDateTime(Convert.ToDateTime(tbDAb.TextBoxText).ToShortDateString() + " " + Convert.ToDateTime(tbAb.TextBoxText).ToShortTimeString());
                            }
                            else
                            {
                                s.Value = Convert.ToDateTime(Convert.ToDateTime(tbDAn.TextBoxText).ToShortDateString() + " " + Convert.ToDateTime(tbAn.TextBoxText).ToShortTimeString());
                            }
                        }
                        else
                            ParamVal.SetParameter(s, tb.TextBoxText);
                    }
                }
            }
            if ((c as TapWebDropDownList) != null)
            {
                TapWebDropDownList dl = (TapWebDropDownList)c;
                foreach (SqlParameter s in KGReiseZeile.Zeile.Params.List)
                {
                    if (dl.DDLDataField == s.ParameterName)
                        ParamVal.SetParameter(s, dl.DDLSelectedValue);
                    if (dl.DDLDataField == "@VERKEHRSMITTEL")
                    {
                        KGReiseZeile.Zeile.Params.VERKEHRSMITTEL.Value = dl.DDL.SelectedItem.Value;
                        KGReiseZeile.Zeile.Params.RAKZTXT.Value = dl.DDL.SelectedItem.ToString();
                    }
                    if (dl.DDLDataField == "@BEREITST")
                    {
                        KGReiseZeile.Zeile.Params.BEREITST.Value = dl.DDL.SelectedItem.Value;
                        KGReiseZeile.Zeile.Params.BSTXT.Value = dl.DDL.SelectedItem.ToString();
                    }
                }
            }
            if ((c as DropDownList) != null)
                if (((DropDownList)c).ID == "ddlAuftrag")
                {
                    KGReiseZeile.AuftragNr = ((DropDownList)c).SelectedValue;
                    KGReiseZeile.Zeile.Params.BESCHREIB.Value = KGReiseZeile.AuftragNr;   //defect 5419  kontonummer auch r�ckschreiben
                }
        }
        if (rblTyp.SelectedIndex == 0) KGReiseZeile.Typ = dbKG_ReiseZeilenTyp.Hinfahrt;
        if (rblTyp.SelectedIndex == 1) KGReiseZeile.Typ = dbKG_ReiseZeilenTyp.Rueckfahrt;
        if (rblTyp.SelectedIndex == 2) KGReiseZeile.Typ = dbKG_ReiseZeilenTyp.StandortWechsel;
        if (rblTyp.SelectedIndex == 3) KGReiseZeile.Typ = dbKG_ReiseZeilenTyp.WechselBereitstellung;
        //if (rblTyp.SelectedIndex == 4) KGReiseZeile.Typ = dbKG_ReiseZeilenTyp.FahrtAmDienstort; 4 gibts nicht

        //Defect 4931, 3932 GN 16.5.2007
        KGReiseZeile.Zeile.Params.SCHWERGP.Value = (SchwergpCheckBox.Visible && SchwergpCheckBox.Checked) ? "S" : "";
        KGReiseZeile.Zeile.Params.MITFAHRER.Value = (MitfahrerDDL.Visible) ? MitfahrerDDL.DDL.SelectedValue : "0";




        //TODO GN Defect suchen
        KGReiseZeile.ReiseTag = (DateTime)KGReiseZeile.Zeile.Params.AB.Value;
        //BAN 500059 ... falls Zeile im Vormonat begonnen ist, dann diese in BERMON anzeigen
        if (KGReiseZeile.ReiseTag.Month < KGMonat.MinDatum.Month)
        {
            KGReiseZeile.ReiseTag = KGMonat.MinDatum;
        }
        //BAN 500059 ... ENDE

        KGReiseZeile.AuftragNr = ddlAuftrag.SelectedValue;
        Session["KGReiseZeile"] = KGReiseZeile;
        // defect 4972 datenkonsistenz herstellen
        //KGMonat.Rabrech.ComputeSAP();

        // #6012 beginn
        if (Session["ber_ignore"] == null)
            Session.Add("ber_ignore", "");
        Session["ber_ignore"] = true;
        KGMonat.Rabrech.set_bereitstellung_von_reise(KGReiseZeile.Reise, KGReiseZeile.Zeile.Params.BEREITST.Value.ToString(), KGReiseZeile.Zeile.Params.BSTXT.Value.ToString(), KGReiseZeile.Zeile);  //defect 5155 gleichziehn der bereitstellungen
        // ende #6012
        KGMonat.Rabrech.PruefeReiseZeilen(KGReiseZeile.Reise, false); //defect 5155 hier nicht die bereitstellung aus den vorg�ngerreisen �bernehmen
        return (KGMonat.Rabrech.ComputeSAP(false, false, false));   //defect 5155 3 parameter  // defect 5390 fm retournieren
        //return (KGMonat.Rabrech.ComputeSAP(true, true, false));   //defect 5155 3 parameter  // defect 5390 fm retournieren
        //.DelReiseZeile(KGReiseZeile.Ab);
        //defect 4972 ende

    }

    protected void BtnPrev_Click(object sender, EventArgs e)
    {
        //save content
        Response.Redirect("~/Genehmigung/KG_Zeiten.aspx");
    }

    protected void BtnRefresh_Click(object sender, EventArgs e)
    {
        //TAPM-34 - Refrechbutton - only postback - den rest macht prerender
    }

    protected void BtnNext_Click(object sender, EventArgs e)
    {
        //TAPM-34 - wird mit prerender erledigt
        //progress1.Visible = true;
        // save content

        // defect 4972 beginn red-ng auslesen aus maske
        /*int i = 0, j = 0;
        Table Rabtab = (Table)phRabTab.Controls[0];
        dbArbTag tmpAT = null;
        DateTime dt = ParamVal.Date0;
        string dat = null;
        foreach (TableRow tr in Rabtab.Rows)
        {
            //tr.Cells[3].ID;
            i++;
            j=0;
            foreach (TableCell tc in tr.Cells)
            {
                CheckBox cb = null;
                Label l = null;
                j++;
                try
                {
                     cb = (CheckBox)tc.Controls[0];
                }
                catch
                {
                }
                try
                {
                     l = (Label)tc.Controls[0];
                }
                catch
                {
                }
                if (l != null)
                {
                    if (  (j == 1)&&(l.Visible==true) )
                    {
                        //datum
                        dt = ParamVal.Date0; 
                        dat = l.Text.ToString();  
                        int idx = dat.IndexOf(".");
                        int idx2 = dat.IndexOf(".", idx+1);
                        //string d = dat.Substring(idx, idx - idx2);
                        //dat = KGMonat.Monat.ToString()+ string.subtring dat
                        //string m = KGMonat.MonatText;
                        
                        try
                        {
                            string d = dat.Substring(idx+1, idx2 - idx - 1);
                            string y = KGMonat.Monat.ToString().Substring(0, 4);
                            string m = KGMonat.Monat.ToString().Substring(4, 2);
                            dt = Convert.ToDateTime(y + '.' + m + '.' + d);

                        }
                        catch
                        {
                        }


                        //foreach (dbMontBer MB in KGMonat.Rabrech.Monat.Monteur.MBerichte)  // defect 5338
                        for (int im = 0; im < KGMonat.Rabrech.Monat.Monteur.MBerichte.Count; im++)  // defect 5338
                        {
                            //foreach (dbArbTag AT in KGMonat.Rabrech.Monat.Monteur.MBerichte[i].Tage) // defect 5338
                            for (int jt = 0; jt < ((dbMontBer)KGMonat.Rabrech.Monat.Monteur.MBerichte[im]).Tage.Count; jt++) // defect 5338
                            {
                                //if (AT.TagesDatum == dt)  // defect 5338
                                if (((dbArbTag)((dbMontBer)KGMonat.Rabrech.Monat.Monteur.MBerichte[im]).Tage[jt]).TagesDatum == dt) // defect 5338 
                                {
                                    tmpAT = ((dbArbTag)((dbMontBer)KGMonat.Rabrech.Monat.Monteur.MBerichte[im]).Tage[jt]);  // defect 5338 pointerzuweisung
                                }
                            }
                        }
                         
                    }
                }
                if (cb != null)
                {
                    if (cb.Checked == true)
                    {
                        tmpAT.RNG = true;
                    }
                    else if (cb.Visible == true)
                    {
                        tmpAT.RNG = false;
                    }
                    else
                    {
                        //tmpAT.RNG = false;
                    }


                }
            }
            //TableCell
            //tr.Cells[2].ID
            //if ((tr.Cells[0].ID != null) && (tr.Cells[0].ID != ""))
            // Beginn Defect # 4941: Check return value
            //{
            //    if (!ReadLine(tr))
            //    {
            //        blnValidTimestamps = false;
            //    }
            //}
        }
        */
        LabelError.Text = KGMonat.Rabrech.ComputeSAP(true, false, false);  //defect 4972
        if (LabelError.Text == "")
        {
            Session["KGMonat"] = KGMonat;
            //BAN 500059 Beginn
            if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
            {
                foreach (dbKG_Reise r in KGMonat.Rabrech.Reisen)
                {
                    r.Kopf.RaStat = dbRaKopf.RaStati.InArbeit;
                    r.Kopf.Save();
                }
                Session["SendTripsToSAP"] = true;
                Session["ChangeSAPTrip"] = true;
                Session["KGMonat"] = KGMonat;
                Response.Redirect("~/Genehmigung/KG_SAP_RA.aspx");
            }
            else
                Response.Redirect("~/Genehmigung/KG_AZM.aspx");
            //BAN 500059 Ende
        }
        SetFocus((Control)sender);
    }

    private class RZeile
    {
        public string Datum = "";
        public string SummeStd = "";
        public string ReiseStd = "";
        public string AuftragNr = "";
        public string VonNach = "";
        public string VonNachOrt = ""; //Ortsangabe Pflichtfeld in SAP TM
        public string AbAn = "";
        public string VM = "";
        public string BS = ""; // Breitstellungstext
        public string Km = "";
        public string Zid = "";
        public string anzahl = "";
        public string betrag = "";
        public string auslagen = "";
        public string sg = "";
        public string mf = "";
        public string RNG = "";  //defect 4972

        public bool isBarauslage = false;
        public bool isLoeschbar = true;  //defect 5243
        public bool isAenderbar = true;  //defect 5243

        public RZeile(string datum, string summeStd, string reiseStd, string auftragNr, string vonNach, string vonNachOrt, string abAn, string vM, string bs, string km, string mf, string sg, string zid, string auslagen, string anzahl, string betrag, string rng)  //defect 4972
        {
            Datum = datum;
            SummeStd = summeStd;
            ReiseStd = reiseStd;
            AuftragNr = auftragNr;
            VonNach = vonNach;
            VonNachOrt = vonNachOrt; //Ortsangabe Pflichtfeld in SAP TM
            AbAn = abAn;
            VM = vM;
            BS = bs;
            Km = km;
            RNG = rng;  // defect 4972
            Zid = zid;
            this.mf = (mf != "0") ? mf : "";
            this.sg = sg;
            this.anzahl = anzahl;
            this.auslagen = auslagen;
            this.betrag = betrag;
        }
    }

    private class AZeile
    {
        public string Auslage = "";
        public string Anzahl = "";
        public string Betrag = "";

        public AZeile(string auslage, string anzahl, string betrag)
        {
            Auslage = auslage;
            Anzahl = anzahl;
            Betrag = betrag;
        }
    }


    Table RabTab()
    {
        Table t = new Table();
        int num = 1;

        Dictionary<int, RZeile> id_zeilen1 = new Dictionary<int, RZeile>();
        Dictionary<RZeile, int> zeilen1_id = new Dictionary<RZeile, int>();
        Dictionary<RZeile, dbKG_ReiseZeile> zeilen1_zeilen2 = new Dictionary<RZeile, dbKG_ReiseZeile>();

        t.Width = Unit.Percentage(97);  //defect 4972 war 100
        xxID = 0;
        TableRow rh = new TableRow();
        string xss = "TabHeader";
        rh = AddNewCell(rh, "Datum", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "Summe Std.", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "+Std. Reise", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "Auftrag-Nr.", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "Von - Nach", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "Ab - An", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "Verkehrsm.", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "Bereitst.", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "km", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "MF", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "SG", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "Auslagen", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "Anzahl", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "Betrag", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "RNG", xss, HorizontalAlign.NotSet);  //defect 4972

        rh = AddNewCell(rh, "", xss, HorizontalAlign.NotSet);
        rh.Cells[rh.Cells.Count - 1].ColumnSpan = 2;
        t.Rows.Add(rh);
        //if Reiseabrechnung des Vormonats neu aufrollen
        //die letzte Reise des Vormonats hier anzeigen
        //CheckBox: die letzte Reise wird ge�ndert
        //CheckedChanged: Abrechnung neu generieren...

        //bool ersteTeilAbrNochNichtAngezeigt = true;
        string tRNG = "'";  //defect 4972
        foreach (dbKG_Tag tag in KGMonat.Tage)
        {
            ArrayList Reisen = new ArrayList();
            ArrayList Auslagen = new ArrayList();
            //defect 5390 beginn
            tRNG = "'";
            // defect beginn 5701 wg null-werte (sicherheitshalber hier eingebaut um den absturz zu unterbinden)
            if (KGMonat.Rabrech.ArbzeitenALL == null)
                KGMonat.Rabrech.ArbzeitenALL = KGMonat.Rabrech.get_ArbzeitenALL(KGMonat.Rabrech.ArbzeitenALL);
            // defect 5701 ende
            foreach (dbArbTag AT in KGMonat.Rabrech.ArbzeitenALL)
            {
                if ((AT.TagesDatum == tag.TagesDatum) && (AT.RNGkand == true))
                {
                    if (AT.RNGReisetag == true)
                        tRNG = "+";
                    if (AT.RNG == true)
                        tRNG = "-";
                }
            }
            //defect 5390 ende
            foreach (dbKG_Reise r in KGMonat.Rabrech.Reisen)
            {

                //Defect Blaaarrrgghhh
                //GN 12.02.2007 Beim Hinzuf�gen einer R�ckreise am Monatsanfang kam diese vor der Teilabrechnung zu liegen.
                r.SortZeiten();

                foreach (dbKG_ReiseZeile z in r.Zeilen)
                    if (z.Typ != dbKG_ReiseZeilenTyp.Belegzeile) //werden �ber RAAuslgae angezeigt -> �ber EB ver�nderbar
                    {

                        //Damit die Teilabrechnung aus dem Vormat auch noch angezeit wird
                        if (z.ReiseTag.ToShortDateString() == tag.TagesDatum.ToShortDateString())
                        {

                            //ersteTeilAbrNochNichtAngezeigt = false;
                            double d = tag.NormStunden + tag.UE100 + tag.UE50 + tag.GNormStunden + tag.GUE100 + tag.GUE50;
                            TimeSpan ts = new TimeSpan(z.An.Ticks - z.Ab.Ticks);
                            string dstring = "";
                            if (d != 0) dstring = d.ToString("N");
                            string zid = z.Ab.ToShortDateString() + " " + z.Ab.ToShortTimeString();

                            double totalHours = ts.TotalHours;

                            if (z.Typ == dbKG_ReiseZeilenTyp.Barauslage) totalHours = 0;
                            /* defect 5390 beginn: wieder raus damit
                            // defect 4972 beginn
                            tRNG = "+";
                            DateTime redBegTmp = r.redBeg;
                            if  ((z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) &&(z.flg_teilabr_del == true) )
                            {
                                redBegTmp = redBegTmp.AddDays(1);
                            }
                            if ((z.ReiseTag.DayOfYear >= redBegTmp.DayOfYear) && (redBegTmp.DayOfYear > 2))  //defect 5243 richtiges anzeigen der rng
                            {
                                tRNG = "-";
                            }
                            if ((r.Heimfahrt == dbKG_ReiseHeimfahrtTyp.taeglich )&&(r.Von.DayOfYear == r.Bis.DayOfYear))
                            {
                                tRNG = "'";
                            }
                            // defect 4972 ende
                            defect 5390 ende */
                            // Defect#: 3595 Bereistellungstext richtig versorgen  
                            if (z.Zeile.Params.BEREITST.Value != DBNull.Value)
                            {
                                foreach (ValuePair vp in Bearbeiter.Commons.Bereitstellungsarten)
                                {
                                    if (vp.Value == z.Zeile.Params.BEREITST.Value.ToString())
                                    {
                                        z.Zeile.Params.BSTXT.Value = vp.Text;
                                        break;
                                    }
                                }
                            }
                            RZeile rzeile = new RZeile(DayDate(tag.TagesDatum), dstring, totalHours
                                 .ToString("N")
                                 , z.AuftragNr
                                 , dbKG_ReiseZeilenKZ.GetKZText(z.Typ)
                                 , z.Zeile.Params.ABORT.Value.ToString() + " -> " + z.Zeile.Params.ANORT.Value.ToString() + " [Typ " + z.Zeile.Params.REISEART.Value.ToString() + "]" //Ortsangabe Pflichtfeld in SAP TM
                                 , z.Ab.ToShortTimeString() + " - " + z.An.ToShortTimeString()
                                 , z.Zeile.Params.RAKZTXT.Value.ToString()
                                 , z.Zeile.Params.BSTXT.Value.ToString()
                                 , z.Zeile.Params.GEFKM.Value.ToString()
                                 , z.Zeile.Params.MITFAHRER.Value.ToString()
                                 , z.Zeile.Params.SCHWERGP.Value.ToString()
                                 , zid
                                 , z.Zeile.Params.AUSLART.Value.ToString()
                                 , z.Zeile.Params.ANZNAECHTE.Value.ToString()
                                 , z.Zeile.Params.BETRAG.Value.ToString()
                                 , tRNG  // defect 4972
                                 );
                            if( z.Ab.Date != z.An.Date )
                            {
                                rzeile.AbAn = z.Ab.ToString() + " - " + z.An.ToString();
                            }

                            // Defect# 3595 ende
                            if (z.Typ == dbKG_ReiseZeilenTyp.Barauslage)
                            {
                                rzeile.isBarauslage = true;
                            }
                            //defect 4972 merker setzen auf reisebeginn/ende
                            if ((z.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt) || ((z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) && (z.flg_teilabr_del == false) && (z.Ab.Hour == 23))
                            )
                            {
                                tRNG = "'";
                            }
                            //Defect 4933
                            //GN 10.04.2007
                            //Bei Teilabrechnung wird die Zeit nicht mehr angezeigt, um Anwender nicht zu verwirren.
                            if (z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                            {
                                rzeile.AbAn = "";
                                //defect 5243 beg: versogren der anzeigeflags
                                if (z.flg_teilabr_del == true)
                                {
                                    rzeile.isLoeschbar = false;
                                    rzeile.isAenderbar = false;
                                }
                                else
                                {
                                    rzeile.isLoeschbar = true;
                                    rzeile.isAenderbar = false;
                                }
                                //defect 5243 ende
                            }
                            //BAN 500059
                            if (z.Typ == dbKG_ReiseZeilenTyp.WechselBereitstellung )
                            {
                                switch (Convert.ToInt32(z.Zeile.Params.INTF_ID.Value))
                                {
                                    case 85:
                                        rzeile.isLoeschbar = false;
                                        rzeile.isAenderbar = false;
                                        break;
                                    case 88:
                                        rzeile.isAenderbar = false;
                                        break;
                                    default:
                                        break;
                                }
                            }

                            //if(!rzeile.isBarauslage)
                            Reisen.Add(rzeile);

                            id_zeilen1.Add(num, rzeile);
                            zeilen1_id.Add(rzeile, num);
                            zeilen1_zeilen2.Add(rzeile, z);
                            num++;

                        }

                    }
            }
            foreach (dbKG_EB eb in tag.EBerichte)
                foreach (dbKG_RATag ra in eb.ReiseAusl)
                {
                    Auslagen.Add(new AZeile(ra.Auslagenart, ra.Anzahl.ToString("N"), ra.Betrag.ToString("N")));
                }
            if (Reisen.Count == 0)
            {
                double d = tag.NormStunden + tag.UE100 + tag.UE50 + tag.GNormStunden + tag.GUE100 + tag.GUE50;
                string dstring = "";
                if (d != 0) dstring = d.ToString("N");
                Reisen.Add(new RZeile(DayDate(tag.TagesDatum), dstring, "", "", "", "", "", "", "", "", "", "", "", "", "", "", tRNG));
            }
            while (Reisen.Count < Auslagen.Count) Reisen.Add(new RZeile("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""));
            while (Auslagen.Count < Reisen.Count) Auslagen.Add(new AZeile("", "", ""));
            bool first = true;
            for (int i = 0; i < Reisen.Count; i++)
            {
                RZeile rz = (RZeile)Reisen[i];
                AZeile az = (AZeile)Auslagen[i];
                string css = "TabNewDay";
                //defect 4972 beginn
                string tempRNG = rz.RNG;  //defect 4972
                // defect 4972 ende
                if (!first)
                {
                    rz.Datum = "";
                    rz.SummeStd = "";
                    css = "TabZeile";
                    tempRNG = "";  //defect 4972
                }
                //if ((tag.TagesDatum.DayOfWeek == DayOfWeek.Saturday) | (tag.TagesDatum.DayOfWeek == DayOfWeek.Sunday) | (!KGMonat.Monteur.IstArbeitstag(tag.TagesDatum)))
                //BAF 530042 Beginn
                if (KGMonat.Monteur.AZMKalenderTage.ContainsKey(tag.TagesDatum))
                {
                    if (!KGMonat.Monteur.AZMKalenderTage[tag.TagesDatum].IstArbeitstag)
                        css += "WE";
                }//BAF 530042 Ende
                else
                {
                    if (!KGMonat.Monteur.IstArbeitstag(tag.TagesDatum))
                        css += "WE";
                }
                TableRow r = new TableRow();

                // Beginn #4040, 4370
                r = AddNewCell(r, rz.Datum + "<a name=\"" + rz.Datum + "\" />", css, HorizontalAlign.Left);
                // Ende #4040, 4370
                r = AddNewCell(r, rz.SummeStd, css, HorizontalAlign.Right);
                r = AddNewCell(r, rz.ReiseStd, css, HorizontalAlign.Right);
                r = AddNewCell(r, rz.AuftragNr, css, HorizontalAlign.Right);
                r = AddNewCell(r, rz.VonNach, css, HorizontalAlign.Left, rz.VonNachOrt);
                r = AddNewCell(r, rz.AbAn, css, HorizontalAlign.Center);
                r = AddNewCell(r, rz.VM, css, HorizontalAlign.Left);
                r = AddNewCell(r, rz.BS, css, HorizontalAlign.Left);
                r = AddNewCell(r, rz.Km, css, HorizontalAlign.Right);
                //r = AddNewCell(r, rz.sg, css, HorizontalAlign.Right);
                r = AddNewCell(r, rz.mf, css, HorizontalAlign.Right);
                r = AddNewCell(r, rz.sg, css, HorizontalAlign.Right);


                if (rz.isBarauslage)
                {
                    r = AddNewCell(r, rz.auslagen, css, HorizontalAlign.Left);
                    r = AddNewCell(r, rz.anzahl, css, HorizontalAlign.Right);
                    r = AddNewCell(r, rz.betrag, css, HorizontalAlign.Right);
                }
                else
                {

                    r = AddNewCell(r, az.Auslage, css, HorizontalAlign.Left);
                    r = AddNewCell(r, az.Anzahl, css, HorizontalAlign.Right);
                    r = AddNewCell(r, az.Betrag, css, HorizontalAlign.Right);
                }
                // defect 4972 zuweisung einer reduzierung anhand der reise
                r = AddNewCB(r, tempRNG, css, "Reduziertes N�chtigungsgeld", CeckBoxRNG_CheckedChanged, rz.Datum);  // defect 4972

                TableCell c = new TableCell();
                TableCell c2 = new TableCell();
                if (rz.Zid != "")
                {
                    //c.Wrap = false;
                    if (!rz.isBarauslage)
                    {
                        c.Controls.Add(NewTaskButton("bearbeiten", "Edit", zeilen1_id[rz].ToString(), "Klicken Sie hier um diese Reise zu bearbeiten.", TaskButton_Click, "~/Images/Bearbeiten_16x16.jpg"));  // defect 4972 etzer param url f�r bild                        
                    }
                    c2.Controls.Add(NewTaskButton("l�schen", "Delete", zeilen1_id[rz].ToString(), "Klicken Sie hier um diese Reise zu l�schen.", TaskButton_Click, "~/Images/trash16x16.jpg"));  // defect 4972 letzer param url f�r bild

                    if (!rz.isBarauslage)
                    {
                        (c.Controls[0] as LinkButton).Visible = KGMonat.Rabrech.AutoGenerated;
                        (c.Controls[0] as LinkButton).Enabled = KGMonat.Rabrech.AutoGenerated;
                    }
                    (c2.Controls[0] as LinkButton).Visible = KGMonat.Rabrech.AutoGenerated;
                    (c2.Controls[0] as LinkButton).Enabled = KGMonat.Rabrech.AutoGenerated;

                    //Defect 4623
                    //GN 12.02.2007 Die erste Teilabrechnung darf nicht gel�scht werden
                    if (i == 0 && rz.VonNach == "Teilabrechnung")
                    {
                        //defect 5243 beg: icons richtig setzten, nur sichtabr wenn clickbar
                        if (rz.isAenderbar == false)
                        {
                            ((LinkButton)(c.Controls[0])).Enabled = false;
                            ((LinkButton)(c.Controls[0])).Visible = false;
                        }
                        else
                        {
                            ((LinkButton)(c.Controls[0])).Enabled = true;
                            ((LinkButton)(c.Controls[0])).Visible = true;

                        }

                        if (rz.isLoeschbar == false)
                        {
                            ((LinkButton)(c2.Controls[0])).Enabled = false;
                            ((LinkButton)(c2.Controls[0])).Visible = false;
                        }
                        else
                        {
                            ((LinkButton)(c2.Controls[0])).Enabled = true;
                            ((LinkButton)(c2.Controls[0])).Visible = true;
                        }
                        //defect 5243 ende
                    }
                    //BAN 500059 WechselBereitstellung nicht �nderbar und nicht l�schbar
                    if( rz.VonNach == dbKG_ReiseZeilenKZ.GetKZText(dbKG_ReiseZeilenTyp.WechselBereitstellung))
                    {
                        if( rz.isAenderbar == false )
                        {
                            ((LinkButton)(c.Controls[0])).Enabled = false;
                            ((LinkButton)(c.Controls[0])).Visible = false;
                        }

                        if( rz.isLoeschbar == false )
                        {
                            ((LinkButton)(c2.Controls[0])).Enabled = false;
                            ((LinkButton)(c2.Controls[0])).Visible = false;
                        }
                    }//BAN 500059 Ende
                }
                c.CssClass = css;
                c2.CssClass = css;
                r.Cells.Add(c);
                r.Cells.Add(c2);
                t.Rows.Add(r);
                first = false;
            }
        }

        Session["zeilen1_id"] = zeilen1_id;
        Session["id_zeilen1"] = id_zeilen1;
        Session["zeilen1_zeilen2"] = zeilen1_zeilen2;

        return t;
    }

    private string DayDate(DateTime d)
    {
        string[] wTag = new string[] { "So.", "Mo.", "Di.", "Mi.", "Do.", "Fr.", "Sa." };
        return wTag[(int)d.DayOfWeek] + " " + d.Day.ToString() + "." + d.Month.ToString() + ".";
    }
    //defect4972 beginn cb in liste
    void CeckBoxRNG_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox cb = (CheckBox)sender;
        //TAPM-34 - ein ID wergeben und dem prerender sage er soll computeSAP durchf�hren
        foreach (dbArbTag tag in KGMonat.Rabrech.ArbzeitenALL)
        {
            if (cb.ID == "CheckboxRNG-" + DayDate(tag.TagesDatum))
            {
                tag.RNG = cb.Checked;
                Session["computeSAP"] = true;
                break;
            }
        }

    }

    TableRow AddNewCB(TableRow r, string Argument, string css, string ToolTip, EventHandler ev_handle, string td)
    {
        TableCell c = new TableCell();
        CheckBox cb = new CheckBox();
        //cb.AutoPostBack = true;  //nicht so gut...
        cb.CheckedChanged += new EventHandler(ev_handle);
        //TAPM-34 - javascript an checkbox eigenschaft anh�ngen
        cb.Attributes["OnClick"] = "javascript:RNGCheckBoxChanged();";

        //Defect 5673, 5677
        //GN 03.12.2007
        //Die automatische ID-Generierung des .NET-Frameworkds f�hrte in seltenen F�llen zu einem Fehler
        //Wenn die IDs programmatisch vergeben werden, tritt der Fehler nicht auf.

        //cb.ID = "CheckboxRNG" + cb_count;
        if (td == "")
        {
            cb.ID = "CheckboxRNG" + cb_count;
            cb_count++;
        }
        else
            cb.ID = "CheckboxRNG-" + td;


        if (Argument == "+")
        {
            cb.Visible = true;
            cb.Checked = false;
        }
        else if (Argument == "-")
        {
            cb.Visible = true;
            cb.Checked = true;
        }
        else
        {
            cb.Visible = false;
        }

        c.Controls.Add(cb);
        c.HorizontalAlign = HorizontalAlign.Center;
        c.VerticalAlign = VerticalAlign.Middle;
        cb.ToolTip = ToolTip;
        c.CssClass = css;
        r.Cells.Add(c);
        return r;
        //c2.Controls.Add(NewTaskButton("l�schen", "Delete", zeilen1_id[rz].ToString(), "Klicken Sie hier um diese Reise zu l�schen.", TaskButton_Click));
    }
    //defect4972 ende cb in liste

    TableRow AddNewCell(TableRow r, string LabelText, string css, HorizontalAlign align)
    {
        TableCell c = new TableCell();
        Label l = new Label();
        l.Text = LabelText;
        c.Controls.Add(l);
        c.CssClass = css;
        c.HorizontalAlign = align;
        r.Cells.Add(c);
        return r;
    }

    TableRow AddNewCell(TableRow r, string LabelText, string css, HorizontalAlign align, string tooltip)
    {
        TableCell c = new TableCell();
        Label l = new Label();
        l.Text = LabelText;
        c.Controls.Add(l);
        c.CssClass = css;
        c.HorizontalAlign = align;
        c.ToolTip = tooltip;
        r.Cells.Add(c);
        return r;
    }
    private LinkButton NewTaskButton(string Text, string Command, string Argument, string ToolTip, CommandEventHandler TaskButtonClick_EventHandler, string url)  //defect 4972
    {
        LinkButton btn = new LinkButton();
        btn.ID = nid();
        btn.SkinID = "";
        btn.Width = Unit.Percentage(100);
        btn.Text = Text;
        //defect 4972 beginn image bei link
        if (url != "")
        {
            Image i = new Image();
            //zb: "~/Images/user_icon.gif"
            i.ImageUrl = url;
            btn.Controls.Add(i);
        }
        //defect 4972 ende image bei link
        btn.CommandName = Command;
        btn.CommandArgument = Argument;
        btn.ToolTip = ToolTip;
        btn.CausesValidation = false;
        btn.Enabled = (KGReiseZeile == null);
        btn.Command += new CommandEventHandler(TaskButtonClick_EventHandler);
        //cList.Add(btn);
        return btn;
    }

    public int xxID = 0;
    public string nid()
    {
        xxID++;
        return "LnkBTN->" + xxID.ToString();
    }
    void TaskButton_Click(object sender, CommandEventArgs e)
    {
        string scrollPosition = "edit";
        string cmd = (string)e.CommandName;
        int arg = Convert.ToInt16((string)e.CommandArgument);
        //DateTime dt = Convert.ToDateTime(arg);

        switch (cmd)
        {
            case "Edit":

                RZeile rrr = ((Dictionary<int, RZeile>)(Session["id_zeilen1"]))[arg];
                KGReiseZeile = ((Dictionary<RZeile, dbKG_ReiseZeile>)(Session["zeilen1_zeilen2"]))[rrr];

                Session["KGReiseZeile"] = KGReiseZeile;
                if (KGReiseZeile != null)
                    MapData();
                break;
            case "Delete":
                RZeile rrruuuhaa = ((Dictionary<int, RZeile>)(Session["id_zeilen1"]))[arg];
                KGReiseZeile = ((Dictionary<RZeile, dbKG_ReiseZeile>)(Session["zeilen1_zeilen2"]))[rrruuuhaa];

                KGReiseZeile.Zeile.Deleted = true;
                //KGReiseZeile.Reise.Zeilen.Remove(KGReiseZeile); //defect 5243  einmal loeschen reicht
                Session.Remove("KGReiseZeile");
                //defect 4972 auch in den objekt KGMonat.Rabrech.Reisen die zeile l�schen, da sie in RabTab von dort geladen wird....

                LabelError.Text = KGMonat.Rabrech.DelReiseZeile(KGMonat.Rabrech.Reisen, ParamVal.Date0, false, KGReiseZeile);  // defect 5430, 5432 auch An mit pr�fen
                //KGMonat.Rabrech.ComputeSAP();

                KGReiseZeile = null;
                if (rrruuuhaa.Datum != "")
                    scrollPosition = rrruuuhaa.Datum;
                break;
            default:
                Exception ex = new Exception("Command not recognized: " + cmd);
                throw ex;
        }
        phRabTab.Controls.Clear();
        phRabTab.Controls.Add(RabTab());
        // Beginn #4040, 4370
        if (scrollPosition == "edit")
            SetFocus(BtnSave);
        else
            SetFocus(scrollPosition);
        // Ende #4040, 4370
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        KGReiseZeile = null;
        Session.Remove("KGReiseZeile");
        btnCancel.Visible = false;
        phRabTab.Controls.Clear();
        phRabTab.Controls.Add(RabTab());
        clearFields();
        enableEdit();
    }

    /// <summary>
    /// �bernehmen der �nderungen (Button '�nderung Speichern' od. 'Zeile Hinzuf�gen') einer Reisezeile in die Liste
    /// wird noch nicht in die DB geschrieben
    /// </summary>
    protected void BtnSave_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            if (rblTyp.SelectedValue != "W" && ddlVm.DDL.SelectedIndex == 0)
            {
                LabelError.Text = "Geben Sie bitte Verkehrsmittel ein.";
                return;
            }
            if (rblTyp.SelectedValue == "W")
            {
                tbDAn.TB.Text = tbDAb.TB.Text;
                tbAn.TB.Text = tbAb.TB.Text;
            }
            bool useNewHRInterface = false;
            bool doIt = true;
            if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
            {
                useNewHRInterface = true;
            }
            DateTime abfahrt = Convert.ToDateTime(Convert.ToDateTime(tbDAb.TextBoxText).ToShortDateString() + " " + Convert.ToDateTime(tbAb.TextBoxText).ToShortTimeString());
            DateTime ankunft = Convert.ToDateTime(Convert.ToDateTime(tbDAn.TextBoxText).ToShortDateString() + " " + Convert.ToDateTime(tbAn.TextBoxText).ToShortTimeString());

            if (useNewHRInterface)
            {
                if (abfahrt > ankunft)
                    doIt = false;
            }
            else
            {
                // Beginn Defect 5198
                // �berpr�fung ob eingegebene Abfahrtszeit <= Ankunftszeit
                tbDAn = tbDAb; // Eingabe nicht sinnvoll, da Ankunftsdatum immer = Abfahrtsdatum sein mu�
                if (Convert.ToDateTime(tbAb.TextBoxText) >
                    Convert.ToDateTime(tbAn.TextBoxText))
                {
                    //LabelError.Text = "Geben Sie bitte eine Abfahrtszeit ein, die nicht sp�ter als die Ankunftszeit ist.";
                    doIt = false;
                }
            }
            if (doIt == false)
            {
                LabelError.Text = "Geben Sie bitte eine Abfahrtszeit ein, die nicht sp�ter als die Ankunftszeit ist.";
            }
            else
            {   // Ende Defect 5198
                //BAN 500059 Beginn
                if (useNewHRInterface)
                {
                    TimeSpan ts = new TimeSpan(abfahrt.Ticks - KGMonat.MinDatum.Ticks);

                    if (ts.TotalDays < -1) // Hinreise darf im Vormonat beginnen aber nur am letzten Tag
                    {
                        LabelError.Text = "Datum f�r den Zeitstempel muss im Bereich " + KGMonat.MinDatum.ToShortDateString() + " bis " + KGMonat.MaxDatum.ToShortDateString() + " liegen.";
                        doIt = false;
                    }

                    if (doIt)
                    {
                        ts = new TimeSpan(ankunft.Ticks - KGMonat.MaxDatum.Ticks);
                        if (ts.TotalMinutes > 1) // Reisedaten im Folgemonat d�rfen nicht erfasst werden
                        {
                            LabelError.Text = "Datum f�r den Zeitstempel muss im Bereich " + KGMonat.MinDatum.ToShortDateString() + " bis " + KGMonat.MaxDatum.ToShortDateString() + " liegen.";
                            doIt = false;
                        }
                    }
                }
                else
                {
                    //altes code
                    if ((Convert.ToDateTime(tbDAb.TextBoxText).Year * 100) + Convert.ToDateTime(tbDAb.TextBoxText).Month != KGMonat.Monat)
                    {
                        LabelError.Text = "Datum f�r den Zeitstempel muss im Bereich " + KGMonat.MinDatum.ToShortDateString() + " bis " + KGMonat.MaxDatum.ToShortDateString() + " liegen.";
                        doIt = false;
                    }

                }
                //BAN 500059 Ende
                // Beginn Defect 5824
                // Abfrage auf Zeitbereich des Zeitstemples und Fehlermeldung ausgeben
                //if ((Convert.ToDateTime(tbDAb.TextBoxText).Year * 100) + Convert.ToDateTime(tbDAb.TextBoxText).Month != KGMonat.Monat)
                //{
                //    LabelError.Text = "Datum f�r den Zeitstempel muss im Bereich " + KGMonat.MinDatum.ToShortDateString() + " bis " + KGMonat.MaxDatum.ToShortDateString() + " liegen.";
                //}
                //else
                if(doIt)
                { // Ende Defect 5824
                    if (KGReiseZeile == null)
                    {
                        KGReiseZeile = new dbKG_ReiseZeile(new dbKG_Reise(KGMonat.Rabrech, null), null);
                        SaveData();

                        dbKG_Reise rr = null;
                        dbKG_Reise rr2 = null;
                        // defect 4972 besser so suchen
                        //insert der zeile, suchen einer passenden reise, true wenn insertabel, sonst nicht zuordenbar
                        bool bret = KGMonat.Rabrech.InsertReiseZeile(KGReiseZeile, ref rr, false); //defect 5243 nur reise ermitteln
                        /*if ( bret == false )
                        {
                            LabelError.Text = "Die Reisezeile kann nicht zugeordnet werden! -> nicht gespeichert";
                        }
                        else
                         * */
                        //defect 5243 dieser teil ist notwendig um die reisen vollst�ndig zu haben
                        {
                            switch (KGReiseZeile.Typ)
                            {
                                case dbKG_ReiseZeilenTyp.Hinfahrt:
                                    if (rr == null)
                                        rr = KGMonat.Rabrech.FindeReise(KGReiseZeile.An, true, false, KGMonat.Rabrech.Reisen); //beginnt davor oder danach
                                    if (rr == null)
                                        rr = KGMonat.Rabrech.FindeReise(KGReiseZeile.An, true, true, KGMonat.Rabrech.Reisen);
                                    break;
                                case dbKG_ReiseZeilenTyp.Rueckfahrt:
                                    if (rr == null)
                                        rr = KGMonat.Rabrech.FindeReise(KGReiseZeile.Ab, false, true, KGMonat.Rabrech.Reisen); //endet danach oder davor
                                    if (rr == null)
                                        rr = KGMonat.Rabrech.FindeReise(KGReiseZeile.An, true, true, KGMonat.Rabrech.Reisen);

                                    //Defect 4698_4722_4764_4766_4778
                                    //GN 8.3.2007 Hinreise folgt auf Hinreise.
                                    // MIt dieser zeile wird verhindert, dass die letzte Reise aus dem Vormonat nicht mehr �berpr�ft wird
                                    //Defect #5822 try/catch implementiert weil rr kann auch ein nullpointer sein
                                    try
                                    {
                                        if (rr.Bis < KGMonat.MinDatum) KGMonat.Rabrech.VormonatVer�ndert = true;
                                    }
                                    catch
                                    {
                                    }
                                    break;
                                case dbKG_ReiseZeilenTyp.FahrtAmDienstort:
                                case dbKG_ReiseZeilenTyp.Belegzeile:
                                case dbKG_ReiseZeilenTyp.Teilabrechnung:
                                case dbKG_ReiseZeilenTyp.WechselBereitstellung:
                                    //rr = KGMonat.Rabrech.FindeReise(KGReiseZeile.Ab, true, true);
                                    rr2 = KGMonat.Rabrech.FindeReise(KGReiseZeile.An, false, false, KGMonat.Rabrech.Reisen);
                                    if (rr != rr2) rr = null; //da is was faul;
                                    break;
                                case dbKG_ReiseZeilenTyp.StandortWechsel:
                                    //rr = KGMonat.Rabrech.FindeReise(KGReiseZeile.An, true, true);
                                    rr2 = KGMonat.Rabrech.FindeReise(KGReiseZeile.An, false, false, KGMonat.Rabrech.Reisen);
                                    if (rr2 == null) rr2 = rr;
                                    break;
                            }
                            string strAuftrag = "";
                            int gefkm = 0;
                            string strvmindex = "";
                            string strbsindex = "";
                            string strVM = "";
                            string strBS = "";
                            if (rr != null)
                            {
                                KGReiseZeile = new dbKG_ReiseZeile(rr, null);
                                SaveData();
                                gefkm = Convert.ToInt32(KGReiseZeile.Zeile.Params.GEFKM.Value); // gefahrene KM,... werden nachher �berschrieben
                                strvmindex = KGReiseZeile.Zeile.Params.VERKEHRSMITTEL.Value.ToString();
                                strbsindex = KGReiseZeile.Zeile.Params.BEREITST.Value.ToString();
                                strVM = KGReiseZeile.Zeile.Params.RAKZTXT.Value.ToString();
                                strBS = KGReiseZeile.Zeile.Params.BSTXT.Value.ToString();
                                strAuftrag = KGReiseZeile.AuftragNr;
                                switch (KGReiseZeile.Typ)
                                {
                                    case dbKG_ReiseZeilenTyp.Hinfahrt:
                                        // Date         : 26.M�rz 2007
                                        // Author       : Georg Nebehay
                                        // Defect#      : 4782
                                        // Hier wird zuerst die Ab-Zeit gespeichert
                                        DateTime Ab = KGReiseZeile.Ab;
                                        KGReiseZeile = KGMonat.Rabrech.ZHin(KGReiseZeile, KGReiseZeile.An, rr.IntfID, strAuftrag);  // defect 5702 konto von maske
                                        // Und hier wieder gesetzt, da sie in der obigen Zeile �berschrieben wurde
                                        //KGReiseZeile.Params.AB wird dadurch auch gesetzt (Siehe Property)
                                        KGReiseZeile.Ab = Ab;
                                        break;
                                    case dbKG_ReiseZeilenTyp.Rueckfahrt:
                                        // Date         : 26.M�rz 2007
                                        // Author       : Georg Nebehay
                                        // Defect#      : 4782
                                        // Hier wird zuerst die An-Zeit gespeichert
                                        DateTime An = KGReiseZeile.An;
                                        KGReiseZeile = KGMonat.Rabrech.ZRueck(KGReiseZeile, KGReiseZeile.Ab, rr.IntfID, strAuftrag);  // defect 5702 konto von maske
                                        // Und hier wieder gesetzt, da sie in der obigen Zeile �berschrieben wurde
                                        //KGReiseZeile.Params.AN wird dadurch auch gesetzt (Siehe Property)
                                        KGReiseZeile.An = An;
                                        break;
                                    case dbKG_ReiseZeilenTyp.FahrtAmDienstort:
                                        KGReiseZeile = KGMonat.Rabrech.ZFahrtADO(KGReiseZeile, KGReiseZeile.Ab, KGReiseZeile.An, rr.IntfID);
                                        break;
                                    case dbKG_ReiseZeilenTyp.Belegzeile:
                                        //kanns eigentlich garnicht geben?
                                        break;
                                    case dbKG_ReiseZeilenTyp.Teilabrechnung:
                                        //kanns eigentlich garnicht geben
                                        break;
                                    case dbKG_ReiseZeilenTyp.WechselBereitstellung:
                                        KGReiseZeile = KGMonat.Rabrech.ZBWechsel(KGReiseZeile, rr.IntfID);
                                        break;
                                    case dbKG_ReiseZeilenTyp.StandortWechsel:
                                        try //Defect #5822 try/catch implementiert weil rr2 k�nnte ein nullpointer sein
                                        {
                                            KGReiseZeile = KGMonat.Rabrech.ZWechsel(KGReiseZeile, rr2.Aufenthaltsort, "HACK", strAuftrag);  // defect 5702 konto von maske
                                        }
                                        catch
                                        {
                                        }
                                        break;
                                }
                                KGReiseZeile.Zeile.Params.GEFKM.Value = gefkm;
                                KGReiseZeile.Zeile.Params.VERKEHRSMITTEL.Value = strvmindex;
                                KGReiseZeile.Zeile.Params.BEREITST.Value = strbsindex;
                                KGReiseZeile.Zeile.Params.RAKZTXT.Value = strVM;
                                KGReiseZeile.Zeile.Params.BSTXT.Value = strBS;
                                KGReiseZeile.AuftragNr = strAuftrag;
                                rr.Zeilen.Add(KGReiseZeile);
                                rr.SortZeiten();
                                //loeschen einer t1-zeile am monatsende wenn eine rr da ist
                                bret = KGMonat.Rabrech.DelTZeileMonatsende(ref  rr);
                                // zuweisen der modifizieren reise im reisen-array defect 5243
                                foreach (dbKG_Reise rx in KGMonat.Rabrech.Reisen)
                                {
                                    if (rr.Von == rx.Von)
                                    {
                                        int idx = KGMonat.Rabrech.Reisen.IndexOf(rx);
                                        KGMonat.Rabrech.Reisen[idx] = rr;
                                        //defect 5308: wir berechnen die reduzierung wieder mal neu fuer das modifiziere objekt
                                        LabelError.Text = KGMonat.Rabrech.ComputeSAP(false, false, false);  // defect 5390 fm auch darstellen
                                        break;
                                    }
                                }
                            }
                            //Defect 4468, Text korrigiert
                            //else LabelError.Text = "Die Reise kann keinem Einsatzbericht zugeordnet werden! -> nicht gespeichert";
                            else LabelError.Text = "Der Standortwechsel liegt au�erhalb einer Hin- und R�ckreise! -> nicht gespeichert";
                            //ende defect 4972 
                        }

                    }
                    else
                    {//�nderung speichern
                        LabelError.Text = SaveData();  // defect 5390 fm ausgeben
                    }
                    Session["KGMonat"] = KGMonat;
                    KGReiseZeile = null;
                    Session.Remove("KGReiseZeile");
                    phRabTab.Controls.Clear();
                    phRabTab.Controls.Add(RabTab());
                    btnCancel.Visible = false;
                    clearFields();
                    enableEdit();
                    // Beginn #4040, 4370
                    SetFocus(phRabTab);
                    // Ende #4040, 4370
                }
            }
        }
        else
        {
            SetFocus(BtnPrev);
        }
    }

    private void clearFields()
    {
        tbAb.TextBoxText = "";
        tbAn.TextBoxText = "";
        tbKm.TextBoxText = "";
        tbNach.TextBoxText = "";
        tbVon.TextBoxText = "";
        ddlBer.DDL.SelectedIndex = 0;
        ddlVm.DDL.SelectedIndex = 0;

        //CR 4931, 4932
        //Beim R�cksetzen muss �berpr�ft werden, welches Verkehrsmittel ausgew�hlt ist.
        VM_DDL_SelectedIndexChanged(null, null);

        BtnSave.Text = "Zeile Hinzuf�gen";
    }
    private void enableEdit()
    {
        switch (rblTyp.SelectedValue)
        {
            case "H":
            case "R":
            case "S":
                tbAb.Enabled = true;
                tbAn.Enabled = true;
                tbDAb.Enabled = true;
                tbDAn.Enabled = true;
                tbKm.Enabled = true;
                ddlBer.Enabled = true;
                ddlVm.Enabled = true;
                MitfahrerDDL.Enabled = true;
                SchwergpCheckBox.Enabled = true;
                break;
            case "W":
                tbAb.Enabled = true;
                tbAn.Enabled = false;
                tbAn.TB.Text = tbAb.TB.Text;
                tbDAb.Enabled = true;
                tbDAn.Enabled = false;
                tbDAn.TB.Text = tbDAb.TB.Text;
                tbKm.Enabled = false;
                tbKm.TB.Text = "0";
                ddlBer.Enabled = true;
                ddlVm.Enabled = false;
                ddlVm.DDL.SelectedIndex = 0;
                MitfahrerDDL.DDL.SelectedIndex = 0;
                MitfahrerDDL.Enabled = false;
                SchwergpCheckBox.Checked = false;
                SchwergpCheckBox.Enabled = false;
                break;
            default: break;
        }
    }

    protected void rblTyp_SelectedIndexChanged(object sender, EventArgs e)
    {
        enableEdit();
        // Beginn #4040, 4370
        SetFocus(BtnSave);
        // Ende #4040, 4370
    }
    protected void ChkChangeVormonat_CheckedChanged(object sender, EventArgs e)
    {
        KGMonat.Rabrech.KorrekturVormonat = ChkChangeVormonat.Checked;
        KGMonat.Rabrech.Initialized = false;
        KGMonat.Rabrech.Select(true, KGMonat.Monat);
        Session["KGMonat"] = KGMonat;
        phRabTab.Controls.Clear();
        phRabTab.Controls.Add(RabTab());
    }

    private Table BemerkungfuerGenehmiger()
    {
        Table tabBem = new Table();
        TableRow HeaderRow = new TableRow();
        // Defect #6014 - neue Spalte hinzuf�gen - Projektname
        TableCell c3 = new TableCell();
        c3.Text = "Projekt";
        c3.Width = 200;
        c3.HorizontalAlign = HorizontalAlign.Center;
        c3.CssClass = "TabHeader";
        c3.Font.Bold = true;

        TableCell c1 = new TableCell();
        c1.Text = "AuftragNr";
        c1.HorizontalAlign = HorizontalAlign.Center;
        c1.Width = 150;
        c1.CssClass = "TabHeader";
        c1.Font.Bold = true;

        TableCell c2 = new TableCell();
        c2.Text = "Interne Bemerkung";
        c2.Width = 700;
        c2.HorizontalAlign = HorizontalAlign.Center;
        c2.CssClass = "TabHeader";
        c2.Font.Bold = true;

        HeaderRow.Cells.Add(c3);
        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        tabBem.Rows.Add(HeaderRow);

        HeaderRow.Visible = false;
        TableRow tr;
        //string OldAuftNr = "-";
        //string AuftNr = "0";


        //Defect #6014 - pro EB eine Zeile in der Bemerkungstabelle schreiben
        foreach (dbMontBer mber in KGMonat.Monteur.MBerichte)
        {
            string interneBemerkung = mber.Params.EBHIST.Value.ToString().Trim();
            string projektName = mber.Projekt.Params.NAME.Value.ToString().Trim();

            if (interneBemerkung != null && interneBemerkung != "" && projektName != null && projektName != "")
            {
                HeaderRow.Visible = true;
                ArrayList listAuftrag = new ArrayList();
                string auftragNr = "";
                foreach (dbArbTag at in mber.Tage)
                {
                    foreach (dbArbZeit az in at.Zeiten)
                    {
                        if (az.Params is dbAZ_KALTAGParams)
                            continue;
                        if (az.GKAuftragNR != ""
                            && Convert.ToInt32((az.Params as dbAZ_ARBZEITParams).EBID.Value) == Convert.ToInt32(mber.Params.EBID.Value)
                            && listAuftrag.BinarySearch(az.GKAuftragNR) < 0)
                        {
                            listAuftrag.Add(az.GKAuftragNR);
                            listAuftrag.Sort();
                        }
                    }
                }
                foreach (string s in listAuftrag)
                {
                    if (auftragNr != "")
                        auftragNr += " / ";
                    auftragNr += s;
                }

                string strCssClassRow = "Auftnr_neu";
                tr = new TableRow();

                TableCell d3 = new TableCell();
                //TextBox tb3 = new TextBox();
                Label tb3 = new Label();
                tb3.Width = 200;
                tb3.Text = projektName;
                d3.HorizontalAlign = HorizontalAlign.Left;
                d3.CssClass = strCssClassRow;
                //d3.Enabled = false;
                //d3.Font.Bold = true;
                d3.Controls.Add(tb3);
                tr.Cells.Add(d3);

                TableCell d1 = new TableCell();
                //TextBox tb1 = new TextBox();
                Label tb1 = new Label();
                tb1.Width = 150;
                tb1.Text = auftragNr;
                d1.HorizontalAlign = HorizontalAlign.Left;
                d1.CssClass = strCssClassRow;
                //d1.Enabled = false;
                //d1.Font.Bold = true;
                d1.Controls.Add(tb1);
                tr.Cells.Add(d1);

                TableCell d2 = new TableCell();
                //TextBox tb = new TextBox();
                Label tb = new Label();
                tb.Width = 700;
                tb.Text = interneBemerkung;
                d2.HorizontalAlign = HorizontalAlign.Left;
                //d2.Font.Bold = true;
                //d2.Enabled = false;
                d2.ForeColor = System.Drawing.Color.Black;
                d2.Controls.Add(tb);
                d2.CssClass = strCssClassRow;
                tr.Cells.Add(d2);
                tabBem.Rows.Add(tr);
            }
        }

        return tabBem;

        /*TableRow HeaderRow = new TableRow();
        TableCell c1 = new TableCell();
        c1.Text = "AuftragNr";
        c1.HorizontalAlign = HorizontalAlign.Center;
        c1.Width = 200;
        c1.CssClass = "TabHeader";
        c1.Font.Bold = true;

        TableCell c2 = new TableCell();
        c2.Text = "Bemerkungen";
        c2.Width = 700;
        c2.HorizontalAlign = HorizontalAlign.Center;
        c2.CssClass = "TabHeader";
        c2.Font.Bold = true;

        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        tabBem.Rows.Add(HeaderRow);
        TableRow tr;
        string OldAuftNr = "-";
        string AuftNr = "0";
        foreach (dbKG_Tag t in KGMonat.Tage)
        {
            foreach (dbKG_EB e in t.EBerichte)
            {
                foreach (object obj in e.ArbZeit)
                {
                    if (obj is dbKG_AZTag)
                    {
                        AuftNr = ((dbKG_AZTag)obj).Auftrag;
                        break;
                    }
                }
                if (OldAuftNr != AuftNr && AuftNr != "0")
                {
                    string hBemerk = e.MBericht.Params.EBHIST.Value.ToString().Trim();
                    if (hBemerk != null && hBemerk != "")
                    {
                        string strCssClassRow = "Auftnr_neu";
                        tr = new TableRow();
                        TableCell d1 = new TableCell();
                        TextBox tb1 = new TextBox();
                        tb1.Width = 200;
                        tb1.Text = AuftNr;
                        d1.HorizontalAlign = HorizontalAlign.Left;
                        d1.CssClass = strCssClassRow;
                        d1.Enabled = false;
                        d1.Font.Bold = true;
                        d1.Controls.Add(tb1);
                        tr.Cells.Add(d1);

                        TableCell d2 = new TableCell();
                        TextBox tb = new TextBox();
                        tb.Width = 700;
                        tb.Text = e.MBericht.Params.EBHIST.Value.ToString();
                        d2.HorizontalAlign = HorizontalAlign.Left;
                        d2.Font.Bold = true;
                        d2.Enabled = false;
                        d2.ForeColor = System.Drawing.Color.Black;
                        d2.Controls.Add(tb);
                        d2.CssClass = strCssClassRow;
                        tr.Cells.Add(d2);
                        tabBem.Rows.Add(tr);
                    }
                    OldAuftNr = AuftNr;
                }
            }
        }
        return tabBem;*/
    }
    //Defect #6060 - KFMBemerkung
    private Table KfmBemerkungfuerGenehmiger()
    {
        Table tabBem = new Table();
        TableRow HeaderRow = new TableRow();
        // Defect #6014 - neue Spalte hinzuf�gen - Projektname
        TableCell c3 = new TableCell();
        c3.Text = "Projekt";
        c3.Width = 200;
        c3.HorizontalAlign = HorizontalAlign.Center;
        c3.CssClass = "TabHeader";
        c3.Font.Bold = true;

        TableCell c1 = new TableCell();
        c1.Text = "AuftragNr";
        c1.HorizontalAlign = HorizontalAlign.Center;
        c1.Width = 150;
        c1.CssClass = "TabHeader";
        c1.Font.Bold = true;

        TableCell c2 = new TableCell();
        c2.Text = "Bemerkung f�r Kunden";
        c2.Width = 687;
        c2.HorizontalAlign = HorizontalAlign.Center;
        c2.CssClass = "TabHeader";
        c2.Font.Bold = true;

        HeaderRow.Cells.Add(c3);
        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        tabBem.Rows.Add(HeaderRow);

        HeaderRow.Visible = false;
        TableRow tr;
        //string OldAuftNr = "-";
        //string AuftNr = "0";


        //Defect #6014 - pro EB eine Zeile in der Bemerkungstabelle schreiben
        foreach (dbMontBer mber in KGMonat.Monteur.MBerichte)
        {
            string interneBemerkung = mber.Params.KFMBEMERKUNG.Value.ToString().Trim();
            string projektName = mber.Projekt.Params.NAME.Value.ToString().Trim();

            if (interneBemerkung != null && interneBemerkung != "" && projektName != null && projektName != "")
            {
                HeaderRow.Visible = true;
                ArrayList listAuftrag = new ArrayList();
                string auftragNr = "";
                foreach (dbArbTag at in mber.Tage)
                {
                    foreach (dbArbZeit az in at.Zeiten)
                    {
                        if (az.Params is dbAZ_KALTAGParams)
                            continue;
                        if (az.GKAuftragNR != ""
                            && Convert.ToInt32((az.Params as dbAZ_ARBZEITParams).EBID.Value) == Convert.ToInt32(mber.Params.EBID.Value)
                            && listAuftrag.BinarySearch(az.GKAuftragNR) < 0)
                        {
                            listAuftrag.Add(az.GKAuftragNR);
                            listAuftrag.Sort();
                        }
                    }
                }
                foreach (string s in listAuftrag)
                {
                    if (auftragNr != "")
                        auftragNr += " / ";
                    auftragNr += s;
                }

                string strCssClassRow = "Auftnr_neu";
                tr = new TableRow();

                TableCell d3 = new TableCell();
                //TextBox tb3 = new TextBox();
                Label tb3 = new Label();
                tb3.Width = 200;
                tb3.Text = projektName;
                d3.HorizontalAlign = HorizontalAlign.Left;
                d3.CssClass = strCssClassRow;
                //d3.Enabled = false;
                //d3.Font.Bold = true;
                d3.Controls.Add(tb3);
                tr.Cells.Add(d3);

                TableCell d1 = new TableCell();
                //TextBox tb1 = new TextBox();
                Label tb1 = new Label();
                tb1.Width = 150;
                tb1.Text = auftragNr;
                d1.HorizontalAlign = HorizontalAlign.Left;
                d1.CssClass = strCssClassRow;
                //d1.Enabled = false;
                //d1.Font.Bold = true;
                d1.Controls.Add(tb1);
                tr.Cells.Add(d1);

                TableCell d2 = new TableCell();
                //TextBox tb = new TextBox();
                Label tb = new Label();
                tb.Width = 687;
                tb.Text = interneBemerkung;
                d2.HorizontalAlign = HorizontalAlign.Left;
                //d2.Font.Bold = true;
                //d2.Enabled = false;
                d2.ForeColor = System.Drawing.Color.Black;
                d2.Controls.Add(tb);
                d2.CssClass = strCssClassRow;
                tr.Cells.Add(d2);
                tabBem.Rows.Add(tr);
            }
        }

        return tabBem;
    }

    protected void tbAn_Load(object sender, EventArgs e)
    {

    }

    // Beginn #5198 - negative Zeiten liefern keine Meldung in der Reiseabrechnung
    protected void cValDateValidation_ServerValidate(object source, ServerValidateEventArgs args)
    {
        bool valid;

        try
        {
            DateTime abfahrt = Convert.ToDateTime(tbDAb.TextBoxText + " " + tbAb.TextBoxText);
            DateTime ankunft = Convert.ToDateTime(tbDAn.TextBoxText + " " + tbAn.TextBoxText);

            if (ankunft < abfahrt)
            {
                valid = false;
            }
            else
            {
                valid = true;
            }
        }
        catch
        {
            valid = false;
        }

        args.IsValid = valid;
    }
    // Ende #5198
}
