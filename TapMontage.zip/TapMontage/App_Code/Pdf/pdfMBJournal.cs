//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : pdfMBJournals.cs
//
// Description  : Erzeugt einen PDF-Report mit einem Montagebericht als Inhalt;
//                Verwendung aus Erfassen/Ansehen Einsatzbericht
//
//=============== V1.0.0044 ===============================================
//
// Date         : 03.September 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-33
//                Belege, Zulagen auf MA-Ausdruck Einsatzbericht
//
//=============== V1.0.0043 ===============================================
//
// Date         : 15.Juli 2008
// Author       : Frantisek Sabol
// Defect#      : 6073
//                Anpassungen Layout analog Kundenbericht 
//
//=============== V1.0.0042 ===============================================
//
// Date         : 18.Juni 2008
// Author       : Frantisek Sabol
// Defect#      : 6074
//                Alle MA Belege Ausdrucken durch ein Knopfdruck
//
//=============== V1.0.0039 ===============================================
//
// Date         : 25.April 2008
// Author       : Joldic Dzevad
// Defect#      : 5901
//                Layout anpassung an neues objekt 
//
//=============== V1.0.0029 ===================================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

using System;
using System.Drawing;
using System.Collections;
using TapMontage.dbObjects;
using Root.Reports;

namespace TapMontage.Pdf
{
    /// <summary>
    /// Summary description for pdfMBJournal
    /// Erzeugt einen PDF-Report mit einem Montagebericht als Inhalt
    /// Verwendung aus Erfassen/Ansehen Einsatzbericht
    /// </summary>
    public class pdfMBJournal : Report
    {

        private class RepRow
        {
            public string Datum;
            public string Kommen;
            public string Gehen;
            public string StdNorm;
            public string Std50;
            public string Std100;
            //public string StdSumme; //defect #5901 - die summe wird nicht mehr angezeigt
            public string StdReise; //defect #5901 - Reisestunden werden bei genehmigten EB angezeigt
            public string Typ;
            public string Lohnart;

            public RepRow(DateTime datum, DateTime kommen, DateTime gehen, double norm, double ue50, double ue100, dbArbZeit.ArbZeitType type, string lohnart)
            {
                string[] t = new string[] { "So.", "Mo.", "Di.", "Mi.", "Do.", "Fr.", "Sa." };
                Datum = ((datum == ParamVal.Date0) ? "" : datum.ToString("dd.MM.")+" "+t[(int)datum.DayOfWeek]);
                Kommen = (kommen.ToShortTimeString() == "00:00" ? "" : kommen.ToShortTimeString());
                Gehen = (gehen.ToShortTimeString() == "00:00" ? "" : gehen.ToShortTimeString());
                double summe = norm + ue50 + ue100;

                if (type != dbArbZeit.ArbZeitType.ReiseVorherNachher)
                {
                    StdNorm = (((norm.ToString("N") == "0,00") | (norm.ToString("N") == "0.00")) ? "" : norm.ToString("N"));
                    Std50 = (((ue50.ToString("N") == "0,00") | (ue50.ToString("N") == "0.00")) ? "" : ue50.ToString("N"));
                    Std100 = (((ue100.ToString("N") == "0,00") | (ue100.ToString("N") == "0.00")) ? "" : ue100.ToString("N"));
                    //StdSumme = (((summe.ToString("N") == "0,00") | (summe.ToString("N") == "0.00")) ? "" : summe.ToString("N"));
                    StdReise = "";
                }
                else
                {
                    //StdSumme = StdNorm = Std50 = Std100 = "";
                    StdReise = (((summe.ToString("N") == "0,00") | (summe.ToString("N") == "0.00")) ? "" : summe.ToString("N"));
                }

                switch (type)
                {
                    case dbArbZeit.ArbZeitType.gk:
                        Typ = "GK/Innenauftrag";
                        break;
                    case dbArbZeit.ArbZeitType.gtAbsenz:
                        Typ = "GT-Absenz";
                        break;
                    case dbArbZeit.ArbZeitType.produktiv:
                        Typ = "produktiv";
                        break;
                    case dbArbZeit.ArbZeitType.ReiseInDienstzeit:
                        Typ = "Reise in Dienstzeit";
                        break;
                    case dbArbZeit.ArbZeitType.ReiseVorherNachher:
                        Typ = "Reise vor/nach Dienstzeit";
                        break;
                    case dbArbZeit.ArbZeitType.stdAbsenz:
                        Typ = "STD-Absenz";
                        break;
                    case dbArbZeit.ArbZeitType.alle:
                        Typ = "";
                        break;
                }
                Lohnart = lohnart;
            }
        }

        ArrayList Zeiten = new ArrayList();

        //Konstante f�r A4-Hoch im mm
        private Double MarginLeft = 20;
        //list-konstanten
        private Double PosLeft = 20;
        private Double PosTop = 24;
        private Double PosBottom = 278;

        Double rX = 10;
        Double rXr = 40;
        Double rY = 20;

        TableLayoutManager llm;
        TableLayoutManager.Column cCounter; //TAPM-33 - Z�hler bei KFZ Daten
        TableLayoutManager.Column cDatum;
        TableLayoutManager.Column cKommen;
        TableLayoutManager.Column cGehen;
        TableLayoutManager.Column cStdNorm;
        TableLayoutManager.Column cStdUe50;
        TableLayoutManager.Column cStdUe100;
        // TableLayoutManager.Column cStdSumme; // Defect #5901 Summe wird nicht mehr angezeigt
        TableLayoutManager.Column cReiseStd; // Defect #5901 neue Spalte Reise Stunden
        TableLayoutManager.Column cTyp;
        TableLayoutManager.Column cLohnart;

        // 6073
        TableLayoutManager zulagenlm;
        TableLayoutManager.Column cAus_Zulage;
        TableLayoutManager.Column cAnzahl;
        TableLayoutManager.Column cAuftragNr;
        TableLayoutManager bemerkunglm;
        TableLayoutManager.Column cBemerkung;
        TableLayoutManager kfzlm;
        //TableLayoutManager.Column cKFZ;
        //TableLayoutManager.Column cKFZKZ;
        TableLayoutManager.Column cGefKM;
        //TableLayoutManager.Column cABKM;
        TableLayoutManager.Column cMitFahrer;
        TableLayoutManager.Column cSchwerGP;
        TableLayoutManager barauslagenlm;
        TableLayoutManager.Column cAuslagenart;
        TableLayoutManager.Column cBetrag;
        TableLayoutManager absenzenlm;
        TableLayoutManager.Column cAbsenzart;

        FontDef fd;
        FontProp fp;
        FontProp fp_bold;
        FontProp fp_colHeader;

        bool headPro = false;
        bool newPage = false;
        bool newPage_zul = false;
        bool newPage_bem = false;
        bool newPage_kfz = false;
        bool newPage_bar = false;
        bool newPage_gta = false;
        public int tmpPageCount = 0;

        public dbMontBer MBericht;
        public ArrayList alleMBerichte;
        public int newMB = 0;

        // Defect# 6074
        public pdfMBJournal(ArrayList mBerichtListe)
        {
            fd = new FontDef(this, FontDef.StandardFont.Helvetica);
            fp = new FontPropMM(fd, 2);
            fp_bold = new FontPropMM(fd, 2);
            fp_bold.bBold = true;
            fp_colHeader = new FontPropMM(fd, 3);
            fp_colHeader.bBold = true;
            fp_colHeader.bUnderline = true;


            alleMBerichte = mBerichtListe;
            
      }

        public pdfMBJournal(dbMontBer mBericht)
        {
            MBericht = mBericht;
            fd = new FontDef(this, FontDef.StandardFont.Helvetica);
            fp = new FontPropMM(fd, 2);
            fp_bold = new FontPropMM(fd, 2);
            fp_bold.bBold = true;
            fp_colHeader = new FontPropMM(fd, 3);
            fp_colHeader.bBold = true;
            fp_colHeader.bUnderline = true;
        }
        protected override void Create()
        {

            // Defect# 6074
            foreach (dbMontBer m in alleMBerichte)
            {
                MBericht = m;
                if (newMB++ > 0)
                {
                    headPro = false;
                    Zeiten.Clear();
                    newPage_zul = false;
                    newPage_bem = false;
                    newPage_kfz = false;
                    newPage_bar = false;
                    newPage_gta = false;
                    tmpPageCount = iPageCount;
                }

                using (llm = new TableLayoutManager(fp_bold))
                {
                    llm.rContainerHeightMM = PosBottom - PosTop - 26;  // set height of table
                    cDatum = new TableLayoutManager.ColumnMM(llm, "Datum", 17);
                    cDatum.cellDef.rAlignH = RepObj.rAlignLeft;
                    cKommen = new TableLayoutManager.ColumnMM(llm, "Kommen", 15);
                    cKommen.cellDef.rAlignH = RepObj.rAlignLeft;
                    cGehen = new TableLayoutManager.ColumnMM(llm, "Gehen", 15);
                    cGehen.cellDef.rAlignH = RepObj.rAlignLeft;
                    cStdNorm = new TableLayoutManager.ColumnMM(llm, "NormStd", 15);
                    cStdNorm.cellDef.rAlignH = RepObj.rAlignRight;
                    cStdUe50 = new TableLayoutManager.ColumnMM(llm, "�Std 50%", 15);
                    cStdUe50.cellDef.rAlignH = RepObj.rAlignRight;
                    cStdUe100 = new TableLayoutManager.ColumnMM(llm, "�Std 100%", 17);
                    cStdUe100.cellDef.rAlignH = RepObj.rAlignRight;
                    // cStdSumme = new TableLayoutManager.ColumnMM(llm, "Summe", 15);
                    // cStdSumme.cellDef.rAlignH = RepObj.rAlignRight;
                    cReiseStd = new TableLayoutManager.ColumnMM(llm, "Reisestunden", 21);
                    cReiseStd.cellDef.rAlignH = RepObj.rAlignRight;
                    cTyp = new TableLayoutManager.ColumnMM(llm, "Typ", 35);
                    cTyp.cellDef.rAlignH = RepObj.rAlignLeft;
                    cLohnart = new TableLayoutManager.ColumnMM(llm, "Schl�ssel", 30);
                    cLohnart.cellDef.rAlignH = RepObj.rAlignLeft;

                    llm.eNewContainer += new TlmBase.NewContainerEventHandler(llm_eNewContainer);

                    //Defect #5901 - keine neu berechnugn der Stunden, sondern, nur auslesen aus der DB




                    dbReadOnly dbEntry = new dbReadOnly(MBericht.MinDatum, (int)MBericht.Params.PERSKEY.Value, (int)MBericht.Params.EBID.Value);
                    ArrayList al = dbEntry.SelectArbzeiten();
                    double gesNormStd = 0;
                    double gesU50Std = 0;
                    double gesU100Std = 0;

                    DateTime tag = MBericht.MinDatum;
                    while (tag.Month == MBericht.MinDatum.Month)
                    {
                        bool written = false;
                        foreach (dbArbeitsZeit az in al)
                        {
                            if (az.Datum == tag)
                            {
                                if (az.Normstd != 0 || az.Uestd50 != 0 || az.Uestd100 != 0)
                                {
                                    written = true;
                                    //Defect #6073 - ZA wird angezeigt aber die stunden werden ignoriert
                                    if (az.Stdabsenzid == 110)
                                    {
                                        az.Normstd = az.Uestd50 = az.Uestd100 = 0;
                                    }
                                    if (az.Kzaz != "R")
                                    {
                                        gesNormStd += az.Normstd;
                                        gesU50Std += az.Uestd50;
                                        gesU100Std += az.Uestd100;
                                    }
                                    Zeiten.Add(new RepRow(az.Datum, az.Beginn, az.Ende, az.Normstd, az.Uestd50, az.Uestd100, az.azTyp, az.Stdabsenztxt == "" ? az.Leistart : az.Stdabsenztxt));
                                }
                            }
                        }
                        if (!written)
                            Zeiten.Add(new RepRow(tag, ParamVal.Date0, ParamVal.Date0, 0, 0, 0, dbArbZeit.ArbZeitType.alle, ""));
                        tag = tag.AddDays(1);
                    }
                    /*
                    foreach (dbArbTag at in MBericht.Tage)
                    {
                        DateTime Tag = at.TagesDatum;
                        bool written = false;
                        foreach (dbArbZeit az in at.Zeiten) //nur Zeiten aus diesem Einsatzbericht, keine GT-Absenzen!
                            if ((!az.Deleted) && (az.Params is dbAZ_ARBZEITParams) && ((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == (int)MBericht.Params.EBID.Value))
                            {
                                written = true;
                                if (az.Params is dbAZ_ARBZEITParams)
                                {
                                    string stdabs = " ";
                                    foreach (ValuePair vp in MBericht.Bearbeiter.Commons.STDAbsenzID)
                                        if (vp.Value == az.STDAbsenzID) stdabs = vp.Text;
                                    Zeiten.Add(new RepRow((written ? at.TagesDatum : ParamVal.Date0), az.Kommen, az.Gehen, az.NormStunden, az.UEStunden50, az.UEStunden100, az.ZeitTyp, az.Leistart + stdabs));
                                }
                            }
                        if (!written)
                            Zeiten.Add(new RepRow(at.TagesDatum, ParamVal.Date0, ParamVal.Date0, 0, 0, 0, dbArbZeit.ArbZeitType.alle, ""));
                    }*/
                    foreach (RepRow r in Zeiten)
                    {
                        //falls nicht neue Seite, neue Zeile
                        if (!newPage) llm.NewRow();
                        WriteColumnHeaders();
                        cDatum.Add(new RepString(fp, r.Datum));
                        cKommen.Add(new RepString(fp, r.Kommen));
                        cGehen.Add(new RepString(fp, r.Gehen));
                        cStdNorm.Add(new RepString(fp, r.StdNorm));
                        cStdUe50.Add(new RepString(fp, r.Std50));
                        cStdUe100.Add(new RepString(fp, r.Std100));
                        // cStdSumme.Add(new RepString(fp, r.StdSumme));
                        cReiseStd.Add(new RepString(fp, r.StdReise));
                        cTyp.Add(new RepString(fp, r.Typ));
                        cLohnart.Add(new RepString(fp, r.Lohnart));
                    }
                    // Abschlie�end Summenzeile
                    if (!newPage) llm.NewRow();
                    WriteColumnHeaders();
                    cDatum.Add(new RepString(fp_bold, "Summe"));
                    cKommen.Add(new RepString(fp, ""));
                    cGehen.Add(new RepString(fp, ""));
                    cStdNorm.Add(new RepString(fp_bold, gesNormStd.ToString("N")));//MBericht.NormStunden.ToString("N")));
                    cStdUe50.Add(new RepString(fp_bold, gesU50Std.ToString("N")));// MBericht.UE50.ToString("N")));
                    cStdUe100.Add(new RepString(fp_bold, gesU100Std.ToString("N")));//MBericht.UE100.ToString("N")))  ;
                    // cStdSumme.Add(new RepString(fp_bold, (dbEntry.summeStdNorm + dbEntry.summeStd50 + dbEntry.summeStd50).ToString("N")));//MBericht.SummeStunden.ToString("N")));
                    cReiseStd.Add(new RepString(fp_bold, dbEntry.summeRZ.ToString("N")));
                    cTyp.Add(new RepString(fp, ""));
                    cLohnart.Add(new RepString(fp, ""));
                    llm.container_Cur.rHeightMM = llm.rCurY_MM + 6;

                    //page_Cur.AddMM(MarginLeft, PosTop + 26 + llm.rCurY_MM + 12, new RepString(fp, "Ausdruck Einsatzberichtbericht " + MBericht.MinDatum.ToString("yyyy/MM")));

                }

                //6073 Tabelle Aus-ZuLagen
                dbReadOnly dbEntry2 = new dbReadOnly(MBericht.MinDatum, (int)MBericht.Params.PERSKEY.Value, (int)MBericht.Params.EBID.Value, Convert.ToInt32(MBericht.Params.EBSTAT.Value));
                ArrayList al2 = dbEntry2.SelectAusZulagen();

                rY += llm.rCurY_MM + 8;

                if (al2.Count > 0)
                {
                    using (zulagenlm = new TableLayoutManager(fp_bold))
                    {
                        zulagenlm.rContainerHeightMM = PosBottom - rY;
                        cAus_Zulage = new TableLayoutManager.ColumnMM(zulagenlm, "Aus/Zulage", 62);
                        cAus_Zulage.cellDef.rAlignH = RepObj.rAlignLeft;
                        cAnzahl = new TableLayoutManager.ColumnMM(zulagenlm, "Anzahl", 15);
                        cAnzahl.cellDef.rAlignH = RepObj.rAlignCenter;
                        cAuftragNr = new TableLayoutManager.ColumnMM(zulagenlm, "AuftragNr", 38);
                        cAuftragNr.cellDef.rAlignH = RepObj.rAlignLeft;

                        zulagenlm.eNewContainer += new TlmBase.NewContainerEventHandler(zulagelm_eNewContainer);


                        foreach (dbReadOnlyAusZulage azl in al2)
                        { 
                            zulagenlm.NewRow();
                            
                            cAus_Zulage.Add(new RepString(fp, azl.Lohnarttxt.ToString()));
                            cAnzahl.Add(new RepString(fp, azl.Anzahl.ToString()));
                            cAuftragNr.Add(new RepString(fp, azl.Ktobj.ToString()));
                        }

                        //zulagenlm.container_Cur.rHeightMM = zulagenlm.rCurY_MM + 6;
                        zulagenlm.tableHeight = TlmBase.TableHeight.AdjustLast;

                    }
                    
                    rY += zulagenlm.rCurY_MM + 6;
                }

                // Tabelle Barauslagen
                ArrayList alBarauslagen = dbEntry2.SelectBarauslagen();
                if (alBarauslagen.Count > 0)
                {
                    using (barauslagenlm = new TableLayoutManager(fp_bold))
                    {
                        barauslagenlm.rContainerHeightMM = PosBottom - rY;
                        cDatum = new TableLayoutManager.ColumnMM(barauslagenlm, "Datum", 30);
                        cDatum.cellDef.rAlignH = RepObj.rAlignLeft;
                        cAuslagenart = new TableLayoutManager.ColumnMM(barauslagenlm, "Auslagenart", 64);
                        cAuslagenart.cellDef.rAlignH = RepObj.rAlignLeft;
                        cAnzahl = new TableLayoutManager.ColumnMM(barauslagenlm, "Anzahl", 21);
                        cAnzahl.cellDef.rAlignH = RepObj.rAlignCenter;
                        cBetrag = new TableLayoutManager.ColumnMM(barauslagenlm, "Betrag", 21);
                        cBetrag.cellDef.rAlignH = RepObj.rAlignRight;

                        barauslagenlm.eNewContainer += new TlmBase.NewContainerEventHandler(barauslagenlm_eNewContainer);


                        foreach (dbReadOnlyBarauslagen barl in alBarauslagen)
                        {
                            barauslagenlm.NewRow();

                            cDatum.Add(new RepString(fp, barl.Datum.ToString()));
                            cAuslagenart.Add(new RepString(fp, barl.Auslagenart.ToString()));
                            cAnzahl.Add(new RepString(fp, barl.Anzahl.ToString()));
                            cBetrag.Add(new RepString(fp, barl.Betrag.ToString("f")));//TAPM-33 Festkommazahl (fixed point)
                        }

                        barauslagenlm.tableHeight = TlmBase.TableHeight.AdjustLast;

                    }
                    
                    rY += barauslagenlm.rCurY_MM + 6;
                }


                // Tabelle KFZ
                ArrayList alKFZ = dbEntry2.SelectKFZ();
                if (alKFZ.Count > 0)
                {
                    using (kfzlm = new TableLayoutManager(fp_bold))
                    {
                        kfzlm.rContainerHeightMM = PosBottom - rY;
                        //TAPM-33 damit man die Tabelle als KFZ Daten erkennen kann
                        cCounter = new TableLayoutManager.ColumnMM(kfzlm, "KFZ Daten", 17);
                        cCounter.cellDef.rAlignH = RepObj.rAlignRight;
                        cDatum = new TableLayoutManager.ColumnMM(kfzlm, "Datum", 47);
                        cDatum.cellDef.rAlignH = RepObj.rAlignLeft;
                        //cKFZ = new TableLayoutManager.ColumnMM(kfzlm, "KfzTyp", 35);
                        //cKFZ.cellDef.rAlignH = RepObj.rAlignLeft;
                        //cKFZKZ = new TableLayoutManager.ColumnMM(kfzlm, "Pol. Kennz.", 25);
                        //cKFZKZ.cellDef.rAlignH = RepObj.rAlignLeft;
                        cGefKM = new TableLayoutManager.ColumnMM(kfzlm, "KM", 15);
                        cGefKM.cellDef.rAlignH = RepObj.rAlignLeft;
                        //cABKM = new TableLayoutManager.ColumnMM(kfzlm, "Km-Stand", 25);
                        //cABKM.cellDef.rAlignH = RepObj.rAlignLeft;
                        cMitFahrer = new TableLayoutManager.ColumnMM(kfzlm, "Mitfahrer", 15);
                        cMitFahrer.cellDef.rAlignH = RepObj.rAlignLeft;
                        cSchwerGP = new TableLayoutManager.ColumnMM(kfzlm, "Schwergep�ck", 38);
                        cSchwerGP.cellDef.rAlignH = RepObj.rAlignLeft;


                        kfzlm.eNewContainer += new TlmBase.NewContainerEventHandler(kfzlm_eNewContainer);

                        int counter = 0;
                        foreach (dbReadOnlyKFZ kfz in alKFZ)
                        {
                            kfzlm.NewRow();
                            counter++;
                            cCounter.Add( new RepString(fp, counter.ToString() + "."));
                            cDatum.Add(new RepString(fp, kfz.rDatum.ToString()));
                            //cKFZ.Add(new RepString(fp, kfz.KFZ.ToString()));
                            //cKFZKZ.Add(new RepString(fp, kfz.KFZKZ.ToString()));
                            cGefKM.Add(new RepString(fp, kfz.GefKM.ToString()));
                            //cABKM.Add(new RepString(fp, kfz.ABKM.ToString()));
                            cMitFahrer.Add(new RepString(fp, kfz.Mitfahrer.ToString()));
                            cSchwerGP.Add(new RepString(fp, kfz.SchwerGP.ToString()));
                        }

                        kfzlm.tableHeight = TlmBase.TableHeight.AdjustLast;

                    }

                    rY += kfzlm.rCurY_MM + 6;

                }

                // Tabelle GTA
                ArrayList alGTA = dbEntry2.SelectGTAbsenzen();

                if (alGTA.Count > 0)
                {
                    using (absenzenlm = new TableLayoutManager(fp_bold))
                    {
                        absenzenlm.rContainerHeightMM = PosBottom - rY;
                        cDatum = new TableLayoutManager.ColumnMM(absenzenlm, "Datum", 30);
                        cDatum.cellDef.rAlignH = RepObj.rAlignLeft;
                        cAbsenzart = new TableLayoutManager.ColumnMM(absenzenlm, "Ganzt�gige Absenz", 47);
                        cAbsenzart.cellDef.rAlignH = RepObj.rAlignLeft;

                        absenzenlm.eNewContainer += new TlmBase.NewContainerEventHandler(absenzlm_eNewContainer);


                        foreach (dbReadOnlyGTA gta in alGTA)
                        {
                            absenzenlm.NewRow();

                            cDatum.Add(new RepString(fp, gta.Datum.ToString()));
                            cAbsenzart.Add(new RepString(fp, gta.Absenzart.ToString()));
                        }

                        absenzenlm.tableHeight = TlmBase.TableHeight.AdjustLast;

                    }

                    rY += absenzenlm.rCurY_MM + 6;
                }


                // Tabelle Bemerkung
                String readOnlyBemerkung = dbEntry2.SelectBemerkung();

                if (readOnlyBemerkung != "")
                {
                    using (bemerkunglm = new TableLayoutManager(fp_bold))
                    {
                        bemerkunglm.rContainerHeightMM = PosBottom - rY;
                        
                        cBemerkung = new TableLayoutManager.ColumnMM(bemerkunglm, "Bemerkung", 180);
                        cBemerkung.cellDef.rAlignH = RepObj.rAlignLeft;
                        cBemerkung.cellDef.textMode = TlmBase.TextMode.MultiLine;
                        
                        bemerkunglm.eNewContainer += new TlmBase.NewContainerEventHandler(bemerkunglm_eNewContainer);

                        bemerkunglm.NewRow();
                        cBemerkung.Add(new RepString(fp, readOnlyBemerkung));
                        bemerkunglm.tableHeight = TlmBase.TableHeight.AdjustLast;
                    }

                    rY += bemerkunglm.rCurY_MM + 6;
                }

                page_Cur.AddMM(MarginLeft, rY, new RepString(fp, "Ausdruck Einsatzbericht " + MBericht.MinDatum.ToString("yyyy/MM")));


            }  // end for each
        }

        private void WriteColumnHeaders()
        {
            /*if (false) //nur bei ListLayoutManager notwendig
            {
                cDatum.Add(new RepString(fp_bold, "Datum"));
                cKommen.Add(new RepString(fp_bold, "Kommen"));
                cGehen.Add(new RepString(fp_bold, "Gehen"));
                cStdNorm.Add(new RepString(fp_bold, "Std.Norm"));
                cStdUe50.Add(new RepString(fp_bold, "�Std 50%"));
                cStdUe100.Add(new RepString(fp_bold, "�Std 100%"));
                // cStdSumme.Add(new RepString(fp_bold, "Std. Summe"));
                cReiseStd.Add(new RepString(fp_bold, "Reise Stunden"));
                cTyp.Add(new RepString(fp_bold, "Typ"));
                cLohnart.Add(new RepString(fp_bold, "Schl�ssel"));
            }*/
            llm.NewRow();
            newPage = false;
        }
        
        void llm_eNewContainer(object oSender, TlmBase.NewContainerEventArgs ea)
        {
            new Page(this);
            rY = WriteHeader(PosTop);
            ea.tlm.rContainerHeightMM = PosBottom - rY;
            page_Cur.AddMM(PosLeft, rY, ea.container);
            newPage = true;
        }
        // begin 6073
        void zulagelm_eNewContainer(object oSender, TlmBase.NewContainerEventArgs ea)
        {
            if (newPage_zul || (PosBottom - rY) < 12)
            {
                new Page(this);
                rY = PosTop;
                page_Cur.AddMM(180, rY, new RepString(fp, "Seite: " + (iPageCount - tmpPageCount).ToString()));
                rY += 4;
            }
            ea.tlm.rContainerHeightMM = PosBottom - rY;
            ea.tlm.container_Cur.rHeightMM = PosBottom - rY;
            page_Cur.AddMM(PosLeft, rY, ea.container);
            newPage_zul = true;
        }

        void barauslagenlm_eNewContainer(object oSender, TlmBase.NewContainerEventArgs ea)
        {
            if (newPage_bar || (PosBottom - rY) < 12)
            {
                new Page(this);
                rY = PosTop;
                page_Cur.AddMM(180, rY, new RepString(fp, "Seite: " + (iPageCount - tmpPageCount).ToString()));
                rY += 4;
            }
            ea.tlm.rContainerHeightMM = PosBottom - rY;
            ea.tlm.container_Cur.rHeightMM = PosBottom - rY;
            page_Cur.AddMM(PosLeft, rY, ea.container);
            newPage_bar = true;
        }

        void absenzlm_eNewContainer(object oSender, TlmBase.NewContainerEventArgs ea)
        {
            if (newPage_gta || (PosBottom - rY) < 12)
            {
                new Page(this);
                rY = PosTop;
                page_Cur.AddMM(180, rY, new RepString(fp, "Seite: " + (iPageCount - tmpPageCount).ToString()));
                rY += 4;
            }
            ea.tlm.rContainerHeightMM = PosBottom - rY;
            ea.tlm.container_Cur.rHeightMM = PosBottom - rY;
            page_Cur.AddMM(PosLeft, rY, ea.container);
            newPage_gta = true;
        }

        void bemerkunglm_eNewContainer(object oSender, TlmBase.NewContainerEventArgs ea)
        {
            if (newPage_bem || (PosBottom - rY) < 12)
            {
                new Page(this);
                rY = PosTop;
                page_Cur.AddMM(180, rY, new RepString(fp, "Seite: " + (iPageCount - tmpPageCount).ToString()));
                rY += 4;
            }
            ea.tlm.rContainerHeightMM = PosBottom - rY;
            ea.tlm.container_Cur.rHeightMM = PosBottom - rY;
            page_Cur.AddMM(PosLeft, rY, ea.container);
            newPage_bem = true;
        }

        void kfzlm_eNewContainer(object oSender, TlmBase.NewContainerEventArgs ea)
        {
            if (newPage_kfz || (PosBottom - rY) < 12)
            {
                new Page(this);
                rY = PosTop;
                page_Cur.AddMM(180, rY, new RepString(fp, "Seite: " + (iPageCount - tmpPageCount).ToString()));
                rY += 4;
            }
            ea.tlm.rContainerHeightMM = PosBottom - rY;
            ea.tlm.container_Cur.rHeightMM = PosBottom - rY;
            page_Cur.AddMM(PosLeft, rY, ea.container);
            newPage_kfz = true;
        }

        // ende 6073

        private double WriteHeader(Double startY)
        {
            page_Cur.AddMM(180,startY, new RepString(fp, "Seite: " + (iPageCount - tmpPageCount).ToString()));
            rY = startY+4;
            if (!headPro)
            {
                FontProp fp_Title = new FontPropMM(fd, 4);
                rX = MarginLeft;
                page_Cur.AddMM(rX, rY, new RepString(fp_Title, "Ausdruck Einsatzbericht "+MBericht.MinDatum.ToString("yyyy/MM")));
                rY += 10;
                page_Cur.AddMM(rX, rY, new RepString(fp, "Mitarbeiter"));
                page_Cur.AddMM(rXr, rY, new RepString(fp_bold, MBericht.Bearbeiter.Params.NACHNAME.Value.ToString() + ", " + MBericht.Bearbeiter.Params.VORNAME.Value.ToString() + " (P:" + Convert.ToString(MBericht.Bearbeiter.Params.PERSNR.Value) + "K:" + MBericht.Bearbeiter.TechParams.KST.Value.ToString() + ")"));
                rY += 4;
                page_Cur.AddMM(rX, rY, new RepString(fp, "Baustelle"));
                page_Cur.AddMM(rXr, rY, new RepString(fp_bold, MBericht.Projekt.Baustelle.Params.NAME.Value.ToString() + "(" + MBericht.Projekt.Baustelle.Params.BAUNR.Value.ToString() + ")"));
                rY += 4;
                page_Cur.AddMM(rX, rY, new RepString(fp, "Projekt"));
                page_Cur.AddMM(rXr, rY, new RepString(fp_bold, MBericht.Projekt.Params.NAME.Value.ToString()+"("+MBericht.Projekt.Params.KTOBJ.Value.ToString()+")"));
                rY += 4;
                headPro = true;
                return startY + 26;
            }
            return rY;
            
        }
    }
}