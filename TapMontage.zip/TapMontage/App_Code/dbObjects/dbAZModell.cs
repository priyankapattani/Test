//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbAZModell.cs
//
// Description  : SQL-Zugriffe auf AZM
//
//=============== V1.0.0037 ===============================================
//
// Date         : 14.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//=============== V1.0.0027 ===============================================
//
// Date         : 09. Mai 2007
// Author       : Caleb Gebhardt
// Defect#      : 5008
//
// Die Ermittlung der Fenstertage basiert im Moment auf den Eintr�gen in 
// ALLG_Feiertage aus den AZM Stammdaten, es soll dazu auch der jeweilige Status 
// (welche Feiertage gelten f�r diesen Mitarbeiter) ausgewertet werden.
//
//--------------- V1.0.0026 ---------------------------------------------------------------------------
//
// Date         : 02. Mai 2007
// Author       : CG
// Defect#      : 5020,5029
//                Ges. Feiertage/rel. Feiertage/Fenstertage m�ssen wieder als solche im EB-Dialog 
//                gekennzeichnet (graue Markierung) werden.
//
//--------------- V1.0.0023 ---------------------------------------------------------------------------
//
// Date         : 21. M�rz 2007
// Author       : CL
// Defect#      : 4827
//                Ber�cksichtigung von Religionskennzeichen des Mitarbeiters und
//                Feiertags-Kennzeichen (Gesetzlich - Religi�s) beim Lesen der Feiertage
//
//--------------- V1.0.0022 ---------------------------------------------------------------------------
//
// Date         : 20. Februar 2007
// Author       : CG
// Defect#      : 4594
//                Erkennen von MA-Arbeitszeitmodellen, welche untermonatig beginnen bzw. enden
//
//--------------- V1.0.0018 ---------------------------------------------------------------------------
//
// Date         : 9. J�nner 2007
// Author       : CG
// Defect       : 4236
//                Die Tage 27.12.2006, 28.12.2006 und 29.12.2006 wurden nicht als Fenstertage
//                erkannt und werden in Zukunft als solche erkannt. 
//
// ----------------------------------------------------------------------------------------------------

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace TapMontage.dbObjects
{

    public class dbAZModellParams
    {
        public SqlParameter SYS_ID = new SqlParameter("@SYS_ID", (string) "");
        public SqlParameter AZ_Modell_Nummer = new SqlParameter("@AZ_Modell_Nummer", (string) "");
        public SqlParameter AZ_Portier = new SqlParameter("@AZ_Portier", (bool) false);
        public SqlParameter AZ_Tarif = new SqlParameter("@AZ_Tarif", (bool) false);
        public SqlParameter AZ_Normal_AZ = new SqlParameter("@AZ_Normal_AZ", Single.MinValue);
        public SqlParameter AZ_Bezeichnung = new SqlParameter("@AZ_Bezeichnung", (string) "");
        public SqlParameter AZ_Mutterschutz = new SqlParameter("@AZ_Mutterschutz", (bool) false);
        public SqlParameter AZ_Starres_Modell = new SqlParameter("@AZ_Starres_Modell", (bool) false);
        public SqlParameter AZ_Schicht = new SqlParameter("@AZ_Schicht", (bool) false);
        public SqlParameter AZ_Arbeitsplan = new SqlParameter("@AZ_Arbeitsplan", (string) "");
        public SqlParameter AZ_Teilzeit = new SqlParameter("@AZ_Teilzeit", (bool) false);
        public SqlParameter AZ_Toleranz = new SqlParameter("@AZ_Toleranz", int.MinValue);
        public SqlParameter AZ_Konti = new SqlParameter("@AZ_Konti", (bool) false);
        public SqlParameter AZ_WochenendZulage = new SqlParameter("@AZ_WochenendZulage", (bool) false);
        public SqlParameter AZ_ZusatzSchicht = new SqlParameter("@AZ_ZusatzSchicht", (bool) false);
        public SqlParameter AZ_Sonderfunktion = new SqlParameter("@AZ_Sonderfunktion", int.MinValue);
        public ArrayList List = new ArrayList();
        
        public dbAZModellParams()
        {
            List.Add(SYS_ID);
            List.Add(AZ_Modell_Nummer);
            List.Add(AZ_Portier);
            List.Add(AZ_Tarif);
            List.Add(AZ_Normal_AZ);
            List.Add(AZ_Bezeichnung);
            List.Add(AZ_Mutterschutz);
            List.Add(AZ_Starres_Modell);
            List.Add(AZ_Schicht);
            List.Add(AZ_Arbeitsplan);
            List.Add(AZ_Teilzeit);
            List.Add(AZ_Toleranz);
            List.Add(AZ_Konti);
            List.Add(AZ_WochenendZulage);
            List.Add(AZ_ZusatzSchicht);
            List.Add(AZ_Sonderfunktion);
            ParamVal.SetDefaultValues(List);
        }
    }
    /// <summary>
    /// dbAZModell enth�lt das zum Zeitpunkt ValidAtDate g�ltige Arbeitszeitmodell
    /// in dbAZModell.AZTage[dbAZTag.Sonntag..dbAZTag.Samstag] sind die Tage verf�gbar
    /// </summary>
    public class dbAZModell
    {
      public dbAZModellParams Params = new dbAZModellParams();
      public dbBearbeiter Bearbeiter;
      public DateTime ValidAt = DateTime.Now;

      private bool AllowUpdate = false;

      private const String strRelFtFlag = "R";        // Defect #4827: Flag f�r religi�sen Feiertag
      private const String stFnstFlag = "F";          // Defect #5008: Flag f�r Fensterfeiertage

      public ArrayList AZTage;

      public ArrayList Feiertage = new ArrayList();
      public ArrayList Fenstertage = new ArrayList();     // Defect #5008: Flag f�r Fensterfeiertage
      public bool Feiertag(DateTime Datum)
      {
        foreach (DateTime dt in Feiertage)
          // Defect 4236:
          //  Die Tage 27.12.2006, 28.12.2006 und 29.12.2006 wurden nicht als Fenstertage erkannt 
          //  und werden in Zukunft als solche erkannt.
          //
          if (dt.ToShortDateString() == Datum.ToShortDateString())    // Defect 4236
          // Defect 4236 beginn neu
          {
            /* Defect 5008: Kode Deaktivierung
            // Defect# 4236: CG - scheneller Schu�. In der Zukunft, Pr�fung aus der Tabelle ablesen. Fenstertage
            // sind keine Feiertage!!!!!
            if ((Datum.Day == 27 || Datum.Day == 28 || Datum.Day == 29) && (Datum.Year == 2006) && (Datum.Month == 12))
                return false;  // Fenstertage lt. AZM
            if ((Datum.Day == 25 && Datum.Month == 12 && Datum.Year == 2006))
                return true;
            */
            // Defect 5008
            return !Fenstertag(Datum);
            // ende 5008
          }

        return false;
      }

      // Defect #5008: �berrpr�fung, ob das �bergebene Datum
      //               ein Fenstertag ist oder nicht
      //

      public bool Fenstertag(DateTime Datum)
      {
        foreach (DateTime dt in Fenstertage)
          if (dt.ToShortDateString() == Datum.ToShortDateString())
          {
            return true;
          }
        return false;
      }

      public dbAZModell(dbBearbeiter bearb, DateTime ValidAtDate)
      {
        Params = new dbAZModellParams();
        Bearbeiter = bearb;
        ValidAt = ValidAtDate;
        if (bearb != null) Select();
      }
      public dbAZModell(dbBearbeiter bearb, int BerMonat)
      {
        Params = new dbAZModellParams();
        Bearbeiter = bearb;
        if (BerMonat.ToString().Length == 6)
          ValidAt = Convert.ToDateTime(BerMonat.ToString().Substring(0, 4) + "-" + BerMonat.ToString().Substring(4, 2) + "-01");
        else
          ValidAt = DateTime.Now;
        if (bearb != null) Select();
      }

      public bool MAMorgens(DateTime Kommen)
      {
        if (Kommen.Ticks == ParamVal.Date0.Ticks) return false;
        if (Feiertag(Kommen)) return true;
        dbAZTag t = (dbAZTag)AZTage[(int)Kommen.DayOfWeek];
        if (Convert.ToDateTime(t.Params.AZ_Begin.Value) == ParamVal.Date0) return true;
        if (Convert.ToDateTime(Kommen.ToShortDateString() + " " + Convert.ToDateTime(t.Params.AZ_Begin.Value).ToShortTimeString()).Ticks > Kommen.Ticks) return true;
        return false;
      }
      public bool MAAbends(DateTime Gehen)
      {
        if (Gehen.Ticks == ParamVal.Date0.Ticks) return false;
        if (Feiertag(Gehen)) return true;
        dbAZTag t = (dbAZTag)AZTage[(int)Gehen.DayOfWeek];
        if (Convert.ToDateTime(t.Params.AZ_Ende.Value) == ParamVal.Date0) return true;
        if (Convert.ToDateTime(Gehen.ToShortDateString() + " " + Convert.ToDateTime(t.Params.AZ_Ende.Value).ToShortTimeString()).Ticks < Gehen.Ticks) return true;
        return false;
      }
      public DateTime NazBeginn(DateTime Kommen)
      {
        if (Feiertag(Kommen)) return ParamVal.Date0;
        dbAZTag t = (dbAZTag)AZTage[(int)Kommen.DayOfWeek];
        if (Convert.ToDateTime(t.Params.AZ_Begin.Value) == ParamVal.Date0) return ParamVal.Date0;
        return Convert.ToDateTime(Kommen.ToShortDateString() + " " + Convert.ToDateTime(t.Params.AZ_Begin.Value).ToShortTimeString());
      }
      public DateTime NazEnde(DateTime Gehen)
      {
        if (Feiertag(Gehen)) return ParamVal.Date0;
        dbAZTag t = (dbAZTag)AZTage[(int)Gehen.DayOfWeek];
        if (Convert.ToDateTime(t.Params.AZ_Ende.Value) == ParamVal.Date0) return ParamVal.Date0;
        return Convert.ToDateTime(Gehen.ToShortDateString() + " " + Convert.ToDateTime(t.Params.AZ_Ende.Value).ToShortTimeString());
      }

      public bool Select()
      {
        DateTime dateFrom = ParamVal.Date0;
        DateTime dateTo = ParamVal.Date0;
        bool found = false;

        // CG- Defect 4594
        bool AZModellFound = false;
        DateTime xdateFrom = ParamVal.Date0;
        DateTime xdateTo = ParamVal.Date0;
        DateTime ydateTo = ParamVal.Date0;
        DateTime ydateFrom = ParamVal.Date0;
        int DateToInt;
        int DateFromInt;
        // Ende Defect 4594
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["AZMConnectionString"].ConnectionString))
        {
          try
          {
            cnx.Open();
            // Defect 5725, Config.Rowlock eingef�hrt
            // Defect 5771, Config.Nolock eingef�hrt
            string sql = "Select MA_AZ_g�ltig_von, MA_AZ_g�ltig_bis, AZ_Modell_nummer from MA_AZ_Modell " + Config.Nolock + " where MA_PersNummer = '";
            sql += Bearbeiter.Params.PERSNR.Value.ToString().Substring(2) + "' and MA_FKN = @MA_FKN " +
                   " ORDER BY MA_AZ_g�ltig_von ASC";
            using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436, using eingef�hrt
            {
              cmd.Parameters.Add(new SqlParameter("@MA_FKN", Bearbeiter.Firmenkennung));
              using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
              {
                // CG Defect-4594
                //while ((found == false) && rd.Read())
                //
                while (rd.Read())
                {
                  dateFrom = Convert.ToDateTime(rd.GetValue(0).ToString());
                  dateTo = Convert.ToDateTime(rd.GetValue(1).ToString());
                  if (dateFrom <= ValidAt && ValidAt <= dateTo)
                  {
                    found = true;
                    //CG Defect-4594
                    ydateFrom = dateFrom;
                    ydateTo = dateTo;
                    // Ende CG Defect-4594
                  }
                  //CG Defect-4594
                  DateToInt = dateTo.Year * 100 + dateTo.Month;
                  DateFromInt = dateFrom.Year * 100 + dateFrom.Month;
                  if (dateFrom.Month == ValidAt.Month && dateFrom.Year == ValidAt.Year && ValidAt <= dateTo ||
                     (ValidAt.AddMonths(-4) <= dateFrom && dateFrom <= DateTime.Now && Bearbeiter.EBSelectedMonat >= DateFromInt) ||
                     (ValidAt.AddMonths(-4) <= dateTo && dateTo <= DateTime.Now && Bearbeiter.EBSelectedMonat <= DateToInt))
                  {
                    // Validieren bis zu 4 Monaten zur�ck
                    // Wenn ein MA-AZModell f. Monat definiert wurde, nimmt es.
                    // 
                    if (!found)
                    {
                      AZModellFound = true;
                      xdateFrom = dateFrom;
                      xdateTo = dateTo;
                    }
                  }
                  // Ende Defect-4594
                }
                rd.Close();
              }
            }
            //CG Defect-4594
            if (found)
            {
              dateFrom = ydateFrom;
              dateTo = ydateTo;
            }
            else
              if (AZModellFound)
              {
                dateFrom = xdateFrom;
                dateTo = xdateTo;
              }

              else if (found == false && AZModellFound == false)
              {
                //CG Ende Defect-4594
                string ErrMsg = "\r\nKein Arbeitszeitmodell zum Mitarbeiter gefunden! -> Abbruch!" +
                                   "\r\nBitte wenden Sie sich an den Personalbetreuer.";
                Exception ex = new Exception(ErrMsg);
                throw ex;
              }
            // Defect 5725, Config.Rowlock eingef�hrt
            // Defect 5771, Config.Rowlock eingef�hrt
            sql = "Select SYS_ID, AZ_Modell_Nummer from MA_AZ_Modell " + Config.Nolock + " where MA_PersNummer = '";
            sql += Bearbeiter.Params.PERSNR.Value.ToString().Substring(2) +
                "' and MA_FKN = @MA_FKN and MA_AZ_g�ltig_von = @DATEFROM and MA_AZ_g�ltig_bis = @DATETO";
            using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436
            {
              cmd.Parameters.Add(new SqlParameter("@MA_FKN", Bearbeiter.Firmenkennung));
              cmd.Parameters.Add(new SqlParameter("@DATEFROM", dateFrom));
              cmd.Parameters.Add(new SqlParameter("@DATETO", dateTo));
              using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
              {
                if (rd.Read()) ParamVal.DataReader2Params(rd, Params.List);
                rd.Close();
              }
            }
            // Defect 5725, Config.Rowlock eingef�hrt
            // Defect 5771, Config.Nolock eingef�hrt
            sql = "select SYS_ID, AZ_Modell_Nummer, AZ_Portier, AZ_Tarif, AZ_Normal_AZ, AZ_Bezeichnung, AZ_Mutterschutz, AZ_Starres_Modell, AZ_Schicht, AZ_Arbeitsplan, AZ_Teilzeit, AZ_Toleranz, AZ_Konti, AZ_WochenendZulage, AZ_ZusatzSchicht, AZ_Sonderfunktion ";
            sql += " from AZ_Modelle " + Config.Nolock + " where SYS_ID = @SYS_ID and AZ_Modell_Nummer = @AZ_Modell_Nummer";
            using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436
            {
              cmd.Parameters.Add(Params.SYS_ID);
              cmd.Parameters.Add(Params.AZ_Modell_Nummer);
              using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
              {
                while (rd.Read())
                {
                  ParamVal.DataReader2Params(rd, Params.List);
                  AllowUpdate = true;
                }
                rd.Close();
              }
              cmd.Parameters.Remove(Params.SYS_ID);
              cmd.Parameters.Remove(Params.AZ_Modell_Nummer);
            }

            /* Beginn Defect #4827: Ber�cksichtigung der religi�sen Feiertage
             * und des Religionskennzeichens des Mitarbeiter in MA_STAMM */
            // sql = "select allg_datum from allg_feiertage where KAL_ID = (select MA_Kal_ID from ma_stamm where MA_Persnummer = '" + Bearbeiter.Params.PERSNR.Value.ToString().Substring(2) + "' and MA_FKN = '"+Bearbeiter.Firmenkennung+"')";
            // Defect 5725, Config.Rowlock eingef�hrt
            // Defect 5771, Config.Nolock eingef�hrt
            sql = "SELECT af.allg_datum, af.allg_bezeichnung, " +
                  "ma.ma_rel_feiertag FROM allg_feiertage af " + Config.Nolock + ", ma_stamm ma " + Config.Nolock +
                  "WHERE af.KAL_ID = ma.ma_kal_id " +
                  "AND ma.MA_Persnummer = '" +
                  Bearbeiter.Params.PERSNR.Value.ToString().Substring(2) +
                  "' and ma.MA_FKN = '" +
                  Bearbeiter.Firmenkennung + "'";
            // Ende Defect #4827
            using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436
            {
              using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
              {
                while (rd.Read())
                {
                  DateTime x = rd.GetDateTime(0);
                  /* Beginn Defect #4827: Die religi�sen Feiertage werden nur
                   * bei Mitarbeitern mit Rel-Flag = 1 ber�cksichtigt */
                  if ((rd.GetString(1) != strRelFtFlag) ||
                      (rd.GetString(1) == strRelFtFlag && rd.GetBoolean(2) == true))
                  {
                    // Defect 5008
                    if (rd.GetString(1) == stFnstFlag)
                    {
                      Fenstertage.Add(rd.GetDateTime(0));
                    }
                    // Ende 5008
                    Feiertage.Add(rd.GetDateTime(0));
                  } // Ende Defect #4827
                }
                rd.Close();
              }
            }
          }
          catch (Exception ex) { throw ex; }
          finally { cnx.Close(); }
        }
        if (AllowUpdate)
        {
          dbAZTag t = new dbAZTag(this, -11);
          AZTage = t.SelectWoche();
        }
        return AllowUpdate;
      }
    } //ende AZModell

    public class dbAZTagParams
    {
        public SqlParameter SYS_ID= new SqlParameter("@SYS_ID", (string) "");
        public SqlParameter AZ_Modell_Nummer = new SqlParameter("@AZ_Modell_Nummer",(string) "" );
        public SqlParameter AZ_Wochentag= new SqlParameter("@AZ_Wochentag", (Int16) 0);
        public SqlParameter AZ_Begin = new SqlParameter("@AZ_Begin", ParamVal.Date0);
        public SqlParameter AZ_Ende = new SqlParameter("@AZ_Ende", ParamVal.Date0);
        public SqlParameter AZ_PauseBeginn = new SqlParameter("@AZ_PauseBeginn", ParamVal.Date0);
        public SqlParameter AZ_PauseEnde = new SqlParameter("@AZ_PauseEnde", ParamVal.Date0);
        public SqlParameter AZ_Pausenzeit = new SqlParameter("@AZ_Pausenzeit", (Single) 0);
        public SqlParameter AZ_GAZKommenBegin = new SqlParameter("@AZ_GAZKommenBegin", ParamVal.Date0);
        public SqlParameter AZ_GAZKommenEnde = new SqlParameter("@AZ_GAZKommenEnde", ParamVal.Date0);
        public SqlParameter AZ_GAZGehenBeginn = new SqlParameter("@AZ_GAZGehenBeginn", ParamVal.Date0);
        public SqlParameter AZ_GAZ_GehenEnde = new SqlParameter("@AZ_GAZ_GehenEnde", ParamVal.Date0);
        public SqlParameter AZ_Blockzeit= new SqlParameter("@AZ_Blockzeit", (Single) 0);
        public SqlParameter AZ_SollarbeitStd = new SqlParameter("@AZ_SollarbeitStd", (Single) 0);
        public SqlParameter AZ_EinarbeitStd= new SqlParameter("@AZ_EinarbeitStd", (Single) 0);
        public SqlParameter AZ_PausenzeitBezahlt = new SqlParameter("@AZ_PausenzeitBezahlt", (bool) false);
        public SqlParameter AZ_ZusatzSchicht= new SqlParameter("@AZ_ZusatzSchicht", (bool) false);
        public ArrayList List = new ArrayList();

        public dbAZTagParams()
        {
            List.Add(SYS_ID);
            List.Add(AZ_Modell_Nummer);
            List.Add(AZ_Wochentag);
            List.Add(AZ_Begin);
            List.Add(AZ_Ende);
            List.Add(AZ_PauseBeginn);
            List.Add(AZ_PauseEnde);
            List.Add(AZ_Pausenzeit);
            List.Add(AZ_GAZKommenBegin);
            List.Add(AZ_GAZKommenEnde);
            List.Add(AZ_GAZGehenBeginn);
            List.Add(AZ_GAZ_GehenEnde);
            List.Add(AZ_Blockzeit);
            List.Add(AZ_SollarbeitStd);
            List.Add(AZ_EinarbeitStd);
            List.Add(AZ_PausenzeitBezahlt);
            List.Add(AZ_ZusatzSchicht);
            ParamVal.SetDefaultValues(List);
        }

    } //ende AZTagParams

    public class dbAZTag
    {
        public const Int16 Montag = 1;
        public const Int16 Dienstag = 2;
        public const Int16 Mittwoch = 3;
        public const Int16 Donnerstag = 4;
        public const Int16 Freitag = 5;
        public const Int16 Samstag = 6;
        public const Int16 Sonntag = 0;

        public dbAZModell AZModell;
        public dbAZTagParams Params = new dbAZTagParams();

        private bool AllowUpdate = false;

        public dbAZTag(dbAZModell AZMod, Int16 Tag)
        {
            AZModell = AZMod;
            if ((AZModell != null) && (Tag > 0))
            {
                Params.AZ_Wochentag.Value = Tag;
                Params.SYS_ID = AZModell.Params.SYS_ID;
                Params.AZ_Modell_Nummer = AZModell.Params.AZ_Modell_Nummer;
                Select();
            }
        }

      public bool Select()
      {
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["AZMConnectionString"].ConnectionString))
        {
          try
          {
            cnx.Open();
            // Defect 5725, Config.Rowlock eingef�hrt
            // Defect 5771, Config.Nolock eingef�hrt
            string sql = "select SYS_ID,AZ_Modell_Nummer,AZ_Wochentag,AZ_Begin,AZ_Ende,AZ_PauseBeginn,AZ_PauseEnde,AZ_Pausenzeit,AZ_GAZKommenBegin,AZ_GAZKommenEnde,AZ_GAZGehenBeginn,AZ_GAZ_GehenEnde,AZ_Blockzeit,AZ_SollarbeitStd,AZ_EinarbeitStd,AZ_PausenzeitBezahlt,AZ_ZusatzSchicht ";
            sql += " from AZ_Tag " + Config.Nolock + " where SYS_ID = @SYS_ID and AZ_Modell_Nummer = @AZ_Modell_Nummer and AZ_Wochentag = @AZ_Wochentag";
            using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436
            {
              cmd.Parameters.Add(Params.SYS_ID);
              cmd.Parameters.Add(Params.AZ_Modell_Nummer);
              cmd.Parameters.Add(Params.AZ_Wochentag);
              using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
              {
                cmd.Parameters.Remove(Params.SYS_ID);
                cmd.Parameters.Remove(Params.AZ_Modell_Nummer);
                cmd.Parameters.Remove(Params.AZ_Wochentag);
                while (rd.Read())
                {
                  ParamVal.DataReader2Params(rd, Params.List);
                  AllowUpdate = true;
                }
                rd.Close();
              }
            }
          }
          catch (Exception ex) { throw ex; }
          finally { cnx.Close(); }
        }
        return AllowUpdate;
      }

        public ArrayList SelectWoche()
        {
            ArrayList al = new ArrayList();
            for (Int16 WTag = 1; WTag <= 7; WTag++)
            {
                dbAZTag t = new dbAZTag(AZModell, WTag);
                al.Add(t);
            }
            return al;
        }
    }
}
