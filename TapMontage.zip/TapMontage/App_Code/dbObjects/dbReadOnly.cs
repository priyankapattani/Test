﻿//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbReadOnly.cs
//
// Description  : DB-Zugriffe für Arbeitszeiten
//
//=============== V1.2.0018 ===============================================
//
// Date         : 27.Novebmer 2013
// Author       : Joldic Dzevad
// Defect#      : TT-6685267
//                Betrag bei Barauslagen auf Decimal umwandeln (anstatt float)
//
//=============== V1.0.0044 ===============================================
//
// Date         : 02.September 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-33
//                Belege, Zulagen auf MA-Ausdruck Einsatzbericht
//
// Date         : 31.Juli 2008
// Author       : Joldic Dzevad
// Defect#      : xxxx
//                Auslagenart als Volltext statt Abkürzung aus der DB auslesen
//
//=============== V1.0.0043 ===============================================
//
// Date         : 15.Juli 2008
// Author       : Frantisek Sabol
// Defect#      : 6073
//                Anpassungen Layout analog Kundenbericht 
//
//=============== V1.0.0039 ===============================================
//
// Date         : 22.April 2008
// Author       : Joldic Dzevad
// Defect#      : 5901
//                Init Module 
//
//-----------------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Data.SqlClient;

/// <summary>
/// Zusammenfassungsbeschreibung für dbReadOnly
/// </summary>
namespace TapMontage.dbObjects
{
    public class dbReadOnly
    {
        private DateTime berMon = ParamVal.Date0;
        private int persKey = 0;
        private int ebId = 0;
        private int ebStatus = 0;
        public double summeStdNorm = 0;
        public double summeStd50 = 0;
        public double summeStd100 = 0;
        public double summeProdStd = 0;
        public double summeGKNorm = 0;
        public double summeGKU50 = 0;
        public double summeGKU100 = 0;
        public double summeGK = 0;
        public double summeRZ = 0;

        public dbReadOnly(DateTime dt, int perskey, int ebid)
        {
            berMon = dt;
            persKey = perskey;
            ebId = ebid;
            //
            // TODO: Konstruktorlogik hier hinzufügen
            //
        }

        public dbReadOnly(DateTime dt, int perskey, int ebid, int ebstatus)
        {
            berMon = dt;
            persKey = perskey;
            ebId = ebid;
            ebStatus = ebstatus;
        }


        public ArrayList SelectArbzeiten()
        {
            ArrayList az = new ArrayList(); // Liste der Arbeitszeiten des Berichtsmonats

            // Selektion der RA Auslagen eines Einsatzberichtes
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    using (SqlCommand cmd = new SqlCommand("SELECT az.kzaz, az.datum, az.normstd, az.beginn, az.ende, az.stdabsenzid, " +
                                                           "(SELECT ys.stdabsenztxt " +
                                                           " FROM   y_stdabsenz ys " + Config.Nolock +
                                                           " WHERE  ys.stdabsenzid = az.stdabsenzid) AS stdabsenztxt, " +
                                                           " az.uestd50, az.uestd100, az.leistart, az.auftrnr, " +
                                                           "(SELECT y.auftrnr" +
                                                           " FROM   y_auftrnrs y " + Config.Nolock + ", bearbeit b " + Config.Nolock +
                                                           " WHERE  b.perskey = az.perskey " +
                                                           " AND    y.mandant = b.mandant " +
                                                           " AND    y.auftrnr = az.auftrnr) AS gkauftrner " +
                                                           " FROM   arbzeit az " + Config.Nolock +
                                                           " WHERE  az.perskey = @PERSKEY " +
                                                           " AND DATEPART(YEAR, az.datum) = @YEAR " +
                                                           " AND DATEPART(MONTH, az.datum) = @MONTH " +
                                                           " AND az.ebid = @EBID " +
                                                           //" AND az.stdabsenzid <> 110 " + //keine ZA Stunden
                                                           " ORDER BY az.beginn ASC ", cnx))
                    {
                        cmd.Parameters.Add(new SqlParameter("@PERSKEY", persKey));
                        cmd.Parameters.Add(new SqlParameter("@YEAR", berMon.Year));
                        cmd.Parameters.Add(new SqlParameter("@MONTH", berMon.Month));
                        cmd.Parameters.Add(new SqlParameter("@EBID", ebId));

                        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                        {
                            /*
                             * 0 = Kzaz
                             * 1 = datum
                             * 2 = normstd
                             * 3 = beginn
                             * 4 = ende
                             * 5 = stdabsenzid
                             * 6 = stdabsenztxt
                             * 7 = uestd50
                             * 8 = uestd100
                             * 9 = leistart
                             * 10 = auftrnr
                             * 11 = gkauftrner
                             */
                            cmd.Parameters.Clear();
                            while (rd.Read())
                            {
                                string gkauftrnr = "";
                                string stdabsenztxt = "";
                                string leistArt = "";

                                if (!rd.IsDBNull(6))
                                {
                                    stdabsenztxt = rd.GetString(6);
                                }
                                if (!rd.IsDBNull(9))
                                    leistArt = rd.GetString(9);

                                if (rd.GetString(0) == "R")
                                    summeRZ += (double)(rd.GetInt16(2) + rd.GetInt16(7) + rd.GetInt16(8)) / 60;
                                else
                                    if (!rd.IsDBNull(11))
                                    {
                                        gkauftrnr = rd.GetString(11);
                                        summeGKNorm += (double)rd.GetInt16(2) / 60; //GK Norm
                                        summeGKU50 += (double)rd.GetInt16(7) / 60; //GK Ue50
                                        summeGKU100 += (double)rd.GetInt16(8) / 60; //GK Ue100
                                    }
                                    else
                                        if (rd.GetInt16(5) == 100 || rd.GetInt16(5) == 10) // Sonstiges oder Pflegefreistellung sind auch GK
                                        {
                                            summeGKNorm += (double)rd.GetInt16(2) / 60; //GK Norm
                                            summeGKU50 += (double)rd.GetInt16(7) / 60; //GK Ue50 ... sollte 0 sein std absenz ausserhalb de NAZ ist nicht erlaubt
                                            summeGKU100 += (double)rd.GetInt16(8) / 60; //GK Ue100 ... sollte 0 sein std absenz ausserhalb de NAZ ist nicht erlaubt
                                        }
                                        else
                                        {
                                            if (rd.GetInt16(5) != 110) // 110 == ZA
                                            {
                                                //produktiv
                                                summeStdNorm += (double)rd.GetInt16(2) / 60;
                                                summeStd50 += (double)rd.GetInt16(7) / 60;
                                                summeStd100 += (double)rd.GetInt16(8) / 60;
                                            }
                                        }
                                az.Add(new dbArbeitsZeit(rd.GetString(0), rd.GetDateTime(1), rd.GetInt16(2), rd.GetDateTime(3), rd.GetDateTime(4), rd.GetInt16(5), stdabsenztxt, rd.GetInt16(7), rd.GetInt16(8), leistArt/* = rd.GetString(9)*/, rd.GetString(10), gkauftrnr));
                            }
                            summeProdStd = summeStdNorm + summeStd50 + summeStd100;
                            summeGK = summeGKNorm + summeGKU50 + summeGKU100;
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return az;
        }

        // beginn 6073


        public ArrayList SelectAusZulagen()
        {

            ArrayList auszu = new ArrayList(); // Liste der Aus- und Zulagen

            // Selektion der Aus- und Zulagen
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    //TAPM-33 SQL Anweisung angepasst
                    /*using (SqlCommand cmd = new SqlCommand("SELECT y.lohnart, y.lohnarttxt, z.anzahl, b.ktobj " +
                                                           " FROM   zulage z " + Config.Nolock + ", einsber e " + Config.Nolock + ", y_lohnart2 y " + Config.Nolock + ", bauprojekt b " + Config.Nolock +
                                                           " WHERE  e.ebid = @EBID " +
                                                           " AND    z.ebid = @EBID " +
                                                           " AND    z.lohnart = y.lohnart " +
                                                           " AND    b.projid = e.projid " +
                                                           " AND    left(y.lohnarttxt,3) <> 'SEG' ", cnx))*/
                    
                   using (SqlCommand cmd = new SqlCommand("SELECT Y_LOHNART3.LOHNART, Y_LOHNART3.LOHNARTTXT, ZULAGE.ANZAHL, BAUPROJEKT.KTOBJ " +
                                                        " FROM Y_LOHNART3 " + Config.Nolock + " INNER JOIN ZULAGE " + Config.Nolock + " ON Y_LOHNART3.LOHNART = ZULAGE.LOHNART INNER JOIN " +
                                                        " EINSBER " + Config.Nolock + " ON Y_LOHNART3.MANDANT = EINSBER.MANDANT INNER JOIN " +
                                                        " BAUPROJEKT " + Config.Nolock + " ON EINSBER.PROJID = BAUPROJEKT.PROJID " +
                                                        " WHERE (EINSBER.EBID = @EBID) AND (LEFT(Y_LOHNART3.LOHNARTTXT, 3) <> 'SEG') AND (ZULAGE.EBID = @EBID)" + 
                                                        " UNION " +
                                                        " SELECT Y_LOHNART3.LOHNART, Y_LOHNART3.LOHNARTTXT, AUSLAGE.ANZAHL, BAUPROJEKT.KTOBJ " +
                                                        " FROM Y_LOHNART3 " + Config.Nolock + " INNER JOIN AUSLAGE " + Config.Nolock + " ON Y_LOHNART3.LOHNART = AUSLAGE.LOHNART INNER JOIN " +
                                                        " EINSBER " + Config.Nolock + " ON Y_LOHNART3.MANDANT = EINSBER.MANDANT INNER JOIN " +
                                                        " BAUPROJEKT " + Config.Nolock + " ON EINSBER.PROJID = BAUPROJEKT.PROJID " +
                                                        " WHERE (EINSBER.EBID = @EBID) AND (LEFT(Y_LOHNART3.LOHNARTTXT, 3) <> 'SEG') AND (AUSLAGE.EBID = @EBID)", cnx))
                   {
                        //TAPM-33 nur EBID als Parameter übergeben
                        cmd.Parameters.Add(new SqlParameter("@EBID", ebId));
                        //cmd.Parameters.Add(new SqlParameter("@PERSKEY", persKey));
                        //cmd.Parameters.Add(new SqlParameter("@BERMON", berMon));

                        using (SqlDataReader rd = cmd.ExecuteReader())
                        {
                            cmd.Parameters.Clear();

                            while (rd.Read())
                            {
                                auszu.Add(new dbReadOnlyAusZulage(rd.GetString(0), rd.GetString(1), Convert.ToSingle(rd.GetValue(2)), rd.GetString(3), "", ""));
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
                /* wird nicht mehr gebraucht, da bei select von zulagen, auch eine union mit der auslagen gemacht ist.
                try
                {
                    cnx.Open();
                    //TAPM-33 SQL Anweisung angepasst
                    using (SqlCommand cmd = new SqlCommand("SELECT y.lohnart, y.lohnarttxt, a.anzahl, b.ktobj " +
                                                           " FROM   auslage a " + Config.Nolock + ", einsber e " + Config.Nolock + ", y_lohnart2 y " + Config.Nolock + ", bauprojekt b " + Config.Nolock +
                                                           " WHERE  e.ebid = @EBID " +
                                                           " AND    a.ebid = @EBID " +
                                                           " AND    a.lohnart = y.lohnart " +
                                                           " AND    left(y.lohnarttxt,3) <> 'SEG' " +
                                                           " AND    b.projid = e.projid ", cnx))
                    {
                        //TAPM-33 nur EBID als Parameter übergeben
                        cmd.Parameters.Add(new SqlParameter("@EBID", ebId)); 
                        //cmd.Parameters.Add(new SqlParameter("@PERSKEY", persKey));
                        //cmd.Parameters.Add(new SqlParameter("@BERMON", berMon));

                        using (SqlDataReader rd = cmd.ExecuteReader())
                        {
                            cmd.Parameters.Clear();

                            while (rd.Read())
                            {
                                auszu.Add(new dbReadOnlyAusZulage(rd.GetString(0), rd.GetString(1), Convert.ToSingle(rd.GetValue(2)), rd.GetString(3), "", ""));
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }*/
            }
            return auszu;
        }

        public ArrayList SelectGTAbsenzen()
        {

            ArrayList gtabsenzen = new ArrayList(); // GTAbsenzen Liste

            // Selektion GTAbsenzen
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    using (SqlCommand cmd = new SqlCommand(" SELECT k.DATUM, g.GTABSENZTXT +'('+Convert(varchar(5),k.GTABSENZID)+')' " +
                                                           "   FROM kaltag k " + Config.Nolock + ", Y_GTABSENZ g " + Config.Nolock +
                                                           "  WHERE k.perskey = @PERSKEY " +
                                                           "        AND k.GTABSENZID = g.GTABSENZID " +
                                                           "        AND DATEPART ( MONTH , k.DATUM ) = @MONTH " + 
                                                           "        AND DATEPART ( YEAR , k.DATUM ) = @YEAR " +
                                                           "  ORDER BY k.DATUM ", cnx))
                    {
                        cmd.Parameters.Add(new SqlParameter("@PERSKEY", persKey));
                        cmd.Parameters.Add(new SqlParameter("@MONTH", berMon.Month));
                        cmd.Parameters.Add(new SqlParameter("@YEAR", berMon.Year));

                        using (SqlDataReader rd = cmd.ExecuteReader())
                        {
                            cmd.Parameters.Clear();

                            while (rd.Read())
                            {
                                gtabsenzen.Add(new dbReadOnlyGTA(rd.GetDateTime(0).ToShortDateString(), rd.GetString(1)));
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return gtabsenzen;
        }


        public string SelectBemerkung()
        {
            string bemerkung = "";
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    //TAPM-33 SQL Anweisung angepasst
                    using (SqlCommand cmd = new SqlCommand("SELECT e.ebhist " +
                                                           " FROM   einsber e " + Config.Nolock + //", bearbeit b " + Config.Nolock +
                                                           " WHERE  e.ebid = @EBID ", cnx))
                    {
                        //TAPM-33 nur EBID als Parameter übergeben
                        cmd.Parameters.Add(new SqlParameter("@EBID", ebId));
                        //cmd.Parameters.Add(new SqlParameter("@PERSKEY", persKey));
                        //cmd.Parameters.Add(new SqlParameter("@BERMON", berMon));

                        using (SqlDataReader rd = cmd.ExecuteReader())
                        {
                            cmd.Parameters.Clear();

                            while (rd.Read())
                            {
                                bemerkung = rd.GetString(0);
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return bemerkung;
        }


        public ArrayList SelectKFZ()
        {

            ArrayList kfz = new ArrayList(); // Liste der KFZ daten

            // Selektion der KFZ daten
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                // status < 40 - read data from "TPM_RAKFZDATEN"
                if (ebStatus < 40)
                {
                    try
                    {
                        cnx.Open();
                        //TAPM-33 SQL Anweisung angepasst
                        using (SqlCommand cmd = new SqlCommand(" SELECT k.RDATUM, k.KFZ, k.KFZKZ, k.ABKM, k.GEFKM, k.MITFAHRER, k.SCHWERGP " +
                                                                " FROM   TPM_RAKFZDATEN k " + Config.Nolock + //", bearbeit b  " + Config.Nolock +
                                                                " WHERE  k.EBID = @EBID " + /*b.perskey = @PERSKEY AND  b.perskey = k.perskey " +
                                                                       " AND DATEPART ( MONTH , k.RDATUM ) = @MONTH " +
                                                                       " AND DATEPART ( YEAR , k.RDATUM ) = @YEAR " +*/
                                                                " ORDER BY k.RDATUM ", cnx))
                        {
                            //TAPM-33 nur EBID als Parameter übergeben
                            cmd.Parameters.Add(new SqlParameter("@EBID", ebId));
                            //cmd.Parameters.Add(new SqlParameter("@PERSKEY", persKey));
                            //cmd.Parameters.Add(new SqlParameter("@MONTH", berMon.Month));
                            //cmd.Parameters.Add(new SqlParameter("@YEAR", berMon.Year));

                            using (SqlDataReader rd = cmd.ExecuteReader())
                            {
                                cmd.Parameters.Clear();

                                while (rd.Read())
                                {
                                    if (!rd.IsDBNull(0))
                                        kfz.Add(new dbReadOnlyKFZ(Convert.ToString(rd.GetDateTime(0)), rd.GetString(1), rd.GetString(2), Convert.ToString(rd.GetInt32(3)), Convert.ToString(rd.GetInt32(4)), Convert.ToString(rd.GetInt32(5)), rd.GetString(6)));
                                }
                            }
                        }
                    }
                    catch (Exception ex) { throw ex; }
                    finally { cnx.Close(); }
                }
                else          // Satus >= 40 - read data from "RAZEILE" table
                {
                    try
                    {
                        cnx.Open();
                        //TAPM-33 SQL Anweisung angepasst
                        using (SqlCommand cmd = new SqlCommand(" SELECT z.AB, 'KFZ' , 'KFZKZ', z.ABKM, z.GEFKM, z.MITFAHRER, z.SCHWERGP " +
                                                               " FROM RAZEILE z " + Config.Nolock +
                                                               " WHERE z.ebid = @EBID " +
                                                               " AND z.ABKM is not null " +
                                                               " AND z.ABKM > 0 " +
                                                               " ORDER BY z.AB ", cnx))
                                                               /*b.perskey = @PERSKEY " +
                                                                     " AND (DATEPART ( MONTH , z.DAT ) = @MONTH) " +
                                                                     " AND (DATEPART ( YEAR , z.DAT ) = @YEAR) " +
                                                                     " AND b.perskey = k.perskey " +
                                                                     " AND k.raid = z.raid " +
                                                                     " AND z.ABKM is not null " +
                                                                     " AND z.ABKM > 0 " +
                                                                     " AND z.ebid  is not null ", cnx))*/
                        {
                            //TAPM-33 nur EBID als Parameter übergeben
                            cmd.Parameters.Add(new SqlParameter("@EBID", ebId));
                            //cmd.Parameters.Add(new SqlParameter("@PERSKEY", persKey));
                            //cmd.Parameters.Add(new SqlParameter("@MONTH", berMon.Month));
                            //cmd.Parameters.Add(new SqlParameter("@YEAR", berMon.Year));

                            using (SqlDataReader rd = cmd.ExecuteReader())
                            {
                                cmd.Parameters.Clear();

                                while (rd.Read())
                                {
                                    kfz.Add(new dbReadOnlyKFZ(Convert.ToString(rd.GetDateTime(0)), rd.GetString(1), rd.GetString(2), rd.GetString(3), rd.GetString(4), rd.GetString(5), rd.GetString(6)));
                                }
                            }
                        }
                    }
                    catch (Exception ex) { throw ex; }
                    finally { cnx.Close(); }
                }
            }
            return kfz;
        }




        public ArrayList SelectBarauslagen()
        {

            ArrayList barauslagen = new ArrayList(); // Liste der Barauslagen

            // Selektion Barauslagen
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                // status < 40 - read data from "RAAUSLAGE" table
                if (ebStatus < 40)
                {
                    try
                    {
                        cnx.Open();
                        using (SqlCommand cmd = new SqlCommand(" SELECT r.DATUM, y.RAKZTXT, r.ANZAHL, r.BETRAG " +
                                                               "   FROM RAAUSLAGE r " + Config.Nolock + ", Y_RAKZ y " + Config.Nolock + 
                                                               "  WHERE r.ebid = @EBID " +
                                                               "  AND r.RAKZ = y.RAKZ " + //Defect xxxx
                                                               //"        AND DATEPART ( MONTH , r.DATUM ) = @MONTH " +
                                                               //"        AND DATEPART ( YEAR , r.DATUM ) = @YEAR " +
                                                               "  ORDER BY r.datum ", cnx))
                        {
                            //TAPM-33 nur EBID als Parameter übergeben
                            cmd.Parameters.Add(new SqlParameter("@EBID", ebId));
                            //cmd.Parameters.Add(new SqlParameter("@PERSKEY", persKey));
                            //cmd.Parameters.Add(new SqlParameter("@MONTH", berMon.Month));
                            //cmd.Parameters.Add(new SqlParameter("@YEAR", berMon.Year));

                            using (SqlDataReader rd = cmd.ExecuteReader())
                            {
                                cmd.Parameters.Clear();

                                while (rd.Read())
                                {
                                    //TT 6685267 Teil 1.
                                    barauslagen.Add(new dbReadOnlyBarauslagen(rd.GetDateTime(0).ToShortDateString(), rd.GetString(1), rd.GetDouble(2), rd.GetDecimal(3)));
                                }
                            }
                        }
                    }
                    catch (Exception ex) { throw ex; }
                    finally { cnx.Close(); }
                }
                else          // Satus >= 40 - read data from "RAZEILE" table
                {
                    try
                    {
                        cnx.Open();
                        //TAPM-33 SQL Anweisung angepasst
                        using (SqlCommand cmd = new SqlCommand(" SELECT z.DAT, y.RAKZTXT, z.ANZNAECHTE, z.BETRAG " +
                                                               " FROM RAZEILE z " + Config.Nolock +
                                                               ", Y_RAKZ y " + Config.Nolock + //Defect xxxx
                                                               " WHERE z.ebid = @EBID " +
                                                                     " AND z.ZEILENKZ is null " +
                                                                     " AND z.AUSLART is not null " +
                                                                     " AND y.RAKZ = z.AUSLART ORDER by z.DAT", cnx))
                        {
                            //TAPM-33 nur EBID als Parameter übergeben
                            cmd.Parameters.Add(new SqlParameter("@EBID", ebId));
                            //cmd.Parameters.Add(new SqlParameter("@PERSKEY", persKey));
                            //cmd.Parameters.Add(new SqlParameter("@MONTH", berMon.Month));
                            //cmd.Parameters.Add(new SqlParameter("@YEAR", berMon.Year));

                            using (SqlDataReader rd = cmd.ExecuteReader())
                            {
                                cmd.Parameters.Clear();

                                while (rd.Read())
                                {
                                    if (!rd.IsDBNull(0))
                                        //TT 6685267 Teil 2
                                        barauslagen.Add(new dbReadOnlyBarauslagen(Convert.ToString(rd.GetDateTime(0)), rd.GetString(1), Convert.ToDouble(rd.GetString(2)), Convert.ToDecimal(rd.GetString(3))));
                                }
                            }
                        }
                    }
                    catch (Exception ex) { throw ex; }
                    finally { cnx.Close(); }
                }
            }
            return barauslagen;
        }


    }


    public class dbReadOnlyAusZulage
    {
        public string Lohnart = "";
        public string Lohnarttxt = "";
        public float Anzahl = 0;
        public string Ktobj = "";
        public string SEGPunkte = "";
        public string Basisstunde = "";

        public dbReadOnlyAusZulage(string lohnart, string lohnarttxt, float anzahl, string ktobj, string segpunkte, string basisstunde)
        {
            Lohnart = lohnart;
            Lohnarttxt = lohnarttxt;
            Anzahl = anzahl;
            Ktobj = ktobj;
            SEGPunkte = segpunkte;
            Basisstunde = basisstunde;
        }
    }

    public class dbReadOnlyGTA
    {
        public string Datum = "";
        public string Absenzart = "";
        
        public dbReadOnlyGTA(string datum, string absenzart)
        {
            Datum = datum;
            Absenzart = absenzart;
        }
    }

    public class dbReadOnlyKFZ
    {
        public string rDatum = "";
        public string KFZ = "";
        public string KFZKZ = "";
        public string GefKM = "";
        public string ABKM = "";
        public string Mitfahrer = "";
        public string SchwerGP = "";

        public dbReadOnlyKFZ(string rdatum, string kfz, string kfzkz, string abkm, string gefkm, string mitfahrer, string schwergp)
        {
            rDatum = rdatum;
            KFZ = kfz;
            KFZKZ = kfzkz;
            GefKM = gefkm;
            ABKM = abkm;
            Mitfahrer = mitfahrer;
            if (schwergp == "S")
            {

                SchwerGP = "ja";
            }
            else
            {
                SchwerGP = "nein";
            }
        }
    }

    public class dbReadOnlyBarauslagen
    {
        public string Datum = "";
        public string Auslagenart = "";
        public double Anzahl = 0;
        public Decimal Betrag = 0;

        public dbReadOnlyBarauslagen(string datum, string auslagenart, double anzahl, Decimal betrag)
        {
            Datum = datum;
            Auslagenart = auslagenart;
            Anzahl = anzahl;
            Betrag = betrag;
        }
    }


    // ende 6073



    public class dbArbeitsZeit
    {
        public string Kzaz = "";
        public double Normstd = 0;
        public DateTime Datum;
        public DateTime Beginn;
        public DateTime Ende;
        public int Stdabsenzid = 0;
        public string Stdabsenztxt = "";
        public double Uestd50 = 0;
        public double Uestd100 = 0;
        public string Leistart = "";
        public string Auftrnr = "";
        public string GKAuftrnr = "";
        public dbArbZeit.ArbZeitType azTyp = dbArbZeit.ArbZeitType.alle;


        public dbArbeitsZeit(string kzaz, DateTime datum, int normstd, DateTime beginn, DateTime ende, int stdabsenzid, string stdabsenztxt, int uestd50, int uestd100, string leistart, string auftrnr, string gkauftrnr)
        {
            Kzaz = kzaz;
            Datum = datum;
            Beginn = beginn;
            Ende = ende;
            Stdabsenzid = stdabsenzid;
            Stdabsenztxt = stdabsenztxt;
            Normstd = (double)normstd / 60;
            Uestd50 = (double)uestd50 / 60;
            Uestd100 = (double)uestd100 / 60;
            Leistart = leistart;
            Auftrnr = auftrnr;
            GKAuftrnr = gkauftrnr;

            switch (Kzaz)
            {
                case "W":
                    azTyp = dbArbZeit.ArbZeitType.ReiseInDienstzeit;
                    break;
                case "R":
                    azTyp = dbArbZeit.ArbZeitType.ReiseVorherNachher;
                    break;
                case "E":
                    azTyp = dbArbZeit.ArbZeitType.produktiv;
                    break;
                case "A":
                    azTyp = dbArbZeit.ArbZeitType.produktiv;
                    if (GKAuftrnr != "")
                        azTyp = dbArbZeit.ArbZeitType.gk;
                    else
                        if (stdabsenztxt != "")
                            azTyp = dbArbZeit.ArbZeitType.stdAbsenz;
                    break;
                default:
                    break;
            }
        }

    }
}