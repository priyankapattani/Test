//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbMontBer.cs
//
// Description  : DB-Zugriffe f�r Einsatzberichte
//
//=============== V1.2.0006 ===============================================
//
// Date         : 16.August 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530042
//                Verwenden von AZMKalenderTage statt st�ndige AZM abfragen
//                
//=============== V1.0.0044 ===============================================
//
// Date         : 11.Juli 2008
// Author       : Joldic Dzevad
// Defect#      : 6178
//                R�cksetzen EB durch Erfasser / Genehmiger
//
//=============== V1.0.0043 ===============================================
//
// Date         : 11.Juli 2008
// Author       : Joldic Dzevad
// Defect#      : 6075
//                Alle offene EB mit einem Knopfdruck freigeben
//
//=============== V1.0.0042 ===============================================
//
// Date         : 18.Juni 2008
// Author       : Frantisek Sabol
// Defect#      : 6074
//                Alle MA Belege Ausdrucken durch ein Knopfdruck
//
//=============== V1.0.0037 ===============================================
//
// Date         : 14.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//--------------- V1.0.0022 ------------------------------------------------------------------
//
// Date         : 24. Februar 2007
// Author       : GN
// Defect#      : 4625
//                Wir haben in der Datenbank f�r Berichtsmonat J�nner ca. 800 R/W Zeilen ohne Leistungsart.
//                Transaktionsthema
//
//--------------- V1.0.0021 ------------------------------------------------------------------ 
//
// Date         : 1. Februar 2007
// Author       : CL
// Defect#      : 4496
//
// Fehlermeldung beim Abspeichern von Einsatzbericht:
// System.ArgumentException: The SqlParameter is already contained by another SqlParameterCollection.
//
//--------------- V1.0.0022 ------------------------------------------------------------------
//
// Date         : 5. Februar 2007
// Author       : CL
// Defect#      : 4521
//                Die Adressdaten der Baustelle werden im Einsatzbericht eingetragen.
//
//--------------- V1.0.0022 ------------------------------------------------------------------
//
// Date         : 6. Februar 2007
// Author       : CL
// Defect#      : 4520
//
// Die laufende Zeilennummer wird aufsteigend nach Kommen-Stempel in die
// Tabelle 'Arbzeit' eingetragen.
//
//--------------- V1.0.0022 ------------------------------------------------------------------
//
// Date         : 15. Februar 2007
// Author       : CG
// Defect#      : 4501
// 
// Keine EB-Erfassung m�glich f. folgende F�lle: 
// Untermonatiger Projektablauf mit/ohne untermonatiger MA- Firmenein- od. austtritt
// �nderung in dieser Klasse dienen zum Auslesen d. MA-Firemenein- und austrittsdaten
//
//--------------- V1.0.0022 ------------------------------------------------------------------
//
// Date         : 27. Februar 2007
// Author       : Caleb GEBHARDT
// Defect#      : 4594 
//                'Kein Arbeitszeitmodell f�r Mitarbeiter gefunden'
//                Merkvariable f. d. selektierten EB - Monat
//
// -------------------------------------------------------------------------------------------

using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


namespace TapMontage.dbObjects
{

    public class dbMB_EINSBERParams
    {
        public SqlParameter PROJID = new SqlParameter("@PROJID", int.MinValue);
        public SqlParameter EBID = new SqlParameter("@EBID", int.MinValue);
        public SqlParameter MANDANT = new SqlParameter("@MANDANT", (string)"");
        public SqlParameter EBNR = new SqlParameter("@EBNR", int.MinValue);
        public SqlParameter EBSTAT = new SqlParameter("@EBSTAT", Int16.MinValue);
        public SqlParameter AUFID = new SqlParameter("@AUFID", int.MinValue);
        public SqlParameter BEARBNR = new SqlParameter("@BEARBNR", (string)"");
        public SqlParameter PERSKEY = new SqlParameter("@PERSKEY", int.MinValue);
        public SqlParameter WARTBEZ = new SqlParameter("@WARTBEZ", (string)"");
        public SqlParameter BERMON = new SqlParameter("@BERMON", ParamVal.Date0);
        public SqlParameter ERFDATUM = new SqlParameter("@ERFDATUM", ParamVal.Date0);
        public SqlParameter LEISTSTELLE = new SqlParameter("@LEISTSTELLE", (string)"");
        public SqlParameter KZGEDRUCKT = new SqlParameter("@KZGEDRUCKT", (string)"");
        public SqlParameter PRPERSKEY = new SqlParameter("@PRPERSKEY", int.MinValue);
        public SqlParameter PRDATUM = new SqlParameter("@PRDATUM", ParamVal.Date0);
        public SqlParameter DATLASRV = new SqlParameter("@DATLASRV", ParamVal.Date0);
        public SqlParameter DATLA = new SqlParameter("@DATLA", ParamVal.Date0);
        public SqlParameter AENPERSKEY = new SqlParameter("@AENPERSKEY", int.MinValue);
        public SqlParameter DATNEU = new SqlParameter("@DATNEU", ParamVal.Date0);
        public SqlParameter KD_NAME1 = new SqlParameter("@KD_NAME1", (string)"");
        public SqlParameter KD_NAME2 = new SqlParameter("@KD_NAME2", (string)"");
        public SqlParameter KD_NAME3 = new SqlParameter("@KD_NAME3", (string)"");
        public SqlParameter KD_STRASSE = new SqlParameter("@KD_STRASSE", (string)"");
        public SqlParameter KD_PLZ = new SqlParameter("@KD_PLZ", (string)"");
        public SqlParameter KD_ORT = new SqlParameter("@KD_ORT", (string)"");
        public SqlParameter KD_LKZ = new SqlParameter("@KD_LKZ", (string)"");
        public SqlParameter KD_ANRUFER = new SqlParameter("@KD_ANRUFER", (string)"");
        public SqlParameter P_BEZEICH = new SqlParameter("@P_BEZEICH", (string)"");
        public SqlParameter BEMERKUNG1 = new SqlParameter("@BEMERKUNG1", (string)"");
        public SqlParameter EINGANGSD = new SqlParameter("@EINGANGSD", ParamVal.Date0);
        public SqlParameter KZAUSL = new SqlParameter("@KZAUSL", (string)"");
        public SqlParameter KZKDBEST = new SqlParameter("@KZKDBEST", (string)"");
        public SqlParameter BEMERKUNG = new SqlParameter("@BEMERKUNG", (string)"");
        public SqlParameter KD_AUFNR1 = new SqlParameter("@KD_AUFNR1", (string)"");
        public SqlParameter KD_TITEL = new SqlParameter("@KD_TITEL", (string)"");
        public SqlParameter KD_UNTERZ = new SqlParameter("@KD_UNTERZ", (string)"");
        public SqlParameter DRDATUM = new SqlParameter("@DRDATUM", ParamVal.Date0);
        public SqlParameter BEARBNRKZ = new SqlParameter("@BEARBNRKZ", (string)"");
        public SqlParameter VORNAME = new SqlParameter("@VORNAME", (string)"");
        public SqlParameter NACHNAME = new SqlParameter("@NACHNAME", (string)"");
        public SqlParameter ABTEILUNG = new SqlParameter("@ABTEILUNG", (string)"");
        public SqlParameter TITEL = new SqlParameter("@TITEL", (string)"");
        public SqlParameter WBNR = new SqlParameter("@WBNR", int.MinValue);
        public SqlParameter EINSID = new SqlParameter("@EINSID", int.MinValue);
        public SqlParameter STDID = new SqlParameter("@STDID", int.MinValue);
        public SqlParameter KDD_TITEL = new SqlParameter("@KDD_TITEL", (string)"");
        public SqlParameter KDD_NAME1 = new SqlParameter("@KDD_NAME1", (string)"");
        public SqlParameter KDD_NAME2 = new SqlParameter("@KDD_NAME2", (string)"");
        public SqlParameter KDD_NAME3 = new SqlParameter("@KDD_NAME3", (string)"");
        public SqlParameter KDD_STRASSE = new SqlParameter("@KDD_STRASSE", (string)"");
        public SqlParameter KDD_PLZ = new SqlParameter("@KDD_PLZ", (string)"");
        public SqlParameter KDD_ORT = new SqlParameter("@KDD_ORT", (string)"");
        public SqlParameter KDD_LKZ = new SqlParameter("@KDD_LKZ", (string)"");
        public SqlParameter V_VERTNR = new SqlParameter("@V_VERTNR", (string)"");
        public SqlParameter DATLEIST = new SqlParameter("@DATLEIST", ParamVal.Date0);
        public SqlParameter DATPREISB = new SqlParameter("@DATPREISB", ParamVal.Date0);
        public SqlParameter KZSERVLEIST = new SqlParameter("@KZSERVLEIST", (string)"");
        public SqlParameter PREISPAUSCH = new SqlParameter("@PREISPAUSCH", Double.MinValue);
        public SqlParameter WAEHRKZ = new SqlParameter("@WAEHRKZ", (string)"");
        public SqlParameter DRUCKVORL = new SqlParameter("@DRUCKVORL", (string)"");
        public SqlParameter DATARCHIV = new SqlParameter("@DATARCHIV", (string)"");
        public SqlParameter BEMERKUNGI = new SqlParameter("@BEMERKUNGI", (string)"");
        public SqlParameter EBSTATK = new SqlParameter("@EBSTATK", Int16.MinValue);
        public SqlParameter VGPERSKEY = new SqlParameter("@VGPERSKEY", int.MinValue);
        public SqlParameter KPERSKEY = new SqlParameter("@KPERSKEY", int.MinValue);
        public SqlParameter KDATUM = new SqlParameter("@KDATUM", ParamVal.Date0);
        public SqlParameter FLDTXT1 = new SqlParameter("@FLDTXT1", (string)"");
        public SqlParameter FLDTXT2 = new SqlParameter("@FLDTXT2", (string)"");
        public SqlParameter FLDTXT3 = new SqlParameter("@FLDTXT3", (string)"");
        public SqlParameter VGBEMERKUNG = new SqlParameter("@VGBEMERKUNG", (string)"");
        public SqlParameter EBHIST = new SqlParameter("@EBHIST", (string)"");
        public SqlParameter KFMBEMERKUNG = new SqlParameter("@KFMBEMERKUNG", (string)"");
        public SqlParameter DATUGFAKT = new SqlParameter("@DATUGFAKT", ParamVal.Date0);
        public SqlParameter SERIENNR = new SqlParameter("@SERIENNR", (string)"");
        public SqlParameter PDFSTATUS = new SqlParameter("@PDFSTATUS", Int16.MinValue);
        public SqlParameter PDFFAX = new SqlParameter("@PDFFAX", (string)"");
        public SqlParameter PDFMAIL = new SqlParameter("@PDFMAIL", (string)"");
        public SqlParameter INTF_ID = new SqlParameter("@INTF_ID", Int16.MinValue);
        public SqlParameter KM = new SqlParameter("@KM", int.MinValue);

        public ArrayList List = new ArrayList();
        public dbMB_EINSBERParams()
        {
            List.Add(PROJID);
            List.Add(EBID);
            List.Add(MANDANT);
            List.Add(EBNR);
            List.Add(EBSTAT);
            List.Add(AUFID);
            List.Add(BEARBNR);
            List.Add(PERSKEY);
            List.Add(WARTBEZ);
            List.Add(BERMON);
            List.Add(ERFDATUM);
            List.Add(LEISTSTELLE);
            List.Add(KZGEDRUCKT);
            List.Add(PRPERSKEY);
            List.Add(PRDATUM);
            List.Add(DATLASRV);
            List.Add(DATLA);
            List.Add(AENPERSKEY);
            List.Add(DATNEU);
            List.Add(KD_NAME1);
            List.Add(KD_NAME2);
            List.Add(KD_NAME3);
            List.Add(KD_STRASSE);
            List.Add(KD_PLZ);
            List.Add(KD_ORT);
            List.Add(KD_LKZ);
            List.Add(KD_ANRUFER);
            List.Add(P_BEZEICH);
            List.Add(BEMERKUNG1);
            List.Add(EINGANGSD);
            List.Add(KZAUSL);
            List.Add(KZKDBEST);
            List.Add(BEMERKUNG);
            List.Add(KD_AUFNR1);
            List.Add(KD_TITEL);
            List.Add(KD_UNTERZ);
            List.Add(DRDATUM);
            List.Add(BEARBNRKZ);
            List.Add(VORNAME);
            List.Add(NACHNAME);
            List.Add(ABTEILUNG);
            List.Add(TITEL);
            List.Add(WBNR);
            List.Add(EINSID);
            List.Add(STDID);
            List.Add(KDD_TITEL);
            List.Add(KDD_NAME1);
            List.Add(KDD_NAME2);
            List.Add(KDD_NAME3);
            List.Add(KDD_STRASSE);
            List.Add(KDD_PLZ);
            List.Add(KDD_ORT);
            List.Add(KDD_LKZ);
            List.Add(V_VERTNR);
            List.Add(DATLEIST);
            List.Add(DATPREISB);
            List.Add(KZSERVLEIST);
            List.Add(PREISPAUSCH);
            List.Add(WAEHRKZ);
            List.Add(DRUCKVORL);
            List.Add(DATARCHIV);
            List.Add(BEMERKUNGI);
            List.Add(EBSTATK);
            List.Add(VGPERSKEY);
            List.Add(KPERSKEY);
            List.Add(KDATUM);
            List.Add(FLDTXT1);
            List.Add(FLDTXT2);
            List.Add(FLDTXT3);
            List.Add(VGBEMERKUNG);
            List.Add(EBHIST);
            List.Add(KFMBEMERKUNG);
            List.Add(DATUGFAKT);
            List.Add(SERIENNR);
            List.Add(PDFSTATUS);
            List.Add(PDFFAX);
            List.Add(PDFMAIL);
            List.Add(INTF_ID);
            List.Add(KM);
            ParamVal.SetDefaultValues(List);
        }
    }

    /// <summary>
    /// Montagebericht je Projekt und Bearbeiter(Monteur)
    /// </summary>
    /// 


    public class dbMontBer
    {
        public bool drucken = false;  // Defect# 6074
        public bool freigeben = false;  // Defect# 6075
        public bool ruecksetzen = false; // Defect 6178
        //Defect# 4594 
        public int EBSelectedMonat = 0;
        //Ende Defect# 4594
        // Defect 4501
        private DateTime lMA_gueltig_von = ParamVal.Date0;
        public DateTime MA_gueltig_von
        {
            get
            {
                bool found = false;
                DateTime datvon = lMA_gueltig_von;
                if (lMA_gueltig_von == ParamVal.Date0)
                {
                    using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["AZMConnectionString"].ConnectionString))
                    {
                        try
                        {
                            cnx.Open();
                            // Defect 5725, Config.Rowlock eingef�hrt
                            // Defect 5771, Config.Nolock eingef�hrt
                            string sql = "Select max(MA_AZ_g�ltig_von) from MA_AZ_Modell " + Config.Nolock + " where MA_PersNummer = '";
                            sql += Bearbeiter.Params.PERSNR.Value.ToString().Substring(2) + "' and ma_fkn ='" +
                                   Bearbeiter.Firmenkennung + "'";
                            using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436, using eingef�hrt
                            {
                                using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                                {
                                    while (rd.Read())
                                    {
                                        datvon = Convert.ToDateTime(rd.GetValue(0).ToString());
                                        found = true;
                                    }
                                    rd.Close();
                                }
                            }
                        }
                        // Defect 5771
                        // Exception Objekt ex entfernt, da es nicht verwendet wird
                        catch { if (found == false) datvon = ParamVal.Date0; }
                        finally { cnx.Close(); }
                    }
                    lMA_gueltig_von = datvon;
                }
                return lMA_gueltig_von;
            }
        }
        private DateTime lMA_gueltig_bis = ParamVal.Date0;
        public DateTime MA_gueltig_bis
        {
            get
            {
                bool found = false;
                string gueltig_von = MA_gueltig_von.ToString("u").Substring(0, MA_gueltig_von.ToString("u").Length - 1);
                DateTime datbis = lMA_gueltig_bis;
                if (lMA_gueltig_bis == ParamVal.Date0)
                {
                    using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["AZMConnectionString"].ConnectionString))
                    {
                        try
                        {
                            cnx.Open();
                            // Defect 5725, Config.Rowlock eingef�hrt
                            // Defect 5771, Config.Rowlock eingef�hrt
                            string sql = "Select MA_AZ_g�ltig_bis from MA_AZ_Modell " + Config.Nolock + " where MA_PersNummer = '";
                            sql += Bearbeiter.Params.PERSNR.Value.ToString().Substring(2) + "' and ma_fkn ='" +
                                   Bearbeiter.Firmenkennung + "' and MA_AZ_g�ltig_von = '" + gueltig_von + "'";
                            using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436
                            {
                                using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                                {
                                    while (rd.Read())
                                    {
                                        datbis = Convert.ToDateTime(rd.GetValue(0).ToString());
                                        found = true;
                                    }
                                    rd.Close();
                                }
                            }
                        }
                        // Defect 5771
                        // Exception Objekt ex entfernt, da es nicht verwendet wird
                        catch { if (found == false) datbis = ParamVal.Date0; }
                        finally { cnx.Close(); }
                    }
                    lMA_gueltig_bis = datbis;
                }
                return lMA_gueltig_bis;
            }
        }
        private DateTime lMA_firma_ein = ParamVal.Date0;
        public DateTime MA_firma_ein
        {
            get
            {
                bool found = false;
                DateTime datein = lMA_firma_ein;
                if (lMA_firma_ein == ParamVal.Date0)
                {
                    using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["AZMConnectionString"].ConnectionString))
                    {
                        try
                        {
                            cnx.Open();
                            // Defect 5725, Config.Rowlock eingef�hrt
                            // Defect 5771, Config.Rowlock eingef�hrt
                            string sql = "Select ma_eintritt from ma_stamm " + Config.Nolock + " where ma_persnummer = '";
                            sql += Bearbeiter.Params.PERSNR.Value.ToString().Substring(2) + "' and ma_fkn ='" +
                                   Bearbeiter.Firmenkennung + "'";
                            using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436
                            {
                                using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                                {
                                    while (rd.Read())
                                    {
                                        datein = Convert.ToDateTime(rd.GetValue(0).ToString());
                                        found = true;
                                    }
                                    rd.Close();
                                }
                            }
                        }
                        // Defect 5771
                        // Exception Objekt ex entfernt, da es nicht verwendet wird
                        catch { if (found == false) datein = ParamVal.Date0; }
                        finally { cnx.Close(); }
                    }
                    lMA_firma_ein = datein;
                }
                return lMA_firma_ein;
            }
        }

        private DateTime lMA_firma_aus = ParamVal.Date0;
        public DateTime MA_firma_aus
        {
            get
            {
                bool found = false;
                DateTime dataus = lMA_firma_aus;
                if (lMA_firma_aus == ParamVal.Date0)
                {
                    using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["AZMConnectionString"].ConnectionString))
                    {
                        try
                        {
                            cnx.Open();
                            // Defect 5725, Config.Rowlock eingef�hrt
                            // Defect 5771, Config.Rowlock eingef�hrt
                            string sql = "Select ma_austritt from ma_stamm " + Config.Nolock + " where ma_persnummer = '";
                            sql += Bearbeiter.Params.PERSNR.Value.ToString().Substring(2) + "' and ma_fkn ='" +
                                   Bearbeiter.Firmenkennung + "'";
                            using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436
                            {
                                using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                                {
                                    while (rd.Read())
                                    {
                                        dataus = Convert.ToDateTime(rd.GetValue(0).ToString());
                                        found = true;
                                    }
                                    rd.Close();
                                }
                            }
                        }
                        // Defect 5771
                        // Exception Objekt ex entfernt, da es nicht verwendet wird
                        catch { if (found == false) dataus = ParamVal.Date0; }
                        finally { cnx.Close(); }
                    }
                    lMA_firma_aus = dataus;
                }
                return lMA_firma_aus;
            }
        }
        // Ende Defect 4501
        //remains private
        public double SummeStunden
        {
            get { return NormStunden + UE50 + UE100; }
        }
        public dbMB_EINSBERParams Params = new dbMB_EINSBERParams();
        private int lBerichtsMonat = 0;
        /// <summary>
        /// (int) im Format JJJJMM, l�dt den Berichtsmonat neu, �nderungen die nicht gespeichert wurden gehen verloren.
        /// </summary>
        public int BerichtsMonat
        {
            get { return lBerichtsMonat; }
            set
            {
                if (value > 0)
                {
                    lBerichtsMonat = value;
                    int Year = Convert.ToInt32(Math.Truncate((double)lBerichtsMonat / 100));
                    int Month = Convert.ToInt32(((double)lBerichtsMonat) - Year * 100);
                    DateTime rd = DateTime.Now;
                    rd = rd.AddDays(-rd.Day + 1);
                    rd = rd.AddMonths(-rd.Month + Month);
                    rd = rd.AddYears(-rd.Year + Year);
                    MinDatum = Convert.ToDateTime(rd.ToShortDateString() + " 00:00:00");
                    rd = MinDatum.AddMonths(1).AddSeconds(-1);
                    MaxDatum = Convert.ToDateTime(rd.ToShortDateString() + " 23:59:59");
                    Params.BERMON.Value = MinDatum;
                    lTage = null;
                }
            }
        }
        public DateTime MinDatum;
        public DateTime MaxDatum;

        public dbProjekt Projekt;
        public dbBearbeiter Bearbeiter;
        public dbKG_Rabrech RAbrech;

        private ArrayList lTage = null;
        public ArrayList Tage
        {
            set { lTage = value; }
            get
            {
                if (lTage == null)
                {
                    Select();
                }
                return lTage;
            }
        }
        public bool ReiseTageErfasst = false; //BAF 530042
        private ArrayList lReiseTage = null;
        public ArrayList ReiseTage
        {
            set { lReiseTage = value; }
            get
            {
                if (lReiseTage == null)
                {
                    SelectReisemonat();
                }
                return lReiseTage;
            }
        }

        private ArrayList lProjektAusZulagen = null;
        public ArrayList ProjektAusZulagen
        {
            set { lProjektAusZulagen = value; }
            get
            {
                if (lProjektAusZulagen == null)
                {
                    dbProjektAusZul az = new dbProjektAusZul(Projekt);
                    lProjektAusZulagen = az.SelectAll();
                }
                return lProjektAusZulagen;
            }
        }

        private ArrayList lReiseauslagen = null;
        public ArrayList Reiseauslagen
        {
            set { lReiseauslagen = value; }
            get
            {
                if (lReiseauslagen == null)
                {
                    dbRAAuslage ra = new dbRAAuslage(this);
                    lReiseauslagen = ra.SelectAllforEinsatzbericht();
                }
                return lReiseauslagen;
            }
        }

        private ArrayList lAuszulagen = null;
        public ArrayList Auszulagen
        {
            set { lAuszulagen = value; }
            get
            {
                if (lAuszulagen == null)
                {
                    dbAusZulage auszul = new dbAusZulage(this);
                    lAuszulagen = auszul.SelectAusZulforEinsatzbericht();
                }
                return lAuszulagen;
            }
        }

        private ArrayList lKfzDaten = null;
        public ArrayList KfzDatenlist
        {
            set { lKfzDaten = value; }
            get
            {
                if (lKfzDaten == null)
                {
                    dbRAKfzdaten lKfzlist = new dbRAKfzdaten(this);
                    lKfzDaten = lKfzlist.SelectAllMyKfzDaten();
                }
                return lKfzDaten;
            }
        }
        private ArrayList lPersKfzDaten = null;
        public ArrayList PersKfzDatenList
        {
            set { lPersKfzDaten = value; }
            get
            {
                if (lPersKfzDaten == null)
                {
                    dbRAKfzdaten lPersKfzlist = new dbRAKfzdaten(this);
                    lPersKfzDaten = lPersKfzlist.SelectMyPersKfz();
                }
                return lPersKfzDaten;
            }
        }

        public bool AllowUpdate = false;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Proj">Das Projekt auf dem Bearb abgerechnet werden soll</param>
        /// <param name="Bearb">Der Bearbeiter der auf Proj abgerechnet werden soll</param>
        public dbMontBer(dbProjekt Proj, dbBearbeiter Bearb)
        {
            Projekt = Proj;
            Bearbeiter = Bearb;
            BerichtsMonat = DateTime.Now.Year * 100 + DateTime.Now.Month;
        }

        public void Select()
        {
            AllowUpdate = false;
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    //                    string sql = SQlSELECT.Replace("\r\n","");
                    //                    SqlCommand cmd = new SqlCommand(sql, cnx);
                    SqlCommand cmd;
                    SqlDataReader rd;
                    if ((int)Params.EBID.Value != 0)
                    {
                        //sql += " EBID = @EBID and BERMON = @BERMON";
                        using (cmd = new SqlCommand("sp_TM_EinsberSelectEB", cnx)) // Defect 5436
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            Params.BERMON.Value = MinDatum;
                            Params.PROJID.Value = Projekt.Params.PROJID.Value;
                            Params.PERSKEY.Value = Bearbeiter.Params.PERSKEY.Value;
                            Params.BERMON.Value = MinDatum;
                            cmd.Parameters.Add(Params.EBID);
                            cmd.Parameters.Add(Params.BERMON);
                            rd = cmd.ExecuteReader();
                            cmd.Parameters.Remove(Params.EBID);
                            cmd.Parameters.Remove(Params.BERMON);
                        }
                    }
                    else
                    {
                        //sql += " PROJID = @PROJID and BERMON = @BERMON and PERSKEY = @PERSKEY";
                        using (cmd = new SqlCommand("sp_TM_EinsberSelectPBP", cnx)) // Defect 5436
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            Params.PROJID.Value = Projekt.Params.PROJID.Value;
                            Params.PERSKEY.Value = Bearbeiter.Params.PERSKEY.Value;
                            Params.BERMON.Value = MinDatum;
                            cmd.Parameters.Add(Params.PROJID);
                            cmd.Parameters.Add(Params.BERMON);
                            cmd.Parameters.Add(Params.PERSKEY);
                            rd = cmd.ExecuteReader();
                            cmd.Parameters.Remove(Params.PROJID);
                            cmd.Parameters.Remove(Params.BERMON);
                            cmd.Parameters.Remove(Params.PERSKEY);
                        }
                    }
                    while (rd.Read())
                    {
                        ParamVal.DataReader2Params(rd, Params.List);
                        AllowUpdate = true;
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            dbArbTag at = new dbArbTag(this, 0);
            lTage = at.SelectMonat();
        }

        public void SelectReisemonat()
        {
            dbArbTag at = new dbArbTag(this, RAbrech, 0);
            lReiseTage = at.SelectMonat();
        }

        public enum EBStat
        {
            erfasst = 10,
            //freigegeben = 20,
            freigegeben = 30, //wie beim TapClient
            //kontrolliert = 30,
            genehmigt = 40
        };

        public ArrayList SelectAllByProjekt(int BerMon)
        {
            BerichtsMonat = BerMon;
            ArrayList al = new ArrayList();
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    string sql = "Select EBID,PROJID,PERSKEY,BERMON from EINSBER " + Config.Nolock + " where PROJID = @PROJID and BERMON = @BERMON";
                    cnx.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436
                    {
                        cmd.Parameters.Add(Projekt.Params.PROJID);
                        cmd.Parameters.Add(Params.BERMON);
                        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                        {
                            cmd.Parameters.Remove(Projekt.Params.PROJID);
                            cmd.Parameters.Remove(Params.BERMON);
                            while (rd.Read())
                            {
                                dbBearbeiter bea = new dbBearbeiter(rd.GetInt32(2));
                                dbMontBer ber = new dbMontBer(Projekt, bea);
                                ber.Params.EBID.Value = rd.GetInt32(0);
                                ber.BerichtsMonat = BerichtsMonat;
                                ber.Select();
                                al.Add(ber);
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return al;
        }
        public ArrayList SelectAllByPerskey(int BerMon, int Perskey)
        {
            BerichtsMonat = BerMon;
            Params.PERSKEY.Value = Perskey;
            ArrayList al = new ArrayList();
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    string sql = "Select EBID,PROJID,PERSKEY,BERMON from EINSBER " + Config.Nolock + " where PERSKEY = @PERSKEY and BERMON = @BERMON";
                    cnx.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436
                    {
                        cmd.Parameters.Add(Params.PERSKEY);
                        cmd.Parameters.Add(Params.BERMON);
                        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                        {
                            cmd.Parameters.Remove(Params.PERSKEY);
                            cmd.Parameters.Remove(Params.BERMON);
                            while (rd.Read())
                            {
                                dbBearbeiter bea = new dbBearbeiter(rd.GetInt32(2));
                                dbProjekt p;
                                if (!rd.IsDBNull(1))
                                    p = new dbProjekt(null, rd.GetInt32(1));
                                else
                                    p = new dbProjekt(null, 0);

                                //                        dbMontBer ber = new dbMontBer(Projekt, bea);
                                //dbProjekt p = new dbProjekt(null, rd.GetInt32(1));
                                dbMontBer ber = new dbMontBer(p, bea);
                                ber.Params.EBID.Value = rd.GetInt32(0);
                                ber.BerichtsMonat = BerichtsMonat;
                                ber.Select();
                                dbBaustelle b = new dbBaustelle(Bearbeiter);
                                b.Params.BAUID.Value = p.Params.BAUID.Value;
                                b.Select();
                                p.Baustelle = b;
                                ber.Projekt = p;
                                al.Add(ber);
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return al;
        }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Die parameterlose Methode wurde aufgehoben um Kompatibilit�t zu bewahren
        public void Save()
        {
            Save(null);
        }


        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Diese Methode wurde neu eingef�hrt und �bernimmt die Funktionalit�t der parameterlosen
        //                Methode und f�hrt die Transaktion fort.
        public void Save(SqlTransaction tx)
        {
            bool inTransaction = (tx != null);

            ParamVal.InsertValid(Params.List);
            string sql;
            if (!AllowUpdate)
            {
                sql = "sp_TM_EinsberInsert";
                Params.EBID.Value = Projekt.Baustelle.Bearbeiter.Commons.GetNextID(13, "Einsatzbericht");
                Params.MANDANT.Value = Projekt.Baustelle.Bearbeiter.Mandant.MANDANT;
                Params.EBNR.Value = Params.EBID.Value.ToString();
                if ((Int16)Params.EBSTAT.Value == 0) Params.EBSTAT.Value = (Int16)EBStat.erfasst;
                //Params.PERSKEY.Value must be set
                Params.ERFDATUM.Value = DateTime.Now;
                Params.DATNEU.Value = DateTime.Now;
                Params.VORNAME.Value = Bearbeiter.Params.VORNAME.Value;
                Params.NACHNAME.Value = Bearbeiter.Params.NACHNAME.Value;
                Params.DATLEIST.Value = Params.BERMON.Value;
                Params.VGPERSKEY.Value = Bearbeiter.Vorgesetzter.Params.PERSKEY.Value;
                Params.KPERSKEY.Value = Bearbeiter.KaufmannPerskey;
                Params.KZGEDRUCKT.Value = "N";
                Params.PRPERSKEY.Value = DBNull.Value;
                Params.PRDATUM.Value = DBNull.Value;
                Params.AENPERSKEY.Value = Projekt.Baustelle.Bearbeiter.Params.PERSKEY.Value;
                Params.DATLA.Value = DateTime.Now;
                Params.EINGANGSD.Value = DBNull.Value;
                Params.DRDATUM.Value = DBNull.Value;
                Params.ABTEILUNG.Value = Bearbeiter.Params.ABTEILUNG.Value;
                Params.WBNR.Value = DBNull.Value;
                Params.EINSID.Value = DBNull.Value;
                Params.STDID.Value = Bearbeiter.Params.STDSTDID.Value;
                Params.DATPREISB.Value = Params.DATLEIST.Value;
                Params.DATARCHIV.Value = "N";
                Params.KDATUM.Value = DBNull.Value;
                Params.DATUGFAKT.Value = DBNull.Value;
                Params.SERIENNR.Value = DBNull.Value;
                Params.PDFSTATUS.Value = DBNull.Value;
                Params.PDFFAX.Value = DBNull.Value;
                Params.PDFMAIL.Value = DBNull.Value;
                //Params.INTF_ID.Value = DBNull.Value;
                Params.INTF_ID.Value = Convert.ToInt16(Projekt.INTF_ID);

                // Defect #4521: Die Adressdaten der Baustelle werden im
                //               Einsatzbericht gespeichert:
                //               Baustelle.Name nach EB.Name1 (evtl. EB.Name2 und 3)
                //               Baustelle.Ort  nach EB.Ort
                //               Baustelle.Strasse nach EB.Strasse
                //               Baustelle.Land nach EB.LKZ
                string strAddressData;
                // Baustellen-Name
                try
                {
                    if ((string)Projekt.Baustelle.Params.NAME.Value != "")
                    {
                        strAddressData = (string)Projekt.Baustelle.Params.NAME.Value;
                        if (strAddressData.Length < 41)
                        {
                            Params.KD_NAME1.Value = strAddressData;
                        }
                        else
                        {
                            Params.KD_NAME1.Value = strAddressData.Substring(1, 40);
                            if (strAddressData.Length < 81)
                            {
                                Params.KD_NAME2.Value = strAddressData.Substring(40);
                            }
                            else
                            {
                                Params.KD_NAME2.Value = strAddressData.Substring(40, 40);
                                Params.KD_NAME3.Value = strAddressData.Substring(80);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    strAddressData = ex.Message;
                }

                // Ort
                try
                {
                    if ((string)Projekt.Baustelle.Params.ORT.Value != "")
                    {
                        strAddressData = (string)Projekt.Baustelle.Params.ORT.Value;
                        if (strAddressData.Length < 41)
                        {
                            Params.KD_ORT.Value = strAddressData;
                        }
                        else
                        {
                            Params.KD_ORT.Value = strAddressData.Substring(0, 40);
                        }
                    }

                    // PLZ (10 Stellen in beiden Tabellen)
                    if ((string)Projekt.Baustelle.Params.PLZ.Value != "")
                    {
                        Params.KD_PLZ.Value = (string)Projekt.Baustelle.Params.PLZ.Value;
                    }
                }
                catch (Exception ex)
                {
                    strAddressData = ex.Message;
                }

                // Strasse
                try
                {
                    if ((string)Projekt.Baustelle.Params.STRASSE.Value != "")
                    {
                        strAddressData = (string)Projekt.Baustelle.Params.STRASSE.Value;
                        if (strAddressData.Length < 71)
                        {
                            Params.KD_STRASSE.Value = strAddressData;
                        }
                        else
                        {
                            Params.KD_STRASSE.Value = strAddressData.Substring(0, 70);
                        }
                    }
                }
                catch (Exception ex)
                {
                    strAddressData = ex.Message;
                }

                // L�nderkennzeichen (3 Stellen in EINSBER, 2 Stellen in Baustelle)
                try
                {
                    if ((string)Projekt.Baustelle.Params.LAND.Value != "")
                    {
                        Params.KD_LKZ.Value = (string)Projekt.Baustelle.Params.LAND.Value;
                    }
                }
                catch (Exception ex)
                {
                    strAddressData = ex.Message;
                }
                // Ende Defect #4521
            }
            else
            {
                sql = "sp_TM_EinsberUpdate";
                Params.AENPERSKEY.Value = Projekt.Baustelle.Bearbeiter.Params.PERSKEY.Value;
                Params.DATLA.Value = DateTime.Now;
                // TAP_IXOS_IUS bei I&S aktivieren
                try
                {
                    string pdfAct = ConfigurationManager.AppSettings["PdfStatusActiv"];
                    if (pdfAct.Contains(Params.MANDANT.Value.ToString()) &&
                        Convert.ToInt16(Params.EBSTAT.Value) == (Int16)EBStat.genehmigt)
                    {
                        Params.PDFSTATUS.DbType = DbType.Int16;
                        Params.PDFSTATUS.Value = (Int16)30; //Nur Ausdruck
                    }
                }
                catch
                { }
            }

            {
                SqlConnection cnx = null;
                try
                {

                    if (!inTransaction)
                    {
                        cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
                        cnx.Open();
                    }
                    else cnx = tx.Connection;
                    using (SqlCommand cmd = (inTransaction) ? new SqlCommand(sql, cnx, tx) : new SqlCommand(sql, cnx)) // Defect 5436
                    {

                        cmd.CommandType = CommandType.StoredProcedure;

                        // Beginn Defect 4496: Vor dem Erstellen der Parameterliste
                        // wird grunds�tzlich ein Clear() der Liste durchgef�hrt,
                        // um Exception zu vermeiden.
                        // Siehe: http://www.devnewsgroups.net/group/microsoft.public.dotnet.framework.adonet/topic14134.aspx
                        cmd.Parameters.Clear();
                        // Ende Defect 4496

                        foreach (SqlParameter s in Params.List)
                        {
                            string x = s.ParameterName;
                            cmd.Parameters.Add(s);
                        }

                        AllowUpdate = (cmd.ExecuteNonQuery() > 0);
                        foreach (SqlParameter s in Params.List) cmd.Parameters.Remove(s);
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { if (!inTransaction)cnx.Close(); }
            }

            // Beginn Defect #4520: Alle Arbeitszeiten werden in einem Array
            // gesammelt, nach Kommen-Stempel sortiert und mit aufsteigender
            // Zeilennummer versorgt.
            try
            {
                ArrayList alSortBeginTime = new ArrayList();

                // Zeiten der Normaltage sammeln
                foreach (dbArbTag at in Tage)
                {
                    foreach (dbArbZeit az in at.Zeiten)
                    {
                        // Exclude deleted timestamps and raw timestamps for
                        // weekend days (ParamVal.Date0)
                        if (!az.Deleted && az.Kommen != ParamVal.Date0)
                        {
                            alSortBeginTime.Add(az);
                        }
                    }
                }
                // Zeiten der Reisetage sammeln
                foreach (dbArbTag atr in ReiseTage)
                {
                    foreach (dbArbZeit az in atr.Zeiten)
                    {
                        // Exclude deleted timestamps and raw timestamps for
                        // weekend days (ParamVal.Date0)
                        if (!az.Deleted && az.Kommen != ParamVal.Date0)
                        {
                            alSortBeginTime.Add(az);
                        }
                    }
                }

                // Gesammelte Zeiten nach Kommen-Stempel sortieren
                dbArbZeitSort azSort = new dbArbZeitSort(dbArbZeitSort.SortByEnum.Kommen);
                alSortBeginTime.Sort(azSort);

                // Sortiertes Array mit aufsteigender Zeilennummer versorgen
                Int32 intLocalZnr = 0;
                foreach (dbArbZeit az in alSortBeginTime)
                {
                    intLocalZnr++;
                    az.intZnr = intLocalZnr;
                }
            }
            catch (Exception ex)
            {
                string strErrorMessage = ex.Message;
            }
            // Ende Defect #4520


            // Date         : 24.Februar 2007
            // Author       : GN
            // Defect#      : 4625: Her wird die Transaktion weitergegeben
            foreach (dbArbTag at in Tage) at.Save(tx);
            foreach (dbRAAuslage ra in Reiseauslagen) ra.Save(tx);
            foreach (dbAusZulage azl in Auszulagen) azl.Save(tx);
            foreach (dbArbTag at in ReiseTage) at.Save(tx);
        }

        /*public int ErsterTag
        {
            get
            {/// wir nehmen immo den ersten Tag mit einer Arbeitszeit
                foreach (dbArbTag t in Tage)
                    if (t.AnzahlMBZeiten > 0)return t.Tag;
                return 0;
            }
        }
        public int LetzterTag
        {
            get
            {/// wir nehmen immo den letzten Tag mit einer Arbeitszeit
                int i = 0;
                foreach (dbArbTag t in Tage)
                    if (t.AnzahlMBZeiten > 0) i = t.Tag;
                return i;
            }
        }*/

        /// <summary>
        /// Liefert die Summe der ARBZEIT.NORMSTD dieses Monats, die auf diesen Montagebericht gebucht wurden
        /// enth�lt ausschlie�lich GK, Produktiv und Reisezeiten, alle anderen == 0
        /// </summary>
        public double NormStunden
        {
            get
            {
                double x = 0;
                foreach (dbArbTag a in Tage)
                    x += a.NormStd;
                return x;
            }
        }
        /// <summary>
        /// Liefert die Summe der ARBZEIT.UESTD50 dieses Monats, die auf diesen Montagebericht gebucht wurden
        /// enth�lt ausschlie�lich GK, Produktiv und Reisezeiten, alle anderen == 0
        /// </summary>
        public double UE50
        {
            get
            {
                double x = 0;
                foreach (dbArbTag a in Tage)
                    x += a.UEStunden50;
                return x;
            }
        }
        /// <summary>
        /// Liefert die Summe der ARBZEIT.UESTD100 dieses Monats, die auf diesen Montagebericht gebucht wurden
        /// enth�lt ausschlie�lich GK, Produktiv und Reisezeiten, alle anderen == 0
        /// </summary>
        public double UE100
        {
            get
            {
                double x = 0;
                foreach (dbArbTag a in Tage)
                    x += a.UEStunden100;
                return x;
            }
        }

        /// <summary>
        /// Liefert die Summe der produktiven ARBZEIT.NORMSTD+UESTD50+UESTD100 dieses Montageberichts
        /// enth�lt keine GK, keine Reisezeiten, keine STD-Absenzen
        /// </summary>
        public double SummeProduktiveStunden
        {
            get
            {
                double x = 0;
                foreach (dbArbTag a in Tage)
                    x += a.SummeProduktiveStunden;
                return x;
            }
        }

    }
}