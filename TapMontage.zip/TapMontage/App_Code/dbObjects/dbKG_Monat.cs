//--------------------------------------------------------------------------------------
//
// Projekt      : TAP_Montage
//
// File         : dbKG_Monat.cs
//
// Description  : Datenbankobjekt f�r Berichtsmonat
//
//=============== V1.2.0011 ===================================================
//
// Date         : 27.September 2011
// Author       : Joldic Dzevad
// Defect#      : KMS BAN 500256 TAP-Montage: Erweiterte Zulagenpr�fung
//                Beim select von Zulagen, auch MaxAnzahl �bergeben
//
//=============== 1.0.0050 ================================================
//
// Date         : 06.Oktober 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500059
//                Anbindung an die neue SAP HR Schnittstelle
//
//=============== V1.0.0039 ===============================================
//
// Date         : 21.April 2008
// Author       : Joldic Dzevad
// Defect#      : 5899
//                ersteArbzeitImMonat definieren, damit das EBID aus Vormonat 
//                durch EBID aus aktuellen Monat ersetzt werden kann
//
//=============== V1.0.0038 ===============================================
//
// Date         : 19.M�rz 2008
// Author       : Joldic Dzevad
// Defect#      : 5940
//                Zulage bei ZA ganzt�gig bei B&I (MG) 
//
//--------------- V1.0.0027 ------------------------------------------------------------
//
// Date         : 24. Mai 2007
// Author       : Georg Nebehay
// Defect#      : 5107
//                Mandantenspezifisches Abschalten der �berleitung nach AZM von Fremdmitarbeitern eingebaut
//
//--------------------------------------------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace TapMontage.dbObjects
{

    /// <summary>
    /// Summary description for dbKG_Monat
    /// </summary>
    public class dbKG_Monat
    {
        public ArrayList RZalsAZ; //damit umgewandelte Reisezeilen in ARBZEIT abgespeichern k�nnen
        public dbArbZeit ersteArbzeitImMonat = null; //Defect #5899 - neues Parameter im KGMonat - ersteArbzeitImMonat
        public dbBearbeiter Monteur;
        public dbBearbeiter Genehmiger;
        private int lMonat = 0;
        public int Monat
        {
            get 
            { 
                return lMonat; 
            }
            set 
            { 
                lMonat = value;
                dbMontBer mmm = new dbMontBer(null, null);
                mmm.BerichtsMonat = lMonat;
                MinDatum = mmm.MinDatum;
                MaxDatum = mmm.MaxDatum;
            }
        }
        public DateTime MinDatum;
        public DateTime MaxDatum;
        public ArrayList AusZulagenProjekte;
        public ArrayList SEGZulagen;
        public dbKG_Rabrech Rabrech;

        private ArrayList lTage = null;
        public ArrayList Tage
        {
            get 
            {
                if (lTage == null)
                {
                    lTage = SelectTage();
                }
                return lTage;
            }
            set { lTage = value; }
        }

        public dbKG_Monat(dbBearbeiter monteur, int monat)
        {
            Monteur = monteur;
            Monat = monat;
            AusZulagenProjekte = SelectAusZulProjekte();
            SEGZulagen = SelectSEGZulagen();
            Rabrech = new dbKG_Rabrech(this); //Select muss von aussen (via Monat.Rabrech.Select(true)) aufgerufen werden 
        }

        private ArrayList SelectTage()
        {
            ArrayList al = new ArrayList();
            for (int i = MinDatum.Day; i <= MaxDatum.Day; i++)
            {
                dbKG_Tag t = new dbKG_Tag(this, i);
                al.Add(t);
            }
            return al;
        }
        public int SozStellung
        {
            get
            {
                //return Convert.ToInt32(Monteur.Params.PERSNR.Value.ToString().Substring(0, 2));
                return Convert.ToInt32(Monteur.TechParams.SOZSTELL.Value.ToString());
            }
        }

        //Defect 5107 GN
        //Gibt zur�ck, ob der Mitarbeiter Fremdpersonal ist UND ob im Webconfig-File der zugeh�rige Mandant
        //im Feld NoAZMFremdPersonal eingetragen wurde
        public bool UseAzm
        {
            get
            {
                string mandant = Monteur.Params.MANDANT.Value.ToString();
                string mndconfig = ConfigurationManager.AppSettings["NoAZMFremdpersonal"];
                string[] mnds = mndconfig.Split(' ');

                if (IstFremdPersonal)
                {
                    foreach (string s in mnds)
                    {
                        if (s == mandant) return false;
                    }
                }
                return true;

            }
        }

        public bool IstFremdPersonal
        {
            get
            {
                if (SozStellung == 6 || SozStellung == 7)
                    return true;
                return false;
            }

        }
        /// <summary>
        /// Enth�lt die Summe(NormSTD, UE50, UE100) der Produktiven Zeiten, kein GK, keine Absenzen
        /// </summary>
        public double SummeProduktiveStunden
        {
            get
            {
                double x = 0;
                foreach (dbKG_Tag e in Tage)
                {
                    x += e.NormStunden;
                    x += e.UE50;
                    x += e.UE100;
                }
                return x;
            }
        }
        /// <summary>
        /// Enth�lt die Summe(NormSTD, UE50, UE100) der Produktiven Zeiten mit stdAbsenzen
        /// </summary>
        public double SummeProduktiveStundenMitStdAbsenzen
        {
            get
            {
                double x = 0;
                foreach (dbKG_Tag e in Tage)
                {
                    x += e.NormStundenMitSTDAbsenzen;
                    x += e.UE50;
                    x += e.UE100;
                }
                return x;
            }
        }
        /// <summary>
        /// Enth�lt die Summe(NormStd) der produktiven Zeiten, keine �berstunden, kein GK, keine Absenzen
        /// </summary>
        public double NormStunden
        {
            get
            {
                double x = 0;
                foreach (dbKG_Tag e in Tage)
                    x += e.NormStunden;
                return x;
            }
        }
        /// <summary>
        /// Enth�lt die Summe(NormStd) der produktiven Zeiten, mit stdAbsenzen
        /// </summary>
        public double NormStundenMitStdAbsenz
        {
            get
            {
                double x = 0;
                foreach (dbKG_Tag e in Tage)
                    x += e.NormStundenMitSTDAbsenzen;
                return x;
            }
        }
        /// <summary>
        /// Enth�lt die Summe(UE50) der produktiven Zeiten, keine NormSTD, kein GK, keine Absenzen
        /// </summary>
        public double UE50
        {
            get
            {
                double x = 0;
                foreach (dbKG_Tag e in Tage)
                    x += e.UE50;
                return x;
            }
        }
        /// <summary>
        /// Enth�lt die Summe(UE100) der produktiven Zeiten, keine NormSTD, kein GK, keine Absenzen
        /// </summary>
        public double UE100
        {
            get
            {
                double x = 0;
                foreach (dbKG_Tag e in Tage)
                    x += e.UE100;
                return x;
            }
        }
        /// <summary>
        /// Enth�lt die Summe(NormSTD, ue50, ue100) der GK-Zeiten, sonst nix (niksch aundersch)
        /// </summary>
        public double GK
        {
            get
            {
                double x = 0;
                foreach (dbKG_Tag e in Tage)
                    x += e.GK;
                return x;
            }
        }
        private bool lEBStatus;
        public bool EBStatus
        {
            get
            {
                foreach (dbMontBer m in Monteur.MBerichte)
                {
                    switch (m.Params.EBSTAT.Value.ToString())
                    {
                        case "10":
                            lEBStatus = false;
                            break;
                        case "20":
                        case "30":
                        case "40":
                            lEBStatus = true;
                            break;
                    }
                }
                return lEBStatus;
            }
        }

        public string KG_Stat
        {
            get
            {
                string status = "kontrollieren";
                foreach (dbMontBer m in Monteur.MBerichte)
                {
                    if (m.Params.EBSTAT.Value.ToString() == "40")
                    {
                        status = "genehmigt";
                        return status;
                    }
                }
                return status;
            }
        }

        public int GTAbsenz
        {
            get
            {
                int x = 0;
                foreach (dbKG_Tag t in Tage)
                    if (t.GTAbsenz) x++;
                return x;
            }
        }

        private string[] mn = new string[] { "J�nner", "Februar", "M�rz", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember" };
        public string MonatText
        {
            get { return mn[MinDatum.Month - 1]; }
        }

        private ArrayList SelectAusZulProjekte()
        {
            ArrayList al = new ArrayList();
            foreach (dbMontBer m in Monteur.MBerichte)
            {
                dbKG_AusZulProjekt az = new dbKG_AusZulProjekt(m);
                al.Add(az);
            }
            return al;
        }
        private ArrayList SelectSEGZulagen()
        {
            ArrayList al = new ArrayList();
            foreach (dbMontBer m in Monteur.MBerichte)
            {
                dbKG_SEGZulage s = new dbKG_SEGZulage(m);
                if (s.SEGPKT != "-1")
                    al.Add(s);
            }
            return al;
        }

    }

    public class dbKG_AusZulProjekt
    {
        public ArrayList AusZulagen;
        public dbMontBer MBericht;
        public dbKG_AusZulProjekt(dbMontBer mbericht)
        {
            MBericht = mbericht;
            AusZulagen = SelectAusZulagen();
        }
        private ArrayList SelectAusZulagen()
        {
            ArrayList al = new ArrayList();
            foreach (dbAusZulage az in MBericht.Auszulagen)
            {
                dbKG_PMAusZulage pm = new dbKG_PMAusZulage(az.Params.LOHNART.Value.ToString(), az.Params.LOHNARTTXT.Value.ToString(), float.Parse(az.Params.ANZAHL.Value.ToString()), az.MaxAnzahl);
                al.Add(pm);
            }
            return al;
        }
        public string AuftragNr
        {
            get { return MBericht.Projekt.Params.KTOBJ.Value.ToString(); }
        }
    }

    public class dbKG_PMAusZulage
    {
        public dbKG_PMAusZulage(string lohnart, string text, float anzahl, float maxAnzahl)
        {
            Lohnart = lohnart;
            Text = text;
            Anzahl = anzahl;
            MaxAnzahl = maxAnzahl;
        }
        public string Lohnart = "";
        public string Text = "";
        public float Anzahl = 0;
        public float MaxAnzahl = 0f;
    }

    public class dbKG_SEGZulage
    {
        //Beginn Defect #5940 - 3 neue parameter 
        public int Perskey = 0;
        public string lohnArt = "";
        public int AnzTage = 0;
        //Ende Defect #5940
        public dbMontBer MBericht;
        public ArrayList SEGZulagen;
        public dbKG_SEGZulage(dbMontBer mbericht)
        {
            MBericht = mbericht;
        }

        public string AuftragNr
        {
            get { return MBericht.Projekt.Params.KTOBJ.Value.ToString(); }
        }
        public double BasisStunden
        {
            get 
            {                 
                double x = MBericht.SummeProduktiveStunden;
                return x;
            }
        }
        public double Prozent
        {
            get
            {
                double x = Convert.ToDouble(MBericht.Projekt.Params.SEGPKTPROZ.Value);
                return x;
            }
        }
        public string SEGPKT
        {
            get
            {
                return MBericht.Projekt.Params.SEGPKT.Value.ToString();
            }
        }
        public string Punkte
        {
            get
            {
                //if (Convert.ToInt32(MBericht.Projekt.Params.SEGPKT.Value) >= 0)
                if (MBericht.Projekt.Params.SEGPKT.Value.ToString() != "" && MBericht.Projekt.Params.SEGPKT.Value.ToString() != "-1")
                    return "1";
                else
                    return "0";
            }
        }
        public double Zulage
        {
            get
            {
                //double x = Convert.ToDouble(MBericht.Projekt.Params.SEGPKT.Value);
                double x = Convert.ToDouble(Punkte);
                //x = x * BasisStunden * Prozent / 100;
                x = x * BasisStunden;
                return x;
            }
        }
    }
}