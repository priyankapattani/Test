//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : SAPCache.cs
//
// Description  : SAPCache Objekt f�r caching der kontierbaren Objekt
//
//=============== V1.2.0015 ===============================================
//
// Date         : 04.September 2013
// Author       : Joldic Dzevad
// Defect#      : 
//                SAP Connector ausgelagert in eigenes Projekt 
//
//=============== V1.2.0009 ===============================================
//
// Date         : 24.J�nner 2010
// Author       : Joldic Dzevad
// Defect#      : 
//                Nur bei Testversion ... Exception wenn PSP nicht kontierbar ist
//
//=============== V1.2.0002 ===============================================
//
// Date         : 10.M�rz 2010
// Author       : Joldic Dzevad
// Defect#      : 
//                Anbindung an TapSapConnection
//
//=============== V1.0.0047 ===============================================
//
// Date         : 13.Februar 2009
// Author       : Joldic Dzevad
// Defect#      : TAPM-44
//                Erweiterung der Pr�fung auf kontierbares PS-Element mit 
//                Erlaubnis zur Kostenkontierung "KONT"
// Defect#      : TAPM-45
//                B&I CarveOut
//
//=============== V1.0.0037 ===============================================
//
// Date         : 29.Jaenner 2008
// Author       : Georg Nebehay
// Defect#      : 5700
//                Ersterstellung
//
//=========================================================================

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Text;

/* Mithilfe dieser Klasse k�nnen Kontoabfragen an SAP gecacht werden. Gecacht werden f�r eine Kontonummer
 * folgende Informationen:
 * - Bebuchbarkeitsstatus
 * - Auftragstyp
 * - Objektid
 * 
 * Bei einem Aufruf von Query() wird ein InfoObject zur�ckgegeben, dass alle diese Informationen enth�lt
 * und entweder aus aus dem Cache geholt wird oder nach einem SAP-Aufruf zur�ckgegeben wird.
 * 
 * Es k�nnen G�ltigkeitszeitr�ume f�r gecachte Eintr�ge im Web.config-File gesetzt werden, getrennt f�r
 * bebuchbare Nummern und nicht bebuchbare Nummern.
 * 
 * Der Cache ist als Singleton implementiert, auf deren Instanz mittels SAPCache.GetInstance() zugegriffen
 * werden kann.
 * */
namespace TapMontage.dbObjects
{
    public class SAPCache
    {
        private static SAPCache instance; //Objektinstanz
        private Dictionary<string, CacheObject> entries = new Dictionary<string, CacheObject>(); //Der eigentliche Cache

        private int validityPeriodBebuchbar = 60; //minutes
        private int validityPeriodNichtBebuchbar = 60; //minutes

        //Konstruktor holt Werte aus Web.config
        private SAPCache()
        {

            string bebuchbar = ConfigurationManager.AppSettings["ValidityPeriodBebuchbar"];
            string nichtBebuchbar = ConfigurationManager.AppSettings["ValidityPeriodNichtBebuchbar"];

            try
            {
                validityPeriodBebuchbar = Int32.Parse(bebuchbar);
            }
            catch (Exception) { }

            try
            {
                validityPeriodNichtBebuchbar = Int32.Parse(nichtBebuchbar);
            }
            catch (Exception) { }


        }

        //Liefert die Instanz zur�ck
        public static SAPCache GetInstance()
        {
            if (instance == null) instance = new SAPCache();
            return instance;
        }

        //Anfrage an den Cache - Ruft je nach Cachestatus SAP auf oder gibt Cacheobjekt zur�ck
        public InfoObject Query(String auftrnr)
        {

            auftrnr = auftrnr.ToUpper();

            CacheObject obj;
            if (!entries.ContainsKey(auftrnr)) //Noch nicht im Cache vorhanden
            {
                obj = QuerySAP(auftrnr);
                Cache(auftrnr, obj);
            }
            else //Cacheobjekt ist schon vorhanden
            {
                obj = entries[auftrnr];

                DateTime expiryTime; //Enth�lt Datum, wann das Objekt ung�ltig wird

                if (obj.InfoObject.Bebuchbar)
                {
                    expiryTime = obj.QueryTime.AddMinutes(validityPeriodBebuchbar);
                }
                else expiryTime = obj.QueryTime.AddMinutes(validityPeriodNichtBebuchbar);

                if (expiryTime < DateTime.Now) //�berpr�fung, ob Objekt abgelaufen ist
                {
                    obj = QuerySAP(auftrnr);
                    Cache(auftrnr, obj);
                }
            }

            return obj.InfoObject;

        }

        //Nimmt nur Objekte in den Cache auf, die fehlerlos zustande gekommen sind.
        private void Cache(string auftrnr, CacheObject obj)
        {
            if (obj.InfoObject.Err == "00") entries[auftrnr] = obj;
        }

        public bool RemoveFromCache(string auftrn)
        {
            return entries.Remove(auftrn);
        }


        //Der eigentliche SAP-Aufruf
        private CacheObject QuerySAP(string auftrnr)
        {
            //TAPM-45 auftrnr = TAPMandant + altesAuftragnummer
            //deswegen wird auftrnr geteilt
            string TAPMandant = "";
            if (auftrnr.Length > 2 && auftrnr[0] == 'M' && auftrnr[2] == '$')
            {
                TAPMandant = auftrnr.Substring(0, 2);
                auftrnr = auftrnr.Substring(3, auftrnr.Length - 3);
            }
            //TAPM-45 Ende
            if (auftrnr == "") //leere Auftragsnummern gehen gar nicht an SAP
            {
                InfoObject io = new InfoObject();
                io.Ktobj = ""; //Wenn keine auftragsnummer versorgt, dann error 99 (wie von sap)
                io.Err = "99";

                CacheObject co = new CacheObject();
                co.QueryTime = DateTime.Now;
                co.InfoObject = io;

                return co;
            }
            string connStr = ConfigurationManager.AppSettings["SAPConnectionString"];
            //TAPM-45 ist ein SAPConnectionStringMx in Web.Config definiert, dann wird diese f�r
            //SAP Connection verwendet. Default ist SAPConnectionString.
            if (ConfigurationManager.AppSettings["SAPConnectionString" + TAPMandant] != null)
                connStr = ConfigurationManager.AppSettings["SAPConnectionString" + TAPMandant];

            string Err = "";
            string Ktobj = "";
            string Inact = "";
            string Autyp = "";
            string Objid = "";
            string Belkz = "";

            InfoObject obj = new InfoObject();
            SAPconnector.SAPcheck.GetKontoInfo(connStr, auftrnr, ref Err, ref Ktobj, ref Inact, ref Autyp, ref Objid, ref Belkz);
            obj.Err = Err;
            obj.Ktobj = Ktobj;
            obj.Inact = Inact;
            obj.Autyp = Autyp;
            obj.Objid = Objid;
            obj.Belkz = Belkz; //TAPM-44 Kostenkontierung

            CacheObject cacheObject = new CacheObject();
            cacheObject.QueryTime = DateTime.Now;
            cacheObject.InfoObject = obj;

            return cacheObject;

            //V1.2.0015 Alte Code auskomentiert
            //TAP_SAPProxy SapCon = new TAP_SAPProxy();
            //SapCon.Connection = SAP.Connector.SAPConnectionPool.GetConnectionFromPool(connStr);
            //SapCon.Connection.Open();
            //string Err = "";
            //SIE_SSA_CS_KONT_TAPTable retTable = new SIE_SSA_CS_KONT_TAPTable();
            //try
            //{
            //    SapCon.Sie_Ssa_Cs_Check_Kont_Objects(auftrnr, out Err, ref retTable);
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}
            //finally
            //{
            //    SapCon.Connection.Close();
            //    SAP.Connector.SAPConnectionPool.ReturnConnection(SapCon.Connection);
            //}
            //if (retTable.Count > 1)
            //{
            //    Exception ex = new Exception("dbProjekt::CheckSAP:Eindeutigkeit bei Kont-Objekt nicht gegeben!");
            //    throw ex;
            //}
            //InfoObject obj = new InfoObject();
            //obj.Ktobj = ""; //Wenn keine S�tze gefunden wurden ist das ein Zeichen f�r Nichtbebuchbarkeit
            //obj.Err = Err;
            //foreach (SIE_SSA_CS_KONT_TAP x in retTable)
            //{
            //    obj.Ktobj = x.Ktobj;
            //    obj.Inact = x.Inact;
            //    obj.Autyp = x.Autyp;
            //    obj.Objid = x.Objid;
            //    obj.Belkz = x.Belkz; //TAPM-44 Kostenkontierung
            //}
            //CacheObject cacheObject = new CacheObject();
            //cacheObject.QueryTime = DateTime.Now;
            //cacheObject.InfoObject = obj;
            //return cacheObject;
        }
    }

    //CacheObjekt enth�lt Infoobjekt und Datum der Abfrage
    public class CacheObject
    {

        private DateTime queryTime;
        private InfoObject infoObject;


        public DateTime QueryTime
        {
            get { return queryTime; }
            set { queryTime = value; }
        }

        public InfoObject InfoObject
        {
            get { return infoObject; }
            set { infoObject = value; }
        }



    }

    //Objekt, dass die Daten enth�lt
    public class InfoObject
    {

        private string ktobj;
        private string inact;
        private string autyp;
        private string objid;
        private string belkz;
        private string err;

        public string Ktobj
        {
            get { return ktobj; }
            set { ktobj = value; }
        }
        public string Inact
        {
            get { return inact; }
            set { inact = value; }
        }
        public string Autyp
        {
            get { return autyp; }
            set { autyp = value; }
        }
        public string Objid
        {
            get { return objid; }
            set { objid = value; }
        }
        //TAPM-44 Kostenkontierung  wird unter Belkz in SAP bekannt
        public string Belkz
        {
            get { return belkz; }
            set { belkz = value; }
        }

        public string Err
        {
            get { return err; }
            set { err = value; }
        }

        public bool Bebuchbar
        {
            get
            {
                //TAPM-44 - ist es ein PSP Element und ist diese Kontierbar
                bool kont = true;
                if (Objid == "PR" && belkz == "")
                    kont = false;
                return (Inact == "") && (Err == "00") && kont;
            }
        }

    }
}