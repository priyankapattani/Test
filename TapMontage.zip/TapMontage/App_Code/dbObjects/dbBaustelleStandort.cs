//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbBaustelleStandort.cs
//
// Description  : Definieren der Parameter f�r Baustelle-Standort,
//                Anlegen eines Standortes
//
//=============== V1.0.0043 ===============================================
//
// Date         : 30.Juni 2008
// Author       : Joldic Dzevad
// Defect#      : 6045
//                Standortwechsel bei Baustellenwechsel wird nicht generiert
//
//=============== V1.0.0037 ===============================================
//
// Date         : 14.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 14.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
// Date         : 13.Dezember 2007
// Author       : Georg Nebehay
// Defect#      : 5674
//                Fehler beim �ndern von Baustellenstandorten
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//=============== V1.0.0029 ===================================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for dbBaustelleStandort
/// </summary>
namespace TapMontage.dbObjects
{
  public class dbBaustelleStandortParams
  {
    public SqlParameter BAUID = new SqlParameter("@BAUID", Int32.MinValue);
    public SqlParameter STDID = new SqlParameter("@STDID", Int32.MinValue);
    public SqlParameter BAUID_STDW = new SqlParameter("@BAUID_STDW", Int32.MinValue);
    public SqlParameter RATYP = new SqlParameter("@RATYP", Int32.MinValue);
    public SqlParameter WEGZEIT = new SqlParameter("@WEGZEIT", Int32.MinValue);
    public SqlParameter REISEZEIT = new SqlParameter("@REISEZEIT", Int32.MinValue);
    public SqlParameter KM = new SqlParameter("@KM", Int32.MinValue);
    public SqlParameter RAKZ_VM = new SqlParameter("@RAKZ_VM", (string)"");
    public SqlParameter RAKZ_B = new SqlParameter("@RAKZ_B", (string)"");
    public ArrayList List = new ArrayList();

    public dbBaustelleStandortParams()
    {
      List.Add(BAUID);
      List.Add(STDID);
      List.Add(BAUID_STDW);
      List.Add(RATYP);
      List.Add(WEGZEIT);
      List.Add(REISEZEIT);
      List.Add(KM);
      List.Add(RAKZ_VM);
      List.Add(RAKZ_B);
      List = ParamVal.SetDefaultValues(List);
    }

  }

  public class dbBaustelleStandort
  {
    public dbBaustelleStandortParams Params = new dbBaustelleStandortParams();
    public string RAKZ_VMTEXT = "";
    public string RAKZ_BTEXT = "";
    public dbBaustelle Baustelle;
    public dbStandort Standort;
    public enum Einsatz { StandOrtZuBaust = 0, BaustZuBaust = 1, BaustZuQuartier = 2 };
    public int EinsatzTyp;
    public int iSaveDBRecIdent;


    public dbBaustelleStandort(dbBaustelle dbb, dbStandort dbs)
    {
      Baustelle = dbb;
      if (Baustelle == null) Baustelle = new dbBaustelle(null);
      Standort = dbs;
      if (Standort == null) Standort = new dbStandort(null);

      //Params.BAUID = Baustelle.Params.BAUID;
      //Params.STDID = Standort.Params.STDID;
    }

    /// <summary>
    /// Private Properties
    /// </summary>
    public bool AllowUpdate = false;
    public bool Deleted = false;

    public bool Insert()
    {
      Params.BAUID.Value = Baustelle.Params.BAUID.Value;
      ParamVal.InsertValid(Params.List);
      using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
      {
        try
        {
          cnx.Open();
          using (SqlCommand cmd = new SqlCommand("sp_TM_BaustelleStandortInsert", cnx)) // Defect 5436, using eingef�hrt
          {
            cmd.CommandType = CommandType.StoredProcedure;

            
            //Defect 5674
            //GN 13.12.2007
            //Folgende zwei Zeilen verhindern, dass der Parameter Wegzeit, der ja nur die ID des ge�nderten Standortes enth�lt, mitgespeichert wird.
            //Der ist n�mlich nur f�r die aktuelle Session interessant.
            int tmpid = (int)Params.WEGZEIT.Value;
            Params.WEGZEIT.Value = 0;

            foreach (SqlParameter s in Params.List)
            {
                cmd.Parameters.Add(s);
            }

             
            int nRecs = cmd.ExecuteNonQuery();
            
            //Hier wird der Parameter wieder hinzugef�gt
            Params.WEGZEIT.Value = tmpid;
  
              
            string sqltxt = cmd.CommandText;
            string paramBAUID = Params.BAUID.Value.ToString();
            string paramSTDID = Params.STDID.Value.ToString();
            string paramBAUID_STDW = Params.BAUID_STDW.Value.ToString();
            iSaveDBRecIdent = Int32.Parse(Params.STDID.Value.ToString());
            foreach (SqlParameter s in Params.List)
              cmd.Parameters.Remove(s);
            AllowUpdate = (nRecs > 0);
          }
        }
        catch (Exception ex) { throw ex; }
        finally { cnx.Close(); }
      }
      return AllowUpdate;
    }

    public ArrayList SelectAllforBaustelle()
    {
      ArrayList al = new ArrayList();
      using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
      {
        try
        {
          cnx.Open();
          // Defect 5725, Config.Rowlock eingef�hrt
          // Defect 5771, Config.Rowlock eingef�hrt
          using (SqlCommand cmd = new SqlCommand("Select BAUID, STDID, BAUID_STDW, RATYP, WEGZEIT, REISEZEIT, KM, RAKZ_VM, RAKZ_B, isnull(v1.RAKZTXT, '') as RAKZ_VMTEXT, isnull(v2.RAKZTXT, '') as RAKZ_BTEXT " +
                                                 "From BAUSTELLE_STD " + Config.Nolock +
                                                 " LEFT OUTER JOIN Y_RAKZ as v1 " + Config.Nolock +
                                                 " ON v1.RAKZID = 'VM' AND v1.RAKZ = BAUSTELLE_STD.RAKZ_VM " +
                                                 "LEFT OUTER JOIN Y_RAKZ as v2 " + Config.Nolock +
                                                 " ON v2.RAKZID = 'B' AND v2.RAKZ = BAUSTELLE_STD.RAKZ_B WHERE BAUID = @BAUID  ", cnx)) // Defect 5436
          {
            cmd.Parameters.Add(Baustelle.Params.BAUID);
            using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SequentialAccess)) // Defect 5436
            {
              cmd.Parameters.Remove(Baustelle.Params.BAUID);
              while (rd.Read())
              {
                dbBaustelleStandort bs = new dbBaustelleStandort(Baustelle, null);
                ParamVal.SetDefaultValues(bs.Params.List);
                bs.Params.BAUID.Value = Baustelle.Params.BAUID.Value;
                bs.Params.STDID.Value = rd.GetValue(1);
                bs.Params.BAUID_STDW.Value = rd.GetValue(2);
                bs.Params.RATYP.Value = rd.GetValue(3);
                bs.Params.WEGZEIT.Value = rd.GetValue(4);
                bs.Params.REISEZEIT.Value = rd.GetValue(5);
                bs.Params.KM.Value = rd.GetValue(6);
                bs.Params.RAKZ_VM.Value = rd.GetValue(7);
                bs.Params.RAKZ_B.Value = rd.GetValue(8);
                // Defect #6045 - erkennen das Einsatztyp
                if (bs.Params.RAKZ_B.Value.ToString() == "")
                {
                    //zu Quartier
                    bs.EinsatzTyp = (int) dbBaustelleStandort.Einsatz.BaustZuQuartier;
                }
                else
                    if (bs.Params.BAUID_STDW.Value.ToString() != "0")
                    {
                        //baustelle zu baustelle
                        bs.EinsatzTyp = (int) dbBaustelleStandort.Einsatz.BaustZuBaust;
                    }
                    else
                        bs.EinsatzTyp = (int) dbBaustelleStandort.Einsatz.StandOrtZuBaust;
                bs.RAKZ_VMTEXT = rd.GetString(9);
                bs.RAKZ_BTEXT = rd.GetString(10);
                bs.AllowUpdate = true;
                //bs.EinsatzTyp = Int32.Parse(bs.Params.BAUID_STDW.Value.ToString());
                bs.iSaveDBRecIdent = Int32.Parse(bs.Params.STDID.Value.ToString());
                bs.Deleted = false;
                al.Add(bs);
              }
            }
          }
        }
        catch (Exception ex) { throw ex; }
        finally { cnx.Close(); }
      }
      return al;
    }

    public bool Update()
    {
      if (!AllowUpdate)
      {
        Delete();
        return Insert();
      }
      else
      {
        Delete();
        Insert();
        /*
                        ParamVal.InsertValid(Params.List);
                        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
                        {
                            try
                            {
                                cnx.Open();
                                SqlCommand cmd = new SqlCommand("sp_TM_BaustelleStandortUpdate", cnx);
                                cmd.CommandType = CommandType.StoredProcedure;
                                foreach (SqlParameter s in Params.List)
                                    cmd.Parameters.Add(s);
                                int nRecs = cmd.ExecuteNonQuery();
                                foreach (SqlParameter s in Params.List)
                                    cmd.Parameters.Remove(s);
                                AllowUpdate = (nRecs > 0);
                                if (!AllowUpdate)
                                {
                                    Exception ex = new Exception("dbBaustelle::Update: Update failed!");
                                    throw ex;
                                }
                            }
                            catch (Exception ex) { throw ex; }
                            finally { cnx.Close(); }
                        }
                        */
      }
      return AllowUpdate;
    }

    public bool Delete()
    {
      ParamVal.InsertValid(Params.List);
      //if (AllowUpdate)
      using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
      {
        try
        {
          cnx.Open();
          // Defect 5725, Config.Rowlock eingef�hrt
          using (SqlCommand cmd = new SqlCommand("Delete from BAUSTELLE_STD " + Config.Rowlock + " where BAUID = @BAUID and STDID=@STDID and BAUID_STDW=@BAUID_STDW", cnx))  // Defect 5436
          {
            cmd.Parameters.Add(Params.BAUID);
            cmd.Parameters.Add(Params.STDID);
            cmd.Parameters.Add(Params.BAUID_STDW);
            int nRecs = cmd.ExecuteNonQuery();
            string sqltxt = cmd.CommandText;
            string paramBAUID = Params.BAUID.Value.ToString();
            string paramSTDID = Params.STDID.Value.ToString();
            string paramBAUID_STDW = Params.BAUID_STDW.Value.ToString();
            cmd.Parameters.Remove(Params.BAUID);
            cmd.Parameters.Remove(Params.STDID);
            cmd.Parameters.Remove(Params.BAUID_STDW);
          }
        }
        catch (Exception ex) { throw ex; }
        finally { cnx.Close(); }
      }
      return AllowUpdate;
    }

    public ArrayList SelectAll()
    {
      ArrayList al = new ArrayList();
      return al;
    }
  }
}