//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbBarauslagen.cs
//
// Description  : Barauslagen
//
//=============== V1.2.0017 ===============================================
//
// Date         : 18.November 2013
// Author       : Joldic Dzevad
// Defect#      : TT 6654245
//                Bei @CENT soll decimal anstatt float verwendet werden
//
//=============== V1.0.0037 ===============================================
//
// Date         : 14.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//=============== V1.0.0029 ===============================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=========================================================================

using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using TapMontage.dbObjects;

public class dbBaustelleStandortParams
{
    public SqlParameter BAUID = new SqlParameter("@BAUID", Int32.MinValue);
    public SqlParameter TYP = new SqlParameter("@TYP", "");
    //TT - 6654245 - verwende decimal anstatt float
    public SqlParameter CENTS = new SqlParameter("@CENTS", SqlDbType.Decimal) ; //(float)0);
    public SqlParameter ANZ = new SqlParameter("@ANZ", Int32.MinValue);
    public SqlParameter AUSLAGENID = new SqlParameter("@AUSLAGENID", Int32.MinValue);
    public ArrayList List = new ArrayList();

    public dbBaustelleStandortParams()
    {
        List.Add(BAUID);
        List.Add(TYP);
        List.Add(CENTS);
        List.Add(ANZ);
        List.Add(AUSLAGENID);
        List = ParamVal.SetDefaultValues(List);
    }

}


/// <summary>
/// Summary description for dbBarauslagen
/// </summary>
public class dbBarauslagen
{

  public dbBaustelleStandortParams Params = new dbBaustelleStandortParams();
  public dbBaustelle Baustelle;

  public dbBarauslagen(dbBaustelle baustelle)
  {
    this.Baustelle = baustelle;
  }

  public bool AllowUpdate = false;
  public bool Deleted = false;

  public bool Insert()
  {
    Params.BAUID.Value = Baustelle.Params.BAUID.Value;
    ParamVal.InsertValid(Params.List);
    using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
    {
      try
      {
        cnx.Open();
        using (SqlCommand cmd = new SqlCommand("sp_TM_BaustelleBarauslageInsert", cnx)) // Defect 5436, using eingef�hrt
        {
          cmd.CommandType = CommandType.StoredProcedure;
          Params.List.Remove(Params.AUSLAGENID);
          foreach (SqlParameter s in Params.List)
            cmd.Parameters.Add(s);
          int nRecs = cmd.ExecuteNonQuery();
          AllowUpdate = (nRecs > 0);
          //Params.AUSLAGENID.Value = id;
          string sqltxt = cmd.CommandText;

          foreach (SqlParameter s in Params.List)
            cmd.Parameters.Remove(s);

          Params.List.Add(Params.AUSLAGENID);
        }
      }
      catch (Exception ex) { throw ex; }
      finally { cnx.Close(); }
    }
    return AllowUpdate;
  }

  //public float calcSumme()
  //{
  //  return Convert.ToSingle(Params.CENTS.Value) * Convert.ToSingle(Params.ANZ.Value);
  //}

  public ArrayList SelectAllforBaustelle()
  {
    ArrayList al = new ArrayList();
    if (Int32.Parse(Baustelle.Params.BAUID.Value.ToString()) > 0)
    {
      using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
      {
        cnx.Open();
        // Defect 5725, Config.Rowlock eingef�hrt
        // Defect 5771, Config.Nolock eingef�hrt
        using (SqlCommand cmd = new SqlCommand("Select BAUID, AUSLAGENID, TYP, CENTS, ANZ From BAUSTELLE_BARAUSLAGEN " + Config.Nolock + " where bauid = @BAUID", cnx)) // Defect 5436
        {
          cmd.Parameters.Add(Baustelle.Params.BAUID);
          using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SequentialAccess)) // Defect 5436
          {
            cmd.Parameters.Remove(Baustelle.Params.BAUID);
            while (rd.Read())
            {
              dbBarauslagen bs = new dbBarauslagen(Baustelle);
              ParamVal.SetDefaultValues(bs.Params.List);
              bs.Params.BAUID.Value = Baustelle.Params.BAUID.Value;
              bs.Params.AUSLAGENID.Value = rd.GetValue(1);
              bs.Params.TYP.Value = rd.GetValue(2);
              bs.Params.CENTS.Value = rd.GetValue(3);
              bs.Params.ANZ.Value = rd.GetValue(4);
              bs.AllowUpdate = true;
              bs.Deleted = false;
              al.Add(bs);
            }
            //catch (Exception ex) { throw ex; }
            //finally { cnx.Close(); }
            cnx.Close();
          }
        }
      }
    }
    return al;
  }

  public bool Update()
  {
    ParamVal.InsertValid(Params.List);
    using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
    {
      try
      {
        cnx.Open();
        using (SqlCommand cmd = new SqlCommand("sp_TM_BaustelleBarauslageUpdate", cnx)) // Defect 5436
        {
          cmd.CommandType = CommandType.StoredProcedure;
          foreach (SqlParameter s in Params.List)
            cmd.Parameters.Add(s);
          int nRecs = cmd.ExecuteNonQuery();
          foreach (SqlParameter s in Params.List)
            cmd.Parameters.Remove(s);
          AllowUpdate = (nRecs > 0);
        }
        if (!AllowUpdate)
        {
          Exception ex = new Exception("dbBaustelleBarauslagen::Update: Update failed!");
          throw ex;
        }
      }
      catch (Exception ex) { throw ex; }
      finally { cnx.Close(); }
    }
    return AllowUpdate;
  }

  public void Delete()
  {
    ParamVal.InsertValid(Params.List);
    if (Deleted)
    {
      using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
      {
        try
        {
          cnx.Open();
          // Defect 5725, Config.Rowlock eingef�hrt
          using (SqlCommand cmd = new SqlCommand("Delete from BAUSTELLE_BARAUSLAGEN " + Config.Rowlock + " where BAUID = @BAUID and AUSLAGENID=@AUSLAGENID", cnx)) // Defect 5436
          {
            cmd.Parameters.Add(Params.BAUID);
            cmd.Parameters.Add(Params.AUSLAGENID);
            cmd.ExecuteNonQuery();
            string sqltxt = cmd.CommandText;
            string paramBAUID = Params.BAUID.Value.ToString();
            cmd.Parameters.Remove(Params.BAUID);
            cmd.Parameters.Remove(Params.AUSLAGENID);
          }
        }
        catch (Exception ex) { throw ex; }
        finally { cnx.Close(); }
      }
    }
  }
}
