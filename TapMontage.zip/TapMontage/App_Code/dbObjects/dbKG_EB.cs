// --------------------------------------------------------------------------------------
//
// Projekt      : TAP_Montage
//
// File         : dbKG_EB.cs
//
// Description  : Erstellung Einsatzberichte
//
//--------------- V1.0.0044 -------------------------------------------------------------
//
// Date         : 26. August 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-20
//                Rufbereitschaft
//
//--------------- V1.0.0028 -------------------------------------------------------------
//
// Date         : 21. Juni 2007
// Author       : Caleb Gebhardt 
// Defect#      : 4300, 4947
//
// Die Reisezeit innerhalb der Normalarbeitszeit muss in der Summe der 
// Normalstunde (in der Anzeige "Kontrolle & Genehmigung - Arbeitszeiten" )
// dazugerechnet werden. 
//
//--------------- V1.0.0020 ------------------------------------------------------------
//
// Date         : 31. J�nner 2007
// Author       : CL
// Defect#      : 4462
//
// Falsche Darstellung der Normalstunden.
// Bei ganzt�gigen Absenzen m�ssen, falls in der DB eingetragen, auch die Pausenzeiten
// abgezogen werden.
//
// -------------------------------------------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace TapMontage.dbObjects
{
    /// <summary>
    /// Tageweise/Projektweise Sicht
    /// </summary>
    public class dbKG_EB
    {
        public dbMontBer MBericht;
        public int Tag = 0;
        public dbKG_EB(dbMontBer MontageBericht, int iTag)
        {
            MBericht = MontageBericht;
            Tag = iTag;
        }
        private ArrayList lArbZeit = null;
        public ArrayList ArbZeit
        {
            set { lArbZeit = value; }
            get
            {
                if (lArbZeit == null)
                {
                    lArbZeit = SelectAZTag();
                }
                return lArbZeit;
            }
        }

        private ArrayList lReiseZeit = null;
        public ArrayList ReiseZeit
        {
            set { lReiseZeit = value; }
            get
            {
                if (lReiseZeit == null)
                {
                    lReiseZeit = SelectAZReiseTag();
                }
                return lReiseZeit;
            }
        }

        private ArrayList lReiseAusl = null;
        public ArrayList ReiseAusl
        {
            set { lReiseAusl = value; }
            get
            {
                if (lReiseAusl == null)
                {
                    lReiseAusl = SelectRATag();
                }
                return lReiseAusl;
            }
        }
        private ArrayList SelectRATag()
        {
            ArrayList al = new ArrayList();
            foreach (dbRAAuslage r in MBericht.Reiseauslagen)
            {
                if (Convert.ToDateTime(r.Params.DATUM.Value).Day == Tag)
                {
                    dbKG_RATag rt = new dbKG_RATag();
                    rt.Anzahl = float.Parse(r.Params.ANZAHL.Value.ToString());
                    rt.Auslagenart = r.RAKZText;
                    rt.Betrag = float.Parse(r.Params.BETRAG.Value.ToString());
                    al.Add(rt);
                }
            }
            return al;
        }
        /// <summary>
        /// f�llt ArbZeit mit objekten vom Typ dbKG_AZTag(gk,produktiv,gtAbsenz) und dbKG_AZTagSTDAbsenz(std-Absenz)
        /// </summary>
        /// <returns></returns>
        private ArrayList SelectAZTag()
        {
            ArrayList al = new ArrayList();
            foreach (dbArbZeit z in (MBericht.Tage[Tag - 1] as dbArbTag).Zeiten)
            {
                if ((int)MBericht.Params.EBID.Value != 0)
                {
                    if ((z.Params is dbAZ_ARBZEITParams) && ((int)(z.Params as dbAZ_ARBZEITParams).EBID.Value == (int)MBericht.Params.EBID.Value))
                    {
                        //TAPM-20 Bereitschaft als neues Parameter definieren
                        bool Bereitschaft = ((z.Params as dbAZ_ARBZEITParams).BEREIT.Value.ToString() == "1"); //TAPM-20 Bereitschaft mitliefern
                        if (z.ZeitTyp == dbArbZeit.ArbZeitType.gk)
                            al.Add(new dbKG_AZTag(z.NormStunden, z.UEStunden50, z.UEStunden100, z.NormStunden + z.UEStunden50 + z.UEStunden100, z.Leistart, z.GKAuftragNR, 0, 0, true, z.Kommen, z.Gehen, Bereitschaft));
                        if (z.ZeitTyp == dbArbZeit.ArbZeitType.produktiv)
                            al.Add(new dbKG_AZTag(z.NormStunden, z.UEStunden50, z.UEStunden100, 0, z.Leistart, MBericht.Projekt.Params.KTOBJ.Value.ToString(), 0, 0, false, z.Kommen, z.Gehen, Bereitschaft));
                        if (z.ZeitTyp == dbArbZeit.ArbZeitType.stdAbsenz)
                        {
                            /* Beginn Defect 4462: Auch der Pausenwert des Tages wird
                             *                     dem GT_Absenz-Objekt �bergeben
                             * */
                            al.Add(new dbKG_AZTagSTDAbsenz(z.Kommen,
                                                           z.Gehen ,
                                                           z.Pause , // Ende Defect 4462
                                                           z.STDAbsenzID ,
                                                           z.StdAbsenzTxt));
                        }
                    }
                }
                else
                {
                    dbKG_AZTag t = null;
                    if (z.ZeitTyp == dbArbZeit.ArbZeitType.gtAbsenz)
                        t = new dbKG_AZTag(0, 0, 0, 0, "", z.GTAbsenzTXT, z.GTAbsenzID, z.GTAzmNR, false, z.Kommen, z.Gehen, false);
                    if (t != null) al.Add(t);
                }
            }
            return al;
        }
        /// <summary>
        /// f�llt ReiseZeit mit Objekten vom Typ dbKG_AZReiseTag (ReiseInner... und Au�erhalb... unterscheidet sich durch AZMKommen und AZMGehen bei Au�erhalb nicht gesetzt==>> keine �bertragung an AZM)
        /// </summary>
        /// <returns></returns>
        private ArrayList SelectAZReiseTag()
        {
            ArrayList al = new ArrayList();
            if (MBericht.RAbrech != null)
                foreach (dbArbZeit z in (MBericht.ReiseTage[Tag - 1] as dbArbTag).Zeiten)
                {
                    if (!z.Deleted)
                    {
                        object t = null; 
                        if (z.ZeitTyp == dbArbZeit.ArbZeitType.ReiseInDienstzeit)
                            // Defect 4300, 4947: der 10. Parameter versogt - Dieser dient dazu die "W" - Stempel zu erkennen.
                            // und daher die richtige Versorgung sehr wichtig f�r diesen Defect
                            t = new dbKG_AZReiseTag(z.NormStunden, z.UEStunden50, z.UEStunden100, "Reisezeit", MBericht.Projekt.Params.KTOBJ.Value.ToString(), z.Kommen, z.Gehen, z.Kommen, z.Gehen, z.ZeitTyp);
                        if (z.ZeitTyp == dbArbZeit.ArbZeitType.ReiseVorherNachher)
                            t = new dbKG_AZReiseTag(z.NormStunden, z.UEStunden50, z.UEStunden100, "Reisezeit", MBericht.Projekt.Params.KTOBJ.Value.ToString(), z.Kommen, z.Gehen, ParamVal.Date0, ParamVal.Date0, z.ZeitTyp);
                        if (t != null) al.Add(t);
                    }
                }
            return al;
        }
    }

    public class dbKG_AZTag
    {
        public dbKG_AZTag(double NormStd, double ue50, double ue100, double gk, string LA, string Auftr, int GtAbsenzID,int gtazmnr, bool istGk, DateTime kommen, DateTime gehen, bool bereit)
        {
            NormStunden = NormStd;
            UE50 = ue50;
            UE100 = ue100;
            GK = gk;
            Lohnart = LA;
            Auftrag = Auftr;
            GTAbsenzID = GtAbsenzID;
            GTAzmNR = gtazmnr;
            istGK = istGk;
            Kommen = kommen;
            Gehen = gehen;
            Bereitschaft = bereit;//TAPM-20 - ist es ein Einsatz w�hrent der Rufbereitschaft
        }
        //Arbeitszeit lt. EB
        /// <summary>
        /// ARBZEIT.NORMSTD bei GK und Produktiv, 0 bei GT-Absenz
        /// </summary>
        public double NormStunden = 0;
        /// <summary>
        /// ARBZEIT.UESTD50 bei GK und Produktiv, 0 bei GT-Absenz
        /// </summary>
        public double UE50 = 0;
        /// <summary>
        /// ARBZEIT.UESTD100 bei GK und Produktiv, 0 bei GT-Absenz
        /// </summary>
        public double UE100 = 0;
        /// <summary>
        /// Summe(NORMSTD, UESTD50, UESTD100) bei GK, bei Produktiv und GT-Absenz == 0
        /// </summary>
        public double GK = 0;
        /// <summary>
        /// ARBZEIT.LEISTART, bei GT-Absenz ""
        /// </summary>
        public string Lohnart = "";
        /// <summary>
        /// GK != 0: GK-Auftragnummer, Produktiv KTOBJ des Projekts, GT-Absenz: ArbZeit.GTAbsenzTXT (=Urlaub, Krankheit,...)
        /// </summary>
        public string Auftrag = "";
        public int GTAbsenzID = 0;
        public int GTAzmNR = 0;
        public bool istGK = false;
        public DateTime Kommen;
        public DateTime Gehen;
        public bool Bereitschaft = false;
    }
    public class dbKG_AZReiseTag
    {
        // CG: Defect 4300, 4947 - Konstruktion um 10. erweitert
        // Dieser Parameter dient dazu die "W" - Stempel zu erkennen und daher die richtige Versorgung sehr wichtig f�r diesen Defect

        public dbKG_AZReiseTag(double NormStd, double ue50, double ue100, string LA, string Auftr, DateTime kommen, DateTime gehen, DateTime AZMKommen, DateTime AZMGehen, dbArbZeit.ArbZeitType stempeltyp)
        {
            NormStunden = NormStd;
            UE50 = ue50;
            UE100 = ue100;
            Lohnart = LA;
            Auftrag = Auftr;
            Kommen = kommen;
            Gehen = gehen;
            AzmKommen = AZMKommen;
            AzmGehen = AZMGehen;
            Stempeltyp = stempeltyp;
        }
        public dbArbZeit.ArbZeitType Stempeltyp = dbArbZeit.ArbZeitType.alle;   // CG - Defect 4300, 4947

        //Arbeitszeit lt. EB
        /// <summary>
        /// Stunden in der Normalarbeitszeit
        /// </summary>
        public double NormStunden = 0; 
        /// <summary>
        /// �berstunden 50%
        /// </summary>
        public double UE50 = 0;
        /// <summary>
        /// �berstunden 100%
        /// </summary>
        public double UE100 = 0;
        /// <summary>
        /// immer "Reisezeit"
        /// </summary>
        public string Lohnart = ""; 
        /// <summary>
        /// KTOBJ aus dem Projekt
        /// </summary>
        public string Auftrag = "";
        /// <summary>
        /// Kommen f�r die produktive Sicht (Einsatzbericht)
        /// </summary>
        public DateTime Kommen; 
        /// <summary>
        /// Gehen f�r die produktive Sicht (Einsatzbericht)
        /// </summary>
        public DateTime Gehen;  
        /// <summary>
        /// Kommen-Stempel f�r AZM == ParamVal.Date0 bei Reisen au�erhalb der Dienstzeit
        /// </summary>
        public DateTime AzmKommen;
        /// <summary>
        /// Gehen-Stempel f�r AZM == ParamVal.Date0 bei Reisen au�erhalb der Dienstzeit
        /// </summary>
        public DateTime AzmGehen; 
    }
    public class dbKG_AZTagSTDAbsenz
    {
        // Beginn Defect 4462: Zus�tzlicher Parameter f�r Konstruktor 'dblPause'
        // Der in der DB eingetragene Pausenwert wird ebenfalls dem Konstruktor
        // �bergeben und bei der Berechnung der Normalstunden abgezogen.
        public dbKG_AZTagSTDAbsenz(DateTime von ,
                                   DateTime bis ,
                                   double   dblPause , // Ende Defect 4462
                                   string   AbsID,
                                   string   stdabstxt)
        {
            TimeSpan ts = new TimeSpan(bis.Ticks - von.Ticks);
            // Beginn Defect 4462: Pausenzeit von Normalstunden subtrahieren
            NormStunden = ts.TotalHours - dblPause;
            Pause = dblPause;
            // Ende Defect 4462: Pausenzeit von Normalstunden subtrahieren
            Gehen = von; //nicht wundern, das ist so!!
            Kommen = bis;
            StdAbsID = AbsID;
            StdAbsTxt = stdabstxt;
        }
        /// <summary>
        /// wird errechnet aus TimeSpan(ARBZEIT.GEHEN-ARBZEIT.kommen) wenn ZeitType in [ReiseInDZ .. ReiseVorherNachher]
        /// </summary>
        public double NormStunden = 0;
        public DateTime Gehen;
        public DateTime Kommen;
        // Beginn Defect 4462: public double value 'Pause'
        public double Pause;
        // Ende Defect 4462: public double value 'Pause'
        public string StdAbsID;
        public string StdAbsTxt;
    }

    public class dbKG_RATag
    {
        public dbKG_RATag()
        {
        }
        public string Auslagenart = "";
        public float Anzahl = 0;
        public float Betrag = 0;
    }
}