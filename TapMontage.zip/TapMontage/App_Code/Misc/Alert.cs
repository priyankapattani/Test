﻿//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : Alert.cs
//
// Description  : Java Alert aus code behind
//
//=============== V1.2.0011 ===================================================
//
// Date         : 23.September 2011
// Author       : Joldic Dzevad
// Defect#      : KMS BAN 500256 TAP-Montage: Erweiterte Zulagenprüfung
//                Neu hinzufügt
//
//=============================================================================
using System.Web;
using System.Text;
using System.Web.UI;
using System.Web.UI.HtmlControls;

namespace TapMontage.Misc
{
    /// <summary>
    /// Zusammenfassungsbeschreibung für Alert
    /// </summary>
    public static class Alert
    {

        /// <summary>
        /// Shows a client-side JavaScript alert in the browser.
        /// </summary>
        /// <param name="message">The message to appear in the alert.</param>
        public static void Show(string[] messages)
        {
            string script = "<script type=\"text/javascript\">alert('";
            foreach (string message in messages)
            {
                // Cleans the message to allow single quotation marks
                string cleanMessage = message.Replace("'", "\\'");
                script += cleanMessage + "\\n";
            }
            script += "');</script>";
            // Gets the executing web page
            Page page = HttpContext.Current.CurrentHandler as Page;

            // Checks if the handler is a Page and that the script isn't allready on the Page
            if (page != null && !page.ClientScript.IsClientScriptBlockRegistered("alert"))
            {
                page.ClientScript.RegisterClientScriptBlock(typeof(Alert), "alert", script);
            }
        }
    }
}