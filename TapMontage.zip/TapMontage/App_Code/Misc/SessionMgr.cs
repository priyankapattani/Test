//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : SessionMgr.cs
//
// Description  : SessionMgr
//
//=============== V1.0.0029 ===================================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace TapMontage.Misc
{
    /// <summary>
    /// Summary description for SessionMgr
    /// </summary>
    public static class SessionMgr
    {
        public static void ClearSession(Page page ,string[] exceptions)
        {
            ArrayList objs = new ArrayList();
            for (int i = 0; i <= exceptions.GetUpperBound(0); i++)
            {
                object o = (object)page.Session[exceptions[i]];
                objs.Add(o);
            }
            page.Session.Clear();
            for (int i = 0; i <= exceptions.GetUpperBound(0); i++)
            {
                page.Session[exceptions[i]] = objs[i];
            }
        }
    }
}