//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : AutoIVZ.cs
//
// Description  : AutoIVZ
//
//=============== V1.0.0029 ===================================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Net;
using System.IO;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;

namespace TapMontage.Misc
{
    public class AutoIVZ
    {
        System.Web.UI.Page page;
        public string Request;
        public string Response;
        public string LastError = "";
        public int Error = 0;

        private AZMIVZDESLib.Crypt crypt = new AZMIVZDESLib.Crypt();
        public AutoIVZ(System.Web.UI.Page Page)
        {
            page = Page;
        }
        public bool SendRequest()
        {
            LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "AutoIVZ::SendRequest:\r\nRequest:\r\n" + Request, MessageIDs.AutoIVZRequestInfo, page);
            try
            {
                string cRequest = Request;
                object oRequest = cRequest;
                Random r = new Random(4711);
                int key1 = r.Next(0, 32000);
                int key2 = r.Next(0, 32000);
                int Word1 = 0;
                int Word2 = 0;
                int Length = crypt.getCodedLength(ref oRequest) / 4;
                string codedRequest = key1.ToString() + "," + key2.ToString() + "," + Length.ToString();
                while (cRequest.Length > 0)
                {
                    string tmp8 = "";
                    if (cRequest.Length >= 8)
                    {
                        tmp8 = cRequest.Substring(0, 8);
                        cRequest = cRequest.Substring(8);
                    }
                    else
                    {
                        tmp8 = cRequest;
                        while (tmp8.Length < 8) tmp8 += " ";
                        cRequest = "";
                    }
                    object otmp8 = tmp8;
                    crypt.code2(ref otmp8, key1, key2, out Word1, out Word2);
                    codedRequest += "," + Word1.ToString() + "," + Word2.ToString();
                }
                string codedResponse = "";
                try
                {
                    WebRequest request = WebRequest.Create(ConfigurationManager.AppSettings["autoivz_url"].ToString() + codedRequest);
                    WebResponse response = request.GetResponse();
                    Stream dataStream = response.GetResponseStream();
                    StreamReader reader = new StreamReader(dataStream);
                    codedResponse = reader.ReadToEnd();
                    reader.Close();
                    response.Close();
                }
                catch (Exception exReq)
                {
                    LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Fehler, "AutoIVZ::SendRequest:Req:\r\nSource:\r\n" + exReq.Source + "\r\nMessage:\r\n" + exReq.Message + "\r\nStackTrace\r\n" + exReq.StackTrace, MessageIDs.AutoIVZCommError, page);
                    throw exReq;
                }
                if (codedResponse.Length > 0)
                {
                    try
                    {
                        key1 = Convert.ToInt32(codedResponse.Substring(0, codedResponse.IndexOf(",")));
                        codedResponse = codedResponse.Substring(codedResponse.IndexOf(",") + 1);
                        key2 = Convert.ToInt32(codedResponse.Substring(0, codedResponse.IndexOf(",")));
                        codedResponse = codedResponse.Substring(codedResponse.IndexOf(",") + 1);
                        Length = Convert.ToInt32(codedResponse.Substring(0, codedResponse.IndexOf(",")));
                        codedResponse = codedResponse.Substring(codedResponse.IndexOf(",") + 1);
                        int Pairs = Convert.ToInt32(codedResponse.Substring(0, codedResponse.IndexOf(",")));
                        //codedResponse = codedResponse.Substring(codedResponse.IndexOf(",") + 1);
                        int testPairs = (codedResponse.Length - codedResponse.Replace(",", "").Length + 1) / 2;
                        if (Pairs != testPairs)
                        {
                            //lies trotzdem weiter
                        }
                        codedResponse += ",";
                        while (codedResponse.Length > 0)
                        {
                            Word1 = Convert.ToInt32(codedResponse.Substring(0, codedResponse.IndexOf(",")));
                            codedResponse = codedResponse.Substring(codedResponse.IndexOf(",") + 1);
                            if (codedResponse.IndexOf(",") > 0)
                            {
                                Word2 = Convert.ToInt32(codedResponse.Substring(0, codedResponse.IndexOf(",")));
                                codedResponse = codedResponse.Substring(codedResponse.IndexOf(",") + 1);
                            }
                            Response += crypt.decode2(Word1, Word2, key1, key2);
                        }
                        LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "AutoIVZ::SendRequest:\r\nResponse:\r\n" + Response, MessageIDs.AutoIVZResponseInfo, page);
                    }
                    catch (Exception exRes)
                    {
                        LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Fehler, "AutoIVZ::SendRequest:Res:\r\nSource:\r\n" + exRes.Source + "\r\nMessage:\r\n" + exRes.Message + "\r\nStackTrace\r\n" + exRes.StackTrace, MessageIDs.AutoIVZCommError, page);
                        throw exRes;
                    }
                }
            }
            catch (Exception exCrypt)
            {
                LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Fehler, "AutoIVZ::SendRequest:Crypt:\r\nSource:\r\n" + exCrypt.Source + "\r\nMessage:\r\n" + exCrypt.Message + "\r\nStackTrace\r\n" + exCrypt.StackTrace, MessageIDs.AutoIVZCommErrorCrypt, page);
                throw exCrypt;
            }
            return true;
        }

        private bool ErrorReturned()
        {
            if ((Response != "") & (LastError.Length == 0) & (Error == 0))
            {
                return false;
            }
            return true;
        }
        //AutoIVZ alter Teil
        public dbKG_AZMTag SendAZMTag(dbKG_AZMTag Tag)
        {
            //Request = "";
            if ((SendRequest()) && (!ErrorReturned()))
            {
                while (Response.Length > 0)
                {
                    if (Response.IndexOf(";") > 0)
                    {

                        string fkz = Response.Substring(0, Response.IndexOf(";"));
                        Response = Response.Substring(Response.IndexOf(";") + 1);
                        string persnr = Response.Substring(0, Response.IndexOf(";"));
                        Response = Response.Substring(Response.IndexOf(";") + 1);
                        string jahr = Response.Substring(0, Response.IndexOf(";"));
                        Response = Response.Substring(Response.IndexOf(";") + 1);
                        string monat = Response.Substring(0, Response.IndexOf(";"));
                        Response = Response.Substring(Response.IndexOf(";") + 1);
                        Tag.AStatus = Response.Substring(0, Response.IndexOf(";"));
                        Response = Response.Substring(Response.IndexOf(";") + 1);
                        if (Response.Length > 0)
                        {
                            if (Tag.AStatus == "F")
                            {
                                Tag.ABemerk = Response.Substring(0, Response.IndexOf(";"));
                                Response = Response.Substring(Response.IndexOf(";") + 1);
                            }
                            else
                            {
                                string anz = Response.Substring(0, Response.IndexOf(";"));
                                Response = Response.Substring(Response.IndexOf(";") + 1);
                                string tag = Response.Substring(0, Response.IndexOf(";"));
                                Response = Response.Substring(Response.IndexOf(";") + 1);
                                string kz = Response.Substring(0, Response.IndexOf(";"));
                                Response = Response.Substring(Response.IndexOf(";") + 1);
                                Tag.ANorm = Convert.ToDouble(Response.Substring(0, Response.IndexOf(";")));
                                Response = Response.Substring(Response.IndexOf(";") + 1);
                                Tag.AUe50 = Convert.ToDouble(Response.Substring(0, Response.IndexOf(";")));
                                Response = Response.Substring(Response.IndexOf(";") + 1);
                                Tag.AUe100 = Convert.ToDouble(Response.Substring(0, Response.IndexOf(";")));
                                Response = Response.Substring(Response.IndexOf(";") + 1);
                            }
                        }

                    }
                }
            }
            else
            {
                Exception ex = new Exception("Fehler in AutoIVZ::SendAZMTag:" + LastError + "::ErrorCode:" + Error.ToString());
                throw ex;
            }
            return Tag;
        }
        //AutoIVZ neuer Teil
        //4.1.3
        public dbKG_AZMTag RequestSalden(dbKG_AZMTag Tag)
        {
            string DatumTag = "";
            if ((SendRequest()) && (!ErrorReturned()))
            {
                DatumTag = Tag.TagesDatum.Year.ToString();
                DatumTag += "-";
                DatumTag += Tag.TagesDatum.Month.ToString();
                DatumTag += "-";
                DatumTag += Tag.TagesDatum.Day.ToString();


                if (Response.IndexOf(";") > 0)
                {
                    // Firmen Kennung
                    string fkz = Response.Substring(0, Response.IndexOf(";"));
                    Response = Response.Substring(Response.IndexOf(";") + 1);
                    // Personal Nummer
                    string persnr = Response.Substring(0, Response.IndexOf(";"));
                    Response = Response.Substring(Response.IndexOf(";") + 1);
                    // Jahr
                    string jahr = Response.Substring(0, Response.IndexOf(";"));
                    Response = Response.Substring(Response.IndexOf(";") + 1);
                    // Monat
                    string monat = Response.Substring(0, Response.IndexOf(";"));
                    Response = Response.Substring(Response.IndexOf(";") + 1);
                    // BefehlsKZ
                    string befehlskz = Response.Substring(0, Response.IndexOf(";"));
                    Tag.AStatus = Response.Substring(0, Response.IndexOf(";"));
                    Response = Response.Substring(Response.IndexOf(";") + 1);
                    if (Tag.AStatus == "F")
                    {
                        Tag.ABemerk = Response.Substring(0, Response.IndexOf(";"));
                        Response = Response.Substring(Response.IndexOf(";") + 1);
                    }
                    else
                    {
                        if (Response.IndexOf(",") > 0)
                        {
                            // Status Vormonat
                            string statvormonat = Response.Substring(0, Response.IndexOf(","));
                            Response = Response.Substring(Response.IndexOf(",") + 1);
                        }

                        // Status aktuelle Monat
                        string stataktmonat = Response.Substring(0, Response.IndexOf(";"));
                        Response = Response.Substring(Response.IndexOf(";") + 1);
                        // anzahl �bertragenen tage
                        string anztage = Response.Substring(0, Response.IndexOf(";"));
                        Response = Response.Substring(Response.IndexOf(";") + 1);

                    }
                    while (Response.Length > 0)
                    {

                        // Tagesdatum
                        string tagesdatum = Response.Substring(0, Response.IndexOf(";"));
                        Response = Response.Substring(Response.IndexOf(";") + 1);
                        // KZ f�r tag-status
                        string kz = Response.Substring(0, Response.IndexOf(";"));
                        Response = Response.Substring(Response.IndexOf(";") + 1);
                        // BS_TagStatus aus der AZM-Tabelle BS_berechneteSalden 
                        string bstagstatus = Response.Substring(0, Response.IndexOf(";"));
                        Response = Response.Substring(Response.IndexOf(";") + 1);
                        // Freigabestatus des Tages in AZM 
                        string freigabestatus = Response.Substring(0, Response.IndexOf(";"));
                        Response = Response.Substring(Response.IndexOf(";") + 1);
                        // Soll 
                        if (Convert.ToDateTime(tagesdatum).Ticks == Tag.TagesDatum.Ticks)
                            Tag.ASoll = Convert.ToDouble(Response.Substring(0, Response.IndexOf(";")));
                        Response = Response.Substring(Response.IndexOf(";") + 1);
                        // Ist 
                        if (Convert.ToDateTime(tagesdatum).Ticks == Tag.TagesDatum.Ticks)
                            Tag.AIst = Convert.ToDouble(Response.Substring(0, Response.IndexOf(";")));
                        Response = Response.Substring(Response.IndexOf(";") + 1);
                        // mehrarbeit 50 
                        string mehrarbeit50 = Response.Substring(0, Response.IndexOf(";"));
                        Response = Response.Substring(Response.IndexOf(";") + 1);
                        // mehrarbeit 100 
                        string mehrarbeit100 = Response.Substring(0, Response.IndexOf(";"));
                        Response = Response.Substring(Response.IndexOf(";") + 1);
                        // Tagessaldo 
                        if (Convert.ToDateTime(tagesdatum).Ticks == Tag.TagesDatum.Ticks)
                            Tag.ATSaldo = Convert.ToDouble(Response.Substring(0, Response.IndexOf(";")));
                        Response = Response.Substring(Response.IndexOf(";") + 1);
                        // Geasamtsaldo 
                        if (Convert.ToDateTime(tagesdatum).Ticks == Tag.TagesDatum.Ticks)
                            Tag.AGSaldo = Convert.ToDouble(Response.Substring(0, Response.IndexOf(";")));
                        Response = Response.Substring(Response.IndexOf(";") + 1);

                    }
                }
            }
            else
            {
                Exception ex = new Exception("Fehler in AutoIVZ::SendAZMTag:" + LastError + "::ErrorCode:" + Error.ToString());
                throw ex;
            }
            return Tag;
        }

        //public dbKG_AZM RequestSalden(dbKG_AZM azm)
        //{
        //    return azm;
        //}
        //4.1.4
        public void TageFreigeben(dbKG_AZM azm)
        {
        }
        public void TageGenehmigen(dbKG_AZM azm)
        {
        }
        public dbKG_AZM GetDispo(dbKG_AZM azm)
        {
            return azm;
        }
        public void DispoFreigeben(dbKG_AZM azm)
        {
        }
    }
}