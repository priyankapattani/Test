// ------------------------------------------------------------------------
//
// Projekt      : TAP_Montage
//
// File         : LogWriter.cs
//
// Description  : Logging Funktionen
//
// -------------- V1.0.0020 -----------------------------------------------
//
// Date         : 23. J�nner 2007
// Author       : Patrman Wolfgang
// Defect#      : 4268
//                
// Zus�tzliche Funktion:
// WriteLogEntry(ErrorLevel level, string Beschreibung, string path)
// ... f�r logging um einfache strings in ein Textfile zu schreiben
//
// ------------------------------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Net;
using System.IO;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Diagnostics;
using TapMontage.dbObjects;

namespace TapMontage.Misc
{
    /// <summary>
    /// 
    /// </summary>
    ///Beispiel:
    ///LogWriter.WriteLogEntry(TMLogWriter.ErrorLevel.Information, "Info - Info\r\nInfo -Info!", this.Page);    
    public static class LogWriter
    {
        public static FileStream logfile = null;
        public static StreamWriter logwriter = null;

        public enum ErrorLevel { Fehler = 2, Warnung = 1, Information = 0};

        public static void WriteLogEntry(ErrorLevel level, string Beschreibung, int EventID, System.Web.UI.Page page)
        {
            if ((int)level < Convert.ToInt32(ConfigurationManager.AppSettings["LogLevel"])) return;
            string UserName = page.User.Identity.Name;
            string Path = page.MapPath("~/Log/");
            bool Write2Elog = false; //set to true to try writing to eventlog, ASPNET must have rights to access EventLogs
            if (Write2Elog)
            {
                try
                {
                    if (!EventLog.SourceExists("TAPMontage"))
                    {
                        //Beim ersten Aufruf wird kreiert, ein Zugriff ist erst beim zweiten mal m�glich??
                        EventLog.CreateEventSource("TAPMontage", "TAPMontage");
                    }
                }
                catch
                {
                    Write2Elog = false;
                }

                EventLog ELog = new EventLog("TAPMontage");
                ELog.Source = "TAPMontage";
                EventLogEntryType type = EventLogEntryType.Error;
                if (level == ErrorLevel.Warnung) type = EventLogEntryType.Warning;
                if (level == ErrorLevel.Information) type = EventLogEntryType.Information;
                ELog.WriteEntry(Beschreibung, type, EventID);
                return;
            }
            if (!Write2Elog)
            {
                string fname = Path+UserName+"-"+DateTime.Now.ToString("yyyyMMdd")+".log";
                FileStream fStream = null;
                if (!File.Exists(fname))
                    fStream = File.Create(fname);
                else
                    fStream = File.Open(fname, FileMode.Append);
                Beschreibung += "\r\n\r\n";
                string strTemp = EventID.ToString() + ": " + DateTime.Now.ToString("HH:mm:ss") +"\r\n";
                byte[] header = new byte[strTemp.Length];
                header = Encoding.UTF8.GetBytes(strTemp);
                byte [] array = new byte[Beschreibung.Length];
                array = Encoding.UTF8.GetBytes(Beschreibung);
                fStream.Write(header, 0, header.Length);
                fStream.Write(array, 0, array.Length);
                fStream.Close();
            }
        }

    // Defect 4268 Beginn
    // Textstrings in ein Textfile schreiben
    public static void WriteLogEntry(ErrorLevel level, // Errorlevel
                                     string Beschreibung, // Textstring
                                     string path // Textfile Pfad inkl. Name der Textdatei
                                    )
    {
      string date;
      string logText;

      if ((int)level < Convert.ToInt32(ConfigurationManager.AppSettings["LogLevel"])) return;

      if (path == null)
      {
        // Default Path
        path = "c:\\temp\\Debug";
      }

      // Name der Textdatei besteht aus Name + Zeit
      string filename = path +
                        DateTime.Now.Hour.ToString() + "-" +
                        DateTime.Now.Minute.ToString() + "-" +
                        DateTime.Now.Second.ToString() + ".txt";
      if (logfile == null)
      {
        logfile = new FileStream(filename,
                                 FileMode.OpenOrCreate,
                                 FileAccess.Write,
                                 FileShare.ReadWrite);
      }

      if (logwriter == null)
      {
        logwriter = new StreamWriter(logfile);
      }

      date = DateTime.Now.Hour.ToString() + ":" +
             DateTime.Now.Minute.ToString() + ":" +
             DateTime.Now.Second.ToString() + "-" +
             DateTime.Now.Millisecond.ToString();

      logText = date;
      logText += "\t";
      logText += Beschreibung;

      logwriter.WriteLine(logText);
      logwriter.Flush();
    }
    // Defect 4268 Ende
  }
}
