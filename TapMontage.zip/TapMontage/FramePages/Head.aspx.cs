﻿// ============================================================================
//
// Projekt      : TAP_Montage
//
// File         : Head.aspx.cs
//
// Description  : Header
//
//--------------- V1.0.0038 ---------------------------------------------------
//
// Date         : 20.Februar 2008
// Author       : Sabol Frantisek
// Defect#      : 4252
//                Vertretung anzeigen
//
//--------------- V1.0.0034 ---------------------------------------------------
//
// Date         : 9.Oktober 2007
// Author       : Marcincin Frantisek
// Defect#      : 
//                Dokumentation visible nach einlogen
//
//=============== V1.0.0033 ===================================================
//
// Date         : 30.August 2007
// Author       : Adam Kiefer
// Defect#      : 5416
//                Anzeige Kopfdaten
//
//=============== V1.0.0033 ===================================================
//
// Date         : 28.August 2007
// Author       : Adam Kiefer
//                Global Assembly Informations
//
//=============== V1.0.0028 ===================================================
//
// Date         : 24.Mai 2007
// Author       : Adam Kiefer
// Defect#      : 4121
//                Neues Login-Konzept
//
// ============================================================================

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Caching;
using System.Reflection;
using TapMontage.dbObjects;  // #4252

public partial class Head : System.Web.UI.Page
{
    dbBearbeiter Bearb; // #4252

    protected void Page_Load(object sender, EventArgs e)
    {
        TapWebDAC x = new TapWebDAC();
        Page.Cache.Add("WEBDAC", x, null, System.Web.Caching.Cache.NoAbsoluteExpiration, TimeSpan.FromHours(1), CacheItemPriority.High, null);
        if (Request.Cookies["Perskey_Login"] != null)
        {
            //DDL_SelMa.Visible = true;
            //DDL_SelMa.SetInitsSQL("select b.Nachname + ' ' + b.Vorname + ' (' +right(b.PersNr,5) + ')', b.Perskey from bearbeit b where mandant=(select mandant from bearbeit where perskey=" + Request.Cookies["Perskey_Data"].Value + ") order by b.nachname, b.vorname", Request.Cookies["Perskey_MA"].Value);
            lblLoggedIn.Visible = true;
            lblLoggedIn.Text = "Eingeloggt: " + x.GetSingleSQLResult("select vorname + ' ' + nachname from bearbeit where perskey=" + Request.Cookies["Perskey_Login"].Value);
            if (Request.Cookies["Perskey_Login"].Value!=Request.Cookies["Perskey_Data"].Value)
                lblLoggedIn.Text += ", Vertretung für : " + x.GetSingleSQLResult("select vorname + ' ' + nachname from bearbeit where perskey=" + Request.Cookies["Perskey_Data"].Value);
        }

        /* Sabol: Defect #4252
         * added new label for display "Vertretung"
         */
        if (Session["Bearbeiter"] != null && Session["loginaccount"].ToString() != "gast")
        {
            Bearb = (dbBearbeiter)Session["Bearbeiter"];
            lblVertr.Text = "Vertretung für : " + Bearb.Params.NACHNAME.Value.ToString() + " " + Bearb.Params.VORNAME.Value.ToString();
            lblVertr.Text += " (" + Bearb.Params.BELOGIN.Value.ToString() + ") | " + Session["VertritRole"] + " |";

            // if login account equals to bearbeiter account => it is the same person => no "vertretung" => the label won't be displayed
            if (Session["loginAccount"].ToString().Equals(Bearb.Params.BELOGIN.Value.ToString(), StringComparison.OrdinalIgnoreCase))
                lblVertr.Visible = false;
            else
                lblVertr.Visible = true;
        }
        // end Defect #4252

        // Beginn #4121 - Neues Login-Konzept

        if (Session["loginName"] == null)
            Session.Add("loginName", "Gast");
        if (Session["loginAccount"] == null)
            Session.Add("loginAccount", "gast");
        if (Session["loginRole"] == null)
            Session.Add("loginRole", "Gast");

        if (Session["loginName"].ToString() == "Gast")
        {
            lblLoggedIn.Text = "Sie sind nicht angemeldet! | <a href=\"../Allgemein/Login.aspx\" target=\"main\"><font color=\"white\">Login</font></a>";
            imgUserIcon.Visible = false;
        }

        if (Session["loginName"].ToString() == "Fehler")
        {
            lblLoggedIn.Text = "Sie sind angemeldet! | <a href=\"../Allgemein/Login.aspx\" target=\"main\"><font color=\"white\">Logout</font></a>";
            imgUserIcon.Visible = true;
        }

        if ((Session["loginName"].ToString() != "Fehler") && (Session["loginName"].ToString() != "Gast"))
        {
            lblLoggedIn.Text = String.Format(" {0} ({1}) | {2} | <a href=\"../Allgemein/Login.aspx\" target=\"main\"><font color=\"white\">Logout</font></a>", Session["loginName"].ToString(), Session["loginAccount"].ToString(), Session["loginRole"].ToString());
            imgUserIcon.Visible = true;
        }

        // Ende #4121

        // Dokumentation visible nach einlogen
        if (Session["loginName"].ToString() == "Gast")
        {
            this.HyperLink1.Enabled = false;
        }
        else
        {
            this.HyperLink1.Enabled = true;
        }
   
        // Beginn #Global Assembly Informations
        try
        {
            Assembly assembly = Assembly.Load("App_Code");
            System.Version appVersion = assembly.GetName().Version;
            #region Buildnummer einstellen
            string appBuild = "";
            if (appVersion.Build.ToString().Length == 1)
                appBuild = "000";
            if (appVersion.Build.ToString().Length == 2)
                appBuild = "00";
            if (appVersion.Build.ToString().Length == 3)
                appBuild = "0";
            appBuild += appVersion.Build.ToString();
            #endregion
            string version = String.Format("{0}.{1}.{2}", appVersion.Major.ToString(), appVersion.Minor.ToString(), appBuild);
            lbVersion.Text = version;
        }
        catch
        {
            lbVersion.Text = "1.0.0033";
        }
        // Ende #Global Assembly Informations

        // Beginn #5416 - Anzeige Kopfdaten
        try
        {
            if (Session["headData"] != null)
                lbHeadData.Text = Session["headData"].ToString();

            Session.Remove("headData");
        }
        catch
        {
            lbHeadData.Text = "";
        }         
        // Ende #5416
    }
}