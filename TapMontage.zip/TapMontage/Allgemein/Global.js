//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : Global.js
//
// Description  : Global.js
//
//=============== V1.0.0029 ===================================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

﻿// JScript File
function doOk()
{
            alert("Ok1111!");
    //var strtext = 'false';
    var tbtxt = document.form1.ctl07.value;
    var isnumber = false;
    var errtxt = 'Bitte geben Sie eine gültige Zeit ein.';
    if (tbtxt.length <= 5)
    {
            alert("Ok!");
        if (tbtxt.length == 1)
        {
            //alert("Ok1!");
            if (tbtxt !="")
            {
                //alert("Ok2!");
                //isnumber = IsNumber(helpobj.value);
                isnumber = IsNumber(tbtxt);
            
                if (isnumber)
                //if (IsNumber(helpobj.value))
                {
                //alert("Ok3!");
                  document.form1.ctl07.value = '0'+tbtxt+':00';
                }
                else
                {
                //alert("Ok4!");
                    document.form1.laberr.value = errtxt;
                }
            }
        }
        else if (tbtxt.length == 2)
        {
            alert("Ok1!");
            var helptxt1;
            var helptxt2;
            for (var i = 0; i < tbtxt.length && isnumber; i++)
            {
              helptxt1 = tbtxt[i];
              if (helptxt1 !="")
              {
            alert("Ok2!");
                isnumber = IsNumber(helptxt1);
              }
              if (isnumber)
              {
            alert("Ok3!");
                helptxt2+= helptxt1;
              }
            }
            if (isnumber)
            {
                if ((helptxt2.length ==2))
                {
                    alert("Ok4!");
                  if (helptxt2.charAt(0) == "0" || helptxt2.charAt(0) == "1" || helptxt2.charAt(0) == "2")
                  {
                    alert("Ok5!");
                    document.form1.ctl07.value = helptxt2+':00';
                  }
                  else if (helptxt2.charAt(0) == "3" || helptxt2.charAt(0) == "4" || helptxt2.charAt(0) == "5")
                  {
                    
                    alert("Ok6!");
                    document.form1.ctl07.value = '00:'+helptxt2;
                  }
                  else
                  {
                    alert("Ok7!");
                    document.form1.laberr.value = errtxt;
                  }
                }
            }
            else
            {
            alert("Ok8!");
                document.form1.laberr.value = errtxt;
            }
        
        }
        else
        {
        
        }
        //alert("Ok!");
        //document.form1.laberr.value = errtxt;
        //return confirm('Ready to submit.');
        //return strtext;
        //document.form1.submit();
        //document.form1.BtnBack.visible = false;
        //document.form1.BtnAZSave.OnClick = 'BtnAZSave_Click';
        //document.form1.BtnAZSave.submit();
    }
    else
    {
        document.form1.laberr.value = errtxt;
    }
}

function IsNumber(t)
{
  var z	= '0123456789,';
  var comma = false;

  for (var i = 0; i < t.length;	i++)
  {
    if (t.charAt(i) == ",")
    {
      if (comma)
      {
	return false;
      }
      else
      {
	comma =	true;
      }
    }

    if (z.indexOf(t.charAt(i)) == -1)
      return false;
  }
  return true;
}

