﻿//-----------------------------------------------------------------------------
//
// Projekt      : TAP_Montage
//
// File         : Vertretung.aspx.cs
//
// Description  : Funktionen für Vertreter
//
//--------------- V1.0.0038 ---------------------------------------------------
//
// Date         : 20.Februar 2008
// Author       : Frantisek Sabol
// Defect#      : 4252
//                Vetretung zuruecksetzen
//
//--------------- V1.0.0034 ---------------------------------------------------
//
// Date         : 30.August 2007
// Author       : Adam Kiefer
// Defect#      : 5416
//                Anzeige Kopfdaten
//
//--------------- V1.0.0017 ---------------------------------------------------
//
// Date         : 12.Dezember 2006
// Author       : GN
// Defect#      : 3889
//                Korr. Sessionvariable
//
//--------------- V1.0.0016 ---------------------------------------------------
//
// Date         : 06.Dezember 2006
// Author       : GN
// Defect#      : 3889
//                Sessionvariable Bearbeiter wird jetzt auf den
//                zu Vertretenden gesetzt.
//
//-----------------------------------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using TapMontage.Misc;

public partial class Vertretung : System.Web.UI.Page
{
    dbBearbeiter Bearbeiter;
    string Argument = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        // Beginn #5416 - Anzeige Kopfdaten
        /* Kopfdaten einstellen */
        try
        {
            if (Session["headData"] == null)
                Session.Add("headData", "");

            Session["headData"] = "<span style=\"font-size: 20px;\">Vertretung wechseln</span>";
        }
        catch
        {/* Nicht behandelt! */}
        // Ende #5416

        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        if (Bearbeiter == null) Response.Redirect("~/Allgemein/Login.aspx");

        
        if (Bearbeiter.Vertritt.Count > 0)
            phVertreter.Controls.Add(VertreterListe());
        else
            lblInfo.Text = "Sie sind nicht als Vertretung definiert";

        // Sabol
        // defect #4252
        if (Session["Logged"] != null)
        {
            lblInfo.Text = " Sie vertreten nun " + ((dbBearbeiter)Session["Bearbeiter"]).Params.NACHNAME.Value.ToString() + " " + ((dbBearbeiter)Session["Bearbeiter"]).Params.VORNAME.Value.ToString() + " (" + ((dbBearbeiter)Session["Bearbeiter"]).Params.BELOGIN.Value.ToString() + ")";

            LinkButton lnkbtn = NewTaskButton("Vertretung zurücksetzen", "Reset", Argument, "Vertretung zurückzusetzen", TaskButton_Click);
            phVertreter.Controls.Add(lnkbtn);
        }
        // ende #4252
    }

    private Table VertreterListe()
    {
        xxID = 0;
        Table tab = new Table();
        TableRow rh = new TableRow();
        string xss = "TabHeader";
        rh = AddNewCell(rh, "Nachname", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Vorname", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Personalnummer", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "", xss, HorizontalAlign.NotSet);

        // Sabol removed the last column from the table head
        // defect #4252
        // rh = AddNewCell(rh, "", xss, HorizontalAlign.NotSet); 
        //rh.Cells[rh.Cells.Count - 1].ColumnSpan = 2;
        tab.Rows.Add(rh);
        LinkButton lnkbtn;
        TableRow tr;
        foreach (dbBearbeiter b in Bearbeiter.Vertritt)
        {
            Argument = b.Params.PERSKEY.Value.ToString();

            tr = new TableRow();
            TableCell d1 = new TableCell();
            d1.Text = b.Params.NACHNAME.Value.ToString();
            d1.HorizontalAlign = HorizontalAlign.Center;
            d1.CssClass = "TabNewDay";
            tr.Cells.Add(d1);

            TableCell d2 = new TableCell();
            d2.Text = b.Params.VORNAME.Value.ToString();
            d2.HorizontalAlign = HorizontalAlign.Center;
            d2.CssClass = "TabNewDay";
            tr.Cells.Add(d2);

            TableCell d3 = new TableCell();
            d3.Text = b.Params.PERSNR.Value.ToString().Substring(2);
            d3.HorizontalAlign = HorizontalAlign.Center;
            d3.CssClass = "TabNewDay";
            tr.Cells.Add(d3);

            TableCell d4 = new TableCell();
            lnkbtn = NewTaskButton("Vertretung übernehmen", "Save", Argument, "Vertretung speichern", TaskButton_Click);
            d4.CssClass = "TabNewDay";
            d4.HorizontalAlign = HorizontalAlign.Center;
            d4.Controls.Add(lnkbtn);
            tr.Cells.Add(d4);

            // Sabol: Removed last column from the Vertretung table
            // Defect #4252
            /*
            TableCell d5 = new TableCell();
            lnkbtn = NewTaskButton("Vertretung zurücksetzen", "Reset", Argument, "Vertretung zurückzusetzen", TaskButton_Click);
            d5.CssClass = "TabNewDay";
            d5.HorizontalAlign = HorizontalAlign.Center;
            d5.Controls.Add(lnkbtn);
            tr.Cells.Add(d5);  
            */
            // end #4252

            tab.Rows.Add(tr);
        }
        return tab;
    }

    TableRow AddNewCell(TableRow r, string LabelText, string css, HorizontalAlign align)
    {
        TableCell c = new TableCell();
        Label l = new Label();
        l.Text = LabelText;
        l.Font.Bold = true;
        c.Controls.Add(l);
        c.CssClass = css;
        c.HorizontalAlign = align;
        r.Cells.Add(c);
        return r;
    }

    private LinkButton NewTaskButton(string Text, string Command, string Argument, string ToolTip, CommandEventHandler TaskButtonClick_EventHandler)
    {
        LinkButton btn = new LinkButton();
        btn.ID = nid();
        btn.SkinID = "";
        btn.Width = Unit.Percentage(100);
        btn.Text = Text;
        btn.CommandName = Command;
        btn.CommandArgument = Argument;
        btn.ToolTip = ToolTip;
        btn.Command += new CommandEventHandler(TaskButtonClick_EventHandler);
        //cList.Add(btn);
        return btn;
    }

    public int xxID = 0;
    public string nid()
    {
        xxID++;
        return "LnkBTN->" + xxID.ToString();
    }
    void TaskButton_Click(object sender, CommandEventArgs e)
    {
        string cmd = (string)e.CommandName;
        string arg = (string)e.CommandArgument;
        dbBearbeiter Bearb;
        switch (cmd)
        {
            // Defect 3889
            // GN Sessionvariable Bearbeiter wird jetzt auf den zu Vertretenden gesetzt.

            /* #4252    in case "SAVE": the initial object "Bearbeiter" is stored into Session variable "Logged" 
             *          for the next use by reseting from "Vertretung"    
             *          in case "RESET": read session variable "Logged" and reset the initial options for logged person,
             *          session variable "Logged" is then destroyed
             */
            case "Save":
                // #4252
                Bearb = new dbBearbeiter(Convert.ToInt32(arg));
                //Bearbeiter.BearbInRole = Bearb;

                if (Session["Logged"] == null)
                    Session["Logged"] = Session["Bearbeiter"];

                Session["Bearbeiter"] = Bearb;

                lblInfo.Text = "Sie vertreten nun " + Bearb.Params.NACHNAME.Value.ToString() + " " + Bearb.Params.VORNAME.Value.ToString() + " (" + Bearb.Params.BELOGIN.Value.ToString() + ")";

                SISSITableAdapters.KAUFMANNTableAdapter taKaufmann = new SISSITableAdapters.KAUFMANNTableAdapter();
                SISSI.KAUFMANNDataTable dtKaufmann = taKaufmann.GetDataByBELOGIN(Bearb.Params.BELOGIN.Value.ToString());
                SISSI.KAUFMANNRow rowKaufmann = (SISSI.KAUFMANNRow)dtKaufmann.Rows[0];

                SISSITableAdapters.GENEHMIGERTableAdapter taGenehmiger = new SISSITableAdapters.GENEHMIGERTableAdapter();
                SISSI.GENEHMIGERDataTable dtGenehmiger = taGenehmiger.GetDataByBELOGIN(Bearb.Params.BELOGIN.Value.ToString());

                SISSITableAdapters.ERFASSERTableAdapter taErfasser = new SISSITableAdapters.ERFASSERTableAdapter();
                SISSI.ERFASSERDataTable dtErfasser = taErfasser.GetDataByBELOGIN(Bearb.Params.BELOGIN.Value.ToString());

                Session["VertritRole"] = "";
                bool mehrAlsEineRolle = false;

                try
                {
                    if (rowKaufmann.TECHGRP == "K")
                    {
                        Session["VertritRole"] += "Kaufmann";         // (Prio 1 Rolle)
                        mehrAlsEineRolle = true;
                    }
                }
                catch { Session["VertritRole"] = ""; }


                try
                {
                    SISSI.GENEHMIGERRow rowGenehmiger = (SISSI.GENEHMIGERRow)dtGenehmiger.Rows[0];
                    if (rowGenehmiger.MITARB_COUNT > 0)
                    {
                        if (mehrAlsEineRolle)
                            Session["VertritRole"] += ", ";
                        Session["VertritRole"] += "Genehmiger";       // (Prio 2 Rolle) 
                        mehrAlsEineRolle = true;
                    }
                }
                catch { Session["VertritRole"] += ""; }

                try
                {
                    SISSI.ERFASSERRow rowErfasser = (SISSI.ERFASSERRow)dtErfasser.Rows[0];
                    if ((dtErfasser.Rows.Count > 0) && (rowErfasser.PROJECT_COUNT > 0))
                    {
                        if (mehrAlsEineRolle)
                            Session["VertritRole"] += ", ";
                        Session["VertritRole"] += "Erfasser";         // (Prio 3 Rolle) 
                    }
                }
                catch { Session["VertritRole"] += ""; }

                // page refresh
                Response.Redirect("~/Allgemein/Vertretung.aspx");
                // end #4252
                break;
            case "Reset":
                // #4252
                // Bearbeiter.BearbInRole = Bearbeiter;   /* Defect #4252 | Sabol: removed line */
                Bearb = (dbBearbeiter)Session["Bearbeiter"];
                lblInfo.Text = "Vertretung von " + Bearb.Params.NACHNAME.Value.ToString() + " " + Bearb.Params.VORNAME.Value.ToString() + " (" + Bearb.Params.PERSNR.Value.ToString() + ")" + " wurde zurückgesetzt!";
                Session["Bearbeiter"] = Session["Logged"];
                Session.Remove("Logged");
                // page refresh
                Response.Redirect("~/Allgemein/Vertretung.aspx");
                // end #4252
                break;
            default:
                Exception ex = new Exception("Command not recognised: " + cmd);
                throw ex;

        }
    }


}

