﻿//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : Projekt_Detail.ascx.cs
//
// Description  : Projekt anlegen
//
//=============== V1.0.0038 ===============================================
//
// Date         : 28.Februar 2008
// Author       : Joldic Dzevad
// Defect#      : 5672
//                Projekt AZ Modell korrekt anzeigen
//
//=============== V1.0.0037 ===============================================
//
// Date         : 29.Jaenner 2008
// Author       : Georg Nebehay
// Defect#      : 5771
//                Beim Drücken des Buttons "In SAP überprüfen" wird zuerst die AUftragsnummer aus dem Cache geleert.
//
// Date         : 15.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' für lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 14.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' für DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//--------------- V1.0.0034 ---------------------------------------------------
//
// Date         : 05.September 2007
// Author       : Adam Kiefer
// Defect#      : 4780
//                Abgrenzen von Aufträgen
//
//--------------- V1.0.0028 ---------------------------------------------------------------------
//
// Date         : 05. Mai 2007
// Author       : Adam Kiefer
// Defect#      : 4686
//                Beim Anlegen eines Projektes sieht man nicht das Enddatum der Baustelle
//
//-----------------------------------------------------------------------------------------------

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using TapMontage.Misc;

public partial class Projekt_Projekt_Detail : System.Web.UI.UserControl
{
    dbProjekt Projekt;
    dbBearbeiter Bearbeiter;

    public delegate void SaveCallbackDelegate();
    public SaveCallbackDelegate SaveClicked;

    public delegate void CancelCallbackDelegate();
    public CancelCallbackDelegate CancelClicked;

    private string[] Tg = new string[] { "SO", "MO", "DI", "MI", "DO", "FR", "SA" };

    ArrayList AZMTage;

    protected void Page_Load(object sender, EventArgs e)
    {
        // Beginn #4686 - Beim anlegen eines projektes sieht man nicht das enddatum der Baustelle
        Baustelle.SelIndexChanged = DDLBaustelleChanged; 
        // Ende #4686

        Projekt = (dbProjekt)Session["Projekt"];
        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        BtnDefineAZModelB.Visible = !lInfoMode;
        BtnCancel.Visible = ((int)Projekt.Params.PROJID.Value > 0);
        KTOBJ.TextBoxChangedDelegee = KTOBJChanged;
        KTOBJ.CustValidatorDelegee = KTOBJValid;        
        FilterBau.TextBoxChangedDelegee = FilterBauChanged;
        DDLAusZul.SelIndexChanged = DDLAusZulSelectChange;
        BtnAZDelete.Visible = (Projekt.ProjektAusZulagen.Count > 0);
        AZFilter.TextBoxChangedDelegee = AZFilterChanged;
        MLFilter.TextBoxChangedDelegee = MLFilterChanged;
        AusZulListe();
        //AZModell();
        InfoMode = lInfoMode;
        //KontierCheck();
        BtnSave.Visible = Bearbeiter.BearbInRole.IstKaufmann;
        LabelSuccess.Visible = false;

        PHAZM.Controls.Clear();

        //int baustId =
        //if (ProjektID != 0)
        //{
        // Defect #5672 - Abfrage ob Projekt ID != 0 ist nicht mehr notwendig
        // weil SelectProjAZM und BuildAZMList sind mit try/catch erweitert
        // ansonst sichet man nicht AZ Modell wenn man ein mneues Projekt anlegt
        AZMTage = SelectProjAZM(ProjektID);
        PHAZM.Controls.Add(BuildAZMList());
        //}

       /*
        Literal l = new Literal();

        l.Text = "<a Onclick=\"var l=(screen.width-180)/2; var t=(screen.height-190)/2;alert(t);alert(l);window.open('../DatePicker.aspx?backf=form1.Projekt_Detail1$VALID$txtTextBox', 'calendarPopup', 'width=180,height=190,left=' + l + ',top=' + t + ',resizable=no');\">Calendar</a>";

        PlaceHolder1.Controls.Add(l);*/

        if ((Request.QueryString["Message"] != null) & (!Page.IsPostBack)) LabelSuccess.Visible = true;

        // Beginn #4780 - Abgrenzen von Aufträgen
        if ((Request.Url.PathAndQuery.Contains("Projekt.aspx"))) /* Existierendes Projekt */
        {
            if (!Projekt.KontierbarInSAP()) /* Nicht kontierbares Projekt */
            {
                KTOBJ.Enabled = false;
                Name.Enabled =false;
                Beschreibung.Enabled = false;
                MLFilter.Enabled = false;
                Montageleiter.Enabled = false;
                FilterBau.Enabled = false;
                Baustelle.Enabled = false;
                SEGPunkte.Enabled = false;
                LAFaktor.Enabled = false;
            }
            else
            {
                KTOBJ.Enabled = true;
                Name.Enabled = true;
                Beschreibung.Enabled = true;
                MLFilter.Enabled = true;
                Montageleiter.Enabled = true;
                FilterBau.Enabled = true;
                Baustelle.Enabled = true;
                SEGPunkte.Enabled = true;
                LAFaktor.Enabled = true;
            }
        } 
        // Ende #4780
    }

    // Beginn #4686 - Beim anlegen eines projektes sieht man nicht das enddatum der Baustelle
    public void DDLBaustelleChanged(object sender, EventArgs e)
    {        
        try
        {
            int idBau = Convert.ToInt32(Baustelle.DDL.SelectedValue);
            SISSITableAdapters.BAUSTELLE_TODATETableAdapter taBaustelleToDate = new SISSITableAdapters.BAUSTELLE_TODATETableAdapter();
            SISSI.BAUSTELLE_TODATEDataTable dtBaustelleToDate = taBaustelleToDate.GetBauDate(idBau);
            SISSI.BAUSTELLE_TODATERow rowBaustelleToDate = (SISSI.BAUSTELLE_TODATERow)dtBaustelleToDate.Rows[0];            

            if (Baustelle.DDL.SelectedValue == "-1")
            {
                lbBauValid.Text = "";
            }
            else
            {
                lbBauValid.Text = String.Format(" Gültig von {0} bis {1}", rowBaustelleToDate.DATVON.ToString("dd.MM.yyyy"), rowBaustelleToDate.DATBIS.ToString("dd.MM.yyyy"));
                // Defect #5672
                // #5672 Gültigkeit von Projekt mit dem Gültigkeit von Baustelle ausfühlen, falls
                // diese noch nicht versorgt ist.
                if (VALID.TB.Text == "")
                {
                    VALID.TB.Text = rowBaustelleToDate.DATBIS.ToString("dd.MM.yyyy").ToString();
                }
            }
        }
        catch
        {
            lbBauValid.Text = "";
        }                 
    }
    // Ende #4686

    public string FilterBauChanged(object sender, EventArgs e)
    {
        Baustelle.Filter = (sender as TextBox).Text;
        Baustelle.DDL.Focus();
        return (sender as TextBox).Text;
    }

    private bool lInfoMode = false;
    public bool InfoMode
    {
        get { return lInfoMode; }
        set
        {
            lInfoMode = value;
            BtnKOCheck.Visible = !lInfoMode;
            BtnDefineAZModelB.Visible = !lInfoMode;
            panAusZul.Visible = !lInfoMode;
            panAusZulListe.Visible = !lInfoMode;
            BtnSave.Visible = !lInfoMode;
            BtnCancel.Visible = !lInfoMode;
            MLFilter.Visible = !lInfoMode;
        }
    }

    private bool lSaveMode = false;
    public bool SaveMode
    {
        get { return lSaveMode; }
        set
        {
            lSaveMode = value;
            if (lSaveMode)
            {
                MLFilter.TextBoxText = "";
                FilterBau.TextBoxText = "";
                Montageleiter.DDLSelectedValue = Projekt.Params.MLPERSKEY.Value.ToString();
                Baustelle.DDLSelectedValue = Projekt.Params.BAUID.Value.ToString();
            }
        }
    }
    public bool Enabled
    {
        get { return Panel1.Enabled; }
        set
        {
            Panel1.Enabled = value;
        }
    }

    public int ProjektID
    {
        get
        {
            return (int)Projekt.Params.PROJID.Value;
        }
        set
        {
            //Please Fill Projekt outside!
            Page_Load(null, null);
            MapData();
        }
    }

    private void MapData()
    {
        foreach (Control c in Panel1.Controls)
        {
            if ((c as TapWebTextBox) != null)
            {
                TapWebTextBox tb = (TapWebTextBox)c;
                foreach (SqlParameter s in Projekt.Params.List)
                    if (tb.DataField == s.ParameterName)
                        tb.TextBoxText = ParamVal.GetParameter(s);
            }
            if ((c as TapWebDropDownList) != null)
            {
                TapWebDropDownList dl = (TapWebDropDownList)c;
                foreach (SqlParameter s in Projekt.Params.List)
                    if (dl.DDLDataField == s.ParameterName)
                        dl.DDLSelectedValue = ParamVal.GetParameter(s);
            }
        }
    }

    private void SaveData()
    {
        foreach (Control c in Panel1.Controls)
        {
            if ((c as TapWebTextBox) != null)
            {
                TapWebTextBox tb = (TapWebTextBox)c;
                foreach (SqlParameter s in Projekt.Params.List)
                    if (tb.DataField == s.ParameterName)
                        ParamVal.SetParameter(s, tb.TextBoxText);
            }
            if ((c as TapWebDropDownList) != null)
            {
                TapWebDropDownList dl = (TapWebDropDownList)c;
                foreach (SqlParameter s in Projekt.Params.List)
                    if (dl.DDLDataField == s.ParameterName)
                        ParamVal.SetParameter(s, dl.DDLSelectedValue);
            }
        }
        Bearbeiter.Commons.Projekte_Kaufmann = null;
        Bearbeiter.Commons.ProjekteKO_Kaufmann = null;
        Session["Bearbeiter"] = Bearbeiter;
        Projekt.Update();
        Session["Projekt"] = Projekt;
    }

    private void ReadData()
    {
        foreach (Control c in Panel1.Controls)
        {
            if ((c as TapWebTextBox) != null)
            {
                TapWebTextBox tb = (TapWebTextBox)c;
                foreach (SqlParameter s in Projekt.Params.List)
                    if (tb.DataField == s.ParameterName)
                        ParamVal.SetParameter(s, tb.TextBoxText);
            }
            if ((c as TapWebDropDownList) != null)
            {
                TapWebDropDownList dl = (TapWebDropDownList)c;
                foreach (SqlParameter s in Projekt.Params.List)
                    if (dl.DDLDataField == s.ParameterName)
                        ParamVal.SetParameter(s, dl.DDLSelectedValue);
            }
        }
        Session["Projekt"] = Projekt;
    }

    protected void BtnDefineAZModelB_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            ReadData();
            Response.Redirect("~/Projekt/Projekt_AZModell.aspx?RetUrl=" + Request.RawUrl + "&Restore=1");
        }
    }
    protected void BtnSave_Click(object sender, EventArgs e)
    {
        // Beginn #4686 - Beim anlegen eines projektes sieht man nicht das enddatum der baustell

        //Projekt-Gültigkeitszeitraum ist im Baustelle-Gültigkeitszeitraum
        bool projDateCorrect = true;

        try
        {                
            int idBau = Convert.ToInt32(Baustelle.DDL.SelectedValue);
            SISSITableAdapters.BAUSTELLE_TODATETableAdapter taBaustelleToDate = new SISSITableAdapters.BAUSTELLE_TODATETableAdapter();
            SISSI.BAUSTELLE_TODATEDataTable dtBaustelleToDate = taBaustelleToDate.GetBauDate(idBau);
            SISSI.BAUSTELLE_TODATERow rowBaustelleToDate = (SISSI.BAUSTELLE_TODATERow)dtBaustelleToDate.Rows[0];

            DateTime baustelleStartDate = rowBaustelleToDate.DATVON;
            DateTime baustelleEndDate = rowBaustelleToDate.DATBIS;            
            DateTime projektEndDate = DateTime.Parse(VALID.TB.Text);

            if ((projektEndDate > baustelleEndDate) || (projektEndDate < baustelleStartDate))
            {
                projDateCorrect = false;
                lbBauNotValid.Visible = true;
            }
            else
            {
                projDateCorrect = true;
                lbBauNotValid.Visible = false;
            }

        }
        catch
        {
            projDateCorrect = true;
            lbBauNotValid.Visible = false;
        }

        // Ende #4686

        bool ProjNameExist = false;
        if (!Projekt.AllowUpdate)
            if (isProjNameExist())
                ProjNameExist = true;

        // Beginn #4686 - Beim anlegen eines projektes sieht man nicht das enddatum der baustell
        // Beginn #4780 - Abgrenzen von Aufträgen        
        if ((Page.IsValid) /*&& (KontierCheck()) */&& (!ProjNameExist) && (projDateCorrect)) 
        // Ende #4780 
        // Ende #4686
        {
            if ((int)Projekt.Params.PROJID.Value == 0)
            { //refresh required!
                Bearbeiter.Commons.Projekte_Kaufmann = null;
                Bearbeiter.Commons.ProjekteKO_Kaufmann = null;

            }
            SaveData();
            if (SaveClicked != null) SaveClicked();
        }
    }

    private bool isProjNameExist()
    {
        if (Projekt.ExistProjName(Name.TextBoxText))
        {
            Label1.Visible = true;
            Label1.Text = "* Zu dieser Name gibt es bereits ein Projekt! Bitte verwenden Sie einen anderen Name.";
            return true;
        }
        else
        {
            Label1.Visible = false;
            return false;
        }
    }

    protected void BtnCancel_Click(object sender, EventArgs e)
    {
        if (CancelClicked != null) CancelClicked();
    }

    public string KTOBJChanged(object sender, EventArgs e)
    {   //refresh required
        KontierCheck();
        Bearbeiter.Commons.ProjekteKO_Kaufmann = null;
        return (sender as TextBox).Text;
    }

    public bool KTOBJValid(object Source, ServerValidateEventArgs args)
    {
        ParamVal.SetParameter(Projekt.Params.KTOBJ, KTOBJ.TB.Text);
        // Beginn #4780 - Abgrenzen von Aufträgen
        //return Projekt.KontierbarInSAP();
        return true;
        // Ende #4780
    }


    protected void BtnAusZulAdd_Click(object sender, EventArgs e)
    {
        dbProjektAusZul az = new dbProjektAusZul(Projekt);
        if (DDLAusZul.DDL.SelectedValue != "-1")
        {
            az.Params.LOHNART.Value = DDLAusZul.DDL.SelectedValue;
            az.Params.LOHNARTTXT.Value = DDLAusZul.DDL.SelectedItem.Text;
            bool duplicate = false;
            foreach (dbProjektAusZul z in Projekt.ProjektAusZulagen)
                if (z.Params.LOHNART.Value.ToString() == az.Params.LOHNART.Value.ToString())
                {
                    if (z.Deleted) z.Deleted = false;
                    duplicate = true;
                }
            if (!duplicate) Projekt.ProjektAusZulagen.Add(az);
            Session["Projekt"] = Projekt;
            AusZulListe();
        }
    }

    public void DDLAusZulSelectChange(object sender, EventArgs e)
    {
    }

    public void AusZulListe()
    {
        TableAZListe.Rows.Clear();
        foreach (dbProjektAusZul a in Projekt.ProjektAusZulagen)
        {
            if (!a.Deleted)
            {
                TableRow r = new TableRow();
                TableCell c = new TableCell();
                CheckBox cb = new CheckBox();
                cb.ID = "AZ-" + a.Params.LOHNART.Value;
                cb.Text = a.Params.LOHNARTTXT.Value.ToString();
                c.Controls.Add(cb);
                r.Cells.Add(c);
                TableAZListe.Rows.Add(r);
            }
        }
    }

    protected void BtnAZDelete_Click(object sender, EventArgs e)
    {
        foreach (TableRow r in TableAZListe.Rows)
            foreach (TableCell c in r.Cells)
                foreach (Control ccb in c.Controls)
                    if ((ccb as CheckBox) != null)
                        if ((ccb as CheckBox).Checked)
                            for (int i = Projekt.ProjektAusZulagen.Count - 1; i >= 0; i--)
                                if ((ccb as CheckBox).ID.Substring(3) == (Projekt.ProjektAusZulagen[i] as dbProjektAusZul).Params.LOHNART.Value.ToString())
                                    (Projekt.ProjektAusZulagen[i] as dbProjektAusZul).Deleted = true;
        Session["Projekt"] = Projekt;
        AusZulListe();
    }

    public string AZFilterChanged(object sender, EventArgs e)
    {
        DDLAusZul.Filter = (sender as TextBox).Text;
        DDLAusZul.DDL.Focus();
        return (sender as TextBox).Text;
    }

    public string MLFilterChanged(object sender, EventArgs e)
    {
        Montageleiter.Filter = (sender as TextBox).Text;
        Montageleiter.DDL.Focus();
        return (sender as TextBox).Text;
    }

    private bool KontierCheck()
    {
        Projekt.Params.KTOBJ.Value = KTOBJ.TB.Text;


        if (Projekt.KontierbarInSAP())
        {
            LabelKOError.Visible = true;
            LabelKOError.Font.Bold = false;
            LabelKOError.Text = "überprüft";
            LabelKOError.ForeColor = System.Drawing.Color.Black;
            KTOBJ.TB.Text = Projekt.Params.KTOBJ.Value.ToString();
            //Name.TB.Text = Projekt.Params.NAME.Value.ToString();
            Session["Projekt"] = Projekt;
            return true;
        }
        else
        {
            LabelKOError.Visible = true;
            LabelKOError.Font.Bold = true;
            LabelKOError.Text = "Nicht kontierbar!";
            LabelKOError.ForeColor = System.Drawing.Color.Red;
            KTOBJ.TB.Text = Projekt.Params.KTOBJ.Value.ToString();
            //Name.TB.Text = Projekt.Params.NAME.Value.ToString();
            Session["Projekt"] = Projekt;
            return false;
        }
    }

    protected void BtnKOCheck_Click(object sender, EventArgs e)
    {

        //Defect 5700
        //GN 29.1.2008
        //Beim Drücken dieses Knopfs wird die entsprechende Projektnummer aus dem Cache geleert und damit neu gecacht.
        //TAPM-44
        string Mandant = "Mx";
        try
        {
            Mandant = Bearbeiter.Params.MANDANT.Value.ToString();
        }
        catch
        {
        }
        SAPCache.GetInstance().RemoveFromCache(Mandant + "$" + KTOBJ.TB.Text);

        KontierCheck();
    }

    // Beginn #4780 - Abgrenzen von Aufträgen
    public void KontierCheckPublic()
    {
        KontierCheck();
    } 
    // Ende #4780

    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        VALID.TextBoxText = ((Calendar)sender).SelectedDate.ToShortDateString();
    }
    protected void Calendar1_SelectionChanged1(object sender, EventArgs e)
    {
        VALID.TextBoxText = ((Calendar)sender).SelectedDate.ToShortDateString();
    }

    protected void Button1_Click1(object sender, EventArgs e)
    {
        System.Diagnostics.Debug.Write("raa");
    }
    
    //Vorübergehend Funktionen von ProjektModellazm.cs kopiert
  private ArrayList SelectProjAZM(int projId)
  {
      ArrayList al = new ArrayList();
      string strModell = "";
      // #5672 AZ Modell aus objekt auslesen und nicht jedes mal DB abfragen
      try
      {
          foreach (object obj in Projekt.AZModell.Tage)
          {
              dbProjektAZModellParams p = obj as dbProjektAZModellParams;
              if (Convert.ToDateTime(p.VON.Value) != ParamVal.Date0 || Convert.ToDateTime(p.BIS.Value) != ParamVal.Date0)
              {
                  strModell += Tg[Convert.ToInt32(p.TAG.Value)] + ":"
                      + Convert.ToDateTime(p.VON.Value).ToShortTimeString()
                      + "-"
                      + Convert.ToDateTime(p.BIS.Value).ToShortTimeString()
                      + " ";
              }
          }
          al.Add(new ValuePair(strModell, "0"));//iAZMID.ToString()));
      }
      catch { }
      return al;
      /*
    using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
    {
      try
      {
        cnx.Open();
        // Defect 5725, Config.Rowlock eingeführt
        // Defect 5771, Config.Nolock eingeführt
        String sql = "Select a.PROJAZMID, a.TAG, a.VON, a.BIS from BAUPROJEKT_AZMODELL a " + Config.Nolock + " where a.PROJAZMID = " + projId + "order by a.PROJAZMID, a.TAG";
        using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436, using eingeführt
        {
          using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
          {
            int iAZMID = 0;
            while (rd.Read())
            {
              if (iAZMID != rd.GetInt32(0))
              {
                if (strModell != "")
                {
                  ValuePair vp = new ValuePair(strModell, iAZMID.ToString());
                  bool exists = false;
                  foreach (ValuePair v in al)
                    if (v.Text == strModell)
                    {
                      exists = true;
                      break;
                    }
                  if (!exists) al.Add(vp);
                  strModell = "";
                }
              }
              iAZMID = rd.GetInt32(0);
              if ((rd.GetDateTime(2) != ParamVal.Date0) && (rd.GetDateTime(3) != ParamVal.Date0))
                strModell += Tg[rd.GetInt32(1)] + ":" + rd.GetDateTime(2).ToShortTimeString() + "-" + rd.GetDateTime(3).ToShortTimeString() + " ";
            }
            if (strModell != "")
            {
              ValuePair vp = new ValuePair(strModell, iAZMID.ToString());
              bool exists = false;
              foreach (ValuePair v in al)
                if (v.Text == strModell)
                {
                  exists = true;
                  break;
                }
              if (!exists) al.Add(vp);
            }
          }
        }
      }
      catch (Exception ex) { throw ex; }
      finally { cnx.Close(); }
    }
    return al;
       */
  }

    private Label BuildAZMList()
    {
        Label l = new Label();
        // # 5672 Es gibt nur ein Projekt oder gar keinen AZ Modell, also foreach schleife ist unnötig
        try
        {
            l.Text = (AZMTage[0] as ValuePair).Text;
        }
        catch { }
        return l;
        //RBList.ID = "RBLAZM";
        //RBList.AutoPostBack = true;
        //RBList.OnSelectedIndexChanged = RBLAZM_SelectedIndexChanged;
        /*
        string Itemtext = "";
        int iCount = 0;
        foreach (ValuePair vp in AZMTage)
        {
            if (iCount < AZMTage.Count - 1)
            {
                if ((AZMTage[iCount] as ValuePair).Value == (AZMTage[iCount + 1] as ValuePair).Value)
                    Itemtext += vp.Text + ", ";
                else
                {
                    Itemtext += (AZMTage[iCount] as ValuePair).Text + ", ";
                }
                if ((AZMTage[iCount] as ValuePair).Value != (AZMTage[iCount + 1] as ValuePair).Value)
                {
                    Itemtext = Itemtext.Substring(0, Itemtext.Length - 2);
                    l.Text += Itemtext;
                    Itemtext = "";
                }
            }
            else
            {
                Itemtext += (AZMTage[iCount] as ValuePair).Text + ", ";
                Itemtext = Itemtext.Substring(0, Itemtext.Length - 2);
                l.Text = Itemtext;
                Itemtext = "";
            }
            iCount++;
        }
        return l;
        */
    }
}
