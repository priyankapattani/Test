//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : Projekt_AZModell.aspx.cs
//
// Description  : Verwaltung des AZModells von Projekt
//
//=============== V1.0.0038 ===============================================
//
// Date         : 28.Februar 2008
// Author       : Joldic Dzevad
// Defect#      : 5672
//                Button zum L�schen/R�cksetzen von AZModell implementiert
//                Ein neues dbProjektAZModell object wird erzeugt und 
//                verwendet anstatt von tmpProject zum tempr�ren AZ Modell
//                Berabeitung
//
//=============== V1.0.0037 ===============================================
//
// Date         : 15.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 14.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//=============== V1.0.0029 ===============================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=========================================================================

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using TapMontage.Misc;

public partial class Projekt_Projekt_AZModel : System.Web.UI.Page
{
    dbProjekt Projekt;
    // dbProjekt tmpProjekt; // Defect 5672 gleiches objekt wie Projekt -> Fehler
    dbProjektAZModell azModell; // Defect 5672 ein neues object mit new erzeugt
    dbBearbeiter Bearbeiter;
    ArrayList AZMTage;
    protected void Page_Load(object sender, EventArgs e)
    {
        Projekt = (dbProjekt)Session["Projekt"];
        // tmpProjekt = (dbProjekt)Session["tmpProjekt"];
        //Defect 5672 ein neues object mit new erzeugen oder aus der Session Variable auslesen
        try
        {
            azModell = (dbProjektAZModell)Session["AZModell"];
        }
        catch
        {
        }
        if (azModell == null)
        {
            azModell = new dbProjektAZModell(Projekt, false);
        }
        // if (tmpProjekt == null) tmpProjekt = (dbProjekt)Session["Projekt"];
        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        FilterBau.TextBoxChangedDelegee = FilterBauChanged;
        DDLOffeneBaustellenMitAZM.SelIndexChanged = BaustelleSelectChange;
        if (Page.IsPostBack)
        {
            AZMTage = SelectProjAZMForOpenBaustelle(Convert.ToInt32( DDLOffeneBaustellenMitAZM.DDL.SelectedValue));
            PHAZM.Controls.Add(BuildAZMList());
        }

        AZModell(false);
    }
    //Defect 5672 Session Variable immer aktualisieren
    protected void Page_PreRender(object sender, EventArgs e)
    {
        try
        {
            Session["AZModell"] = azModell;
        }
        catch { }
    }
    public string FilterBauChanged(object sender, EventArgs e)
    {
        DDLOffeneBaustellenMitAZM.Filter = (sender as TextBox).Text;
        DDLOffeneBaustellenMitAZM.DDL.Focus();
        return (sender as TextBox).Text;
    }
    public void BaustelleSelectChange(object sender, EventArgs e)
    {
        AZMTage = SelectProjAZMForOpenBaustelle(Convert.ToInt32((sender as DropDownList).SelectedValue));
        PHAZM.Controls.Clear();
        PHAZM.Controls.Add(BuildAZMList());
    }

    private ArrayList SelectProjAZMForOpenBaustelle(int bauid)
    {
        ArrayList al = new ArrayList();
        string strModell = "";
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                // Defect 5725, Config.Rowlock eingef�hrt
                // Defect 5771, Config.Nolock eingef�hrt
                using (SqlCommand cmd = new SqlCommand("Select a.PROJAZMID, a.TAG, a.VON, a.BIS from BAUPROJEKT_AZMODELL a " + Config.Nolock + ", BAUPROJEKT p " + Config.Nolock + " where p.bauid=" + bauid + " and  a.PROJAZMID = p.PROJID order by a.PROJAZMID, a.TAG", cnx)) // Defect 5436, using eingef�hrt
                {
                  using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                  {
                    int iAZMID = 0;
                    while (rd.Read())
                    {
                      if (iAZMID != rd.GetInt32(0))
                      {
                        if (strModell != "")
                        {
                          ValuePair vp = new ValuePair(strModell, iAZMID.ToString());
                          bool exists = false;
                          foreach (ValuePair v in al)
                            if (v.Text == strModell)
                            {
                              exists = true;
                              break;
                            }
                          if (!exists) al.Add(vp);
                          strModell = "";
                        }
                      }
                      iAZMID = rd.GetInt32(0);
                      if ((rd.GetDateTime(2) != ParamVal.Date0) && (rd.GetDateTime(3) != ParamVal.Date0))
                        strModell += Tg[rd.GetInt32(1)] + ":" + rd.GetDateTime(2).ToShortTimeString() + "-" + rd.GetDateTime(3).ToShortTimeString() + " ";
                    }

                    if (strModell != "")
                    {
                      ValuePair vp = new ValuePair(strModell, iAZMID.ToString());
                      bool exists = false;
                      foreach (ValuePair v in al)
                        if (v.Text == strModell)
                        {
                          exists = true;
                          break;
                        }
                      if (!exists) al.Add(vp);
                    }
                  }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
        }
        return al;
    }
    private RadioButtonList BuildAZMList()
    {
        RadioButtonList RBList = new RadioButtonList();
        //RBList.ID = "RBLAZM";
        //RBList.AutoPostBack = true;
        //RBList.OnSelectedIndexChanged = RBLAZM_SelectedIndexChanged;
        
        string Itemtext = "";
        int iCount = 0;
        foreach (ValuePair vp in AZMTage)
        {
            if (iCount < AZMTage.Count - 1)
            {
                if ((AZMTage[iCount] as ValuePair).Value == (AZMTage[iCount + 1] as ValuePair).Value)
                    Itemtext += vp.Text + ", ";
                else
                {
                    Itemtext += (AZMTage[iCount] as ValuePair).Text + ", ";
                }
                if ((AZMTage[iCount] as ValuePair).Value != (AZMTage[iCount + 1] as ValuePair).Value)
                {
                    Itemtext = Itemtext.Substring(0, Itemtext.Length - 2);
                    RBList.Items.Add(new ListItem(Itemtext, (AZMTage[iCount] as ValuePair).Value));
                    Itemtext = "";
                }
            }
            else
            {
                Itemtext += (AZMTage[iCount] as ValuePair).Text + ", ";
                Itemtext = Itemtext.Substring(0, Itemtext.Length - 2);
                RBList.Items.Add(new ListItem(Itemtext, (AZMTage[iCount] as ValuePair).Value));
                Itemtext = "";
            }
            iCount++;
        }
        RBList.ID = "PAZMRBL1";
        RBList.AutoPostBack = true;
        RBList.SelectedIndexChanged += new EventHandler(RBList_SelectedIndexChanged);
        return RBList;

    }

    void RBList_SelectedIndexChanged(object sender, EventArgs e)
    {
        string strAZM = (sender as RadioButtonList).SelectedItem.Text;
        string strID = (sender as RadioButtonList).SelectedItem.Value;
        dbProjekt p2 = new dbProjekt(Projekt.Baustelle);
        p2.Params.PROJID.Value = Convert.ToInt32(strID);
        p2.Select();
        for (int i = 0; i < p2.AZModell.Tage.Count; i++)
        {
            // Defect 5672 dbProjektAZModell verwenden anstatt von tmpProjekt
            // (tmpProjekt.AZModell.Tage[i] as dbProjektAZModellParams).VON.Value = (p2.AZModell.Tage[i] as dbProjektAZModellParams).VON.Value;
            // (tmpProjekt.AZModell.Tage[i] as dbProjektAZModellParams).BIS.Value = (p2.AZModell.Tage[i] as dbProjektAZModellParams).BIS.Value;
            (azModell.Tage[i] as dbProjektAZModellParams).VON.Value = (p2.AZModell.Tage[i] as dbProjektAZModellParams).VON.Value;
            (azModell.Tage[i] as dbProjektAZModellParams).BIS.Value = (p2.AZModell.Tage[i] as dbProjektAZModellParams).BIS.Value;
        }
        AZModell(true);
        Session["AZModell"] = azModell;
    }
    private string[] Tag = new string[] { "Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag" };
    private string[] Tg = new string[] { "SO", "MO", "DI", "MI", "DO", "FR", "SA" };
    private void AZModell(bool clear)
    {
        if (clear) TabAZModell.Rows.Clear();
        TableRow tr = new TableRow();
        TableCell tc1 = new TableCell();
        TableCell tc2 = new TableCell();
        TableCell tc3 = new TableCell();
        Label h2 = new Label(); h2.Text = "von"; h2.Font.Bold = true;
        Label h3 = new Label(); h3.Text = "bis"; h3.Font.Bold = true;
        tc2.Controls.Add(h2);
        tc3.Controls.Add(h3);
        tr.Cells.Add(tc1);
        tr.Cells.Add(tc2);
        tr.Cells.Add(tc3);
        TabAZModell.Rows.Add(tr);
        for (int i = dbProjektAZModell.Sonntag; i <= dbProjektAZModell.Samstag; i++)
        {
            dbProjektAZModellParams p = (azModell.Tage[(i + 1) % (dbProjektAZModell.Samstag + 1)] as dbProjektAZModellParams);
            TableRow r = new TableRow();
            TableCell c = new TableCell();
            TableCell v = new TableCell();
            TableCell b = new TableCell();
            Label l = new Label();
            l.Text = Tag[(i + 1) % (dbProjektAZModell.Samstag + 1)];
            TextBox von = new TextBox();
            von.Width = Unit.Pixel(60);
            TextBox bis = new TextBox();
            bis.Width = Unit.Pixel(60);
            if (p.VON.Value != p.BIS.Value)
            {
                //n�n�n�! alle eingaben sind zul�ssig! if (Convert.ToDateTime(p.VON.Value).CompareTo(Convert.ToDateTime(p.BIS.Value)) == 1 ) p.BIS.Value = p.VON.Value;
                von.Text = Convert.ToDateTime(p.VON.Value).ToShortTimeString();
                bis.Text = Convert.ToDateTime(p.BIS.Value).ToShortTimeString();
            }
            c.Controls.Add(l);
            v.Controls.Add(von);
            b.Controls.Add(bis);
            r.Cells.Add(c);
            r.Cells.Add(v);
            r.Cells.Add(b);
            TabAZModell.Rows.Add(r);
        }
    }
    private void ReadTable()
    {
        for (int day = 1; day <= TabAZModell.Rows.Count - 1; day++)
        {
            DateTime von = ParamVal.Date0;
            DateTime bis = ParamVal.Date0;
            von = Convert.ToDateTime(ParamVal.Date0.ToShortDateString() + " " + RangeCheck.FixTime((TabAZModell.Rows[day].Cells[1].Controls[0] as TextBox).Text));
            bis = Convert.ToDateTime(ParamVal.Date0.ToShortDateString() + " " + RangeCheck.FixTime((TabAZModell.Rows[day].Cells[2].Controls[0] as TextBox).Text));
            dbProjektAZModellParams p = (dbProjektAZModellParams)azModell.Tage[day % (dbProjektAZModell.Samstag + 1)];
            p.VON.Value = von;
            p.BIS.Value = bis;
        }
    }

    protected void BtnAZSave_Click(object sender, EventArgs e)
    {
        if (laberr.Text == "")
        {
            ReadTable();
            for (int day = 1; day <= TabAZModell.Rows.Count - 1; day++)
            {
                DateTime von = ParamVal.Date0;
                DateTime bis = ParamVal.Date0;
                von = Convert.ToDateTime(ParamVal.Date0.ToShortDateString() + " " + RangeCheck.FixTime((TabAZModell.Rows[day].Cells[1].Controls[0] as TextBox).Text));
                bis = Convert.ToDateTime(ParamVal.Date0.ToShortDateString() + " " + RangeCheck.FixTime((TabAZModell.Rows[day].Cells[2].Controls[0] as TextBox).Text));
                dbProjektAZModellParams p = (dbProjektAZModellParams)Projekt.AZModell.Tage[day % (dbProjektAZModell.Samstag + 1)];
                p.VON.Value = von;
                p.BIS.Value = bis;
            }
            // Defect 5672 save and back to caller
            Session["Projekt"] = Projekt;
            Session["AZModell"] = null;
            string tempRetUrl = "";
            if (Request.QueryString["RetUrl"] != null)
            {
                tempRetUrl = Request.QueryString["RetUrl"].ToString();
                if (tempRetUrl.IndexOf("?") > 0)
                    tempRetUrl = tempRetUrl.Substring(0, tempRetUrl.IndexOf("?"));
                Response.Redirect(tempRetUrl + "?Restore=" + Request.QueryString["Restore"]);
            }
        }
    }
    protected void BtnBack_Click(object sender, EventArgs e)
    {
        string tempRetUrl = "";
        Session["AZModell"] = null;
        if (Request.QueryString["RetUrl"] != null)
        {
            tempRetUrl = Request.QueryString["RetUrl"].ToString();
            if (tempRetUrl.IndexOf("?") > 0)
                tempRetUrl = tempRetUrl.Substring(0, tempRetUrl.IndexOf("?"));
            Response.Redirect(tempRetUrl + "?Restore=" + Request.QueryString["Restore"]);
        }
    }

    // Defect 5672 Funktion zum L�schen/R�cksetzen von AZModell
    protected void AZModellDelete_Click(object sender, EventArgs e)
    {
        foreach (dbProjektAZModellParams p in azModell.Tage)
        {
            p.VON.Value = Convert.ToDateTime(ParamVal.Date0);
            p.BIS.Value = Convert.ToDateTime(ParamVal.Date0);
        }
        AZModell(true);
        Session["AZModell"] = azModell;
    }
}
