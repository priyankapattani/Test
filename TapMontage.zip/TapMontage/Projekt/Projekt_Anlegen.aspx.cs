﻿//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : Projekt_Anlegen.aspx.cs
//
// Description  : Anlegen eines Projektes
//
//--------------- V1.0.0034 ---------------------------------------------------
//
// Date         : 30.August 2007
// Author       : Adam Kiefer
// Defect#      : 5416
//                Anzeige Kopfdaten
//
//=============== V1.0.0029 ===================================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using TapMontage.dbObjects;

public partial class Projekt_Anlegen : System.Web.UI.Page
{
    dbBearbeiter Bearbeiter;
    dbProjekt Projekt;
    dbBaustelle Baustelle;

    protected void Page_Load(object sender, EventArgs e)
    {
        // Beginn #5416 - Anzeige Kopfdaten
        /* Kopfdaten einstellen */
        try
        {
            if (Session["headData"] == null)
                Session.Add("headData", "");

            Session["headData"] = "<span style=\"font-size: 20px;\">Projekt anlegen</span>";
        }
        catch
        {/* Nicht behandelt! */}
        // Ende #5416

        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["Restore"] != null)
            {
                Baustelle = (dbBaustelle)Session["Baustelle"];
                Projekt = (dbProjekt)Session["Projekt"];
                Projekt_Detail1.ProjektID = (int)Projekt.Params.PROJID.Value;
            }
            else
            {
                Session["Baustelle"] = Baustelle = new dbBaustelle(Bearbeiter);
                Session["Projekt"] = Projekt = new dbProjekt(Baustelle);
            }
        }
        else
        {
            Baustelle = (dbBaustelle)Session["Baustelle"];
            Projekt = (dbProjekt)Session["Projekt"];
        }
        Projekt_Detail1.SaveClicked = btnSave_Click;
    }
    protected void btnSave_Click()
    {
        string tempRawu = Request.RawUrl;
        if (tempRawu.IndexOf("?") > 0)
            tempRawu = tempRawu.Substring(0, tempRawu.IndexOf("?"));
        Response.Redirect(tempRawu + "?Message=Gespeichert!");
    }
}
