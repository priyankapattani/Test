//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : RAAuslage.ascx.cs
//
// Description  : Bietet Funktionalit�t zum Verwalten von Reiseauslagen
//                Control wird verwendet von Edit_EB.aspx.cs
//
//=============== V1.0.0046 ===============================================
//
// Date         : 12.Dezember 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-39
//                RA Auslage bleibt erhalten, obwohl AZ gel�scht ist
//
//=============== V1.0.0037 ===============================================
//
// Date         : 15.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//=============== V1.0.0033 ===============================================
//
// Date         : 30.Juli 2007
// Author       : NK
// Defect#      : 5433, 5442
//                vergleich um id erweitern
//
//=============== V1.0.0032 ===============================================
//
// Date         : 30.Juli 2007
// Author       : Adam Kiefer
// Defect#      : 5190, 5211
//                Erfassen KFZ-Daten , anzeigen falsches Kalendermonat; KFZ-Fahrt l�schen
//
//=============== V1.0.0029 ===============================================
//
// Date         : 18.Juli 2007
// Author       : Adam Kiefer
// Defect#      : 4418
//                Generierung Auslagen
//
//=============== V1.0.0029 ===============================================
//
// Date         : 03. Juli 2007
// Author       : Wolfgang Patrman
// Defect#      : 5239
//                �berpr�fung der Reiseauslagen, ob sich diese innerhalb
//                der Arbeitszeit befinden, korrigiert
//
//=============== V1.0.0028 ===============================================
//
// Date         : 01. Juni 2007
// Author       : Wolfgang Patrman
// Defect#      : 4887
//                �berpr�fung der Reiseauslagen, ob diese innerhalb der
//                der Arbeitszeit
//
//=============== V1.0.0028 ===============================================
//
// Date         : 29.Mai 2007
// Author       : GN
// Defect#      : 5127
//                Text von Reiseauslagen mit Status 40 wird nun korrekt angezeigt
//
//=============== V1.0.0022 ===============================================
//
// Date         : 19.Februar 2007
// Author       : GN
// Defect#      : 4650
//                Barauslagen d�fen nur an Arbeitstagen eingetragen werden
//
//=========================================================================

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using TapMontage.Misc;

// Beginn #4418 - Generierung Auslagen
public class ReiseauslagenComparer : System.Collections.IComparer
{
    public int Compare(object obj1, object obj2)
    {
        int retVal = 0;

        dbRAAuslage RAAuslage1 = (dbRAAuslage)obj1;
        dbRAAuslage RAAuslage2 = (dbRAAuslage)obj2;

        DateTime date1 = Convert.ToDateTime(RAAuslage1.Params.DATUM.Value);
        DateTime date2 = Convert.ToDateTime(RAAuslage2.Params.DATUM.Value);
        // defect 5433, 5442 vergleich um id erweitern
        int RAAUSLAGEID_1 = Convert.ToInt32(RAAuslage1.Params.RAAUSLAGEID.Value);
        int RAAUSLAGEID_2 = Convert.ToInt32(RAAuslage2.Params.RAAUSLAGEID.Value);
        if (date1 < date2)
        {
            retVal = -1;
        }
        else
        {
            if ( date1 == date2 )
            {
                if (RAAUSLAGEID_1 < RAAUSLAGEID_2)
                {
                    retVal = -1;
                }
                else
                {
                    retVal = 1;
                }
            }
            else
            {
                retVal = 1;
            }
        }
        return retVal;
        // defect ende 5433, 5442 vergleich um id erweitern
    }
} 
// Ende #4418

public partial class Einsatzbericht_RAAuslage : System.Web.UI.UserControl
{
  dbMontBer Monber;
  
  private bool isEdit = false;
  string Argument = "";

  protected void Page_Load(object sender, EventArgs e)
  {

    Monber = (dbMontBer)Session["MBericht"];
    if (Monber.Reiseauslagen.Count != 0)
      phTable.Controls.Add(RAuslageTable());

      // Beginn #5190, 5211 - Erfassen KFZ-Daten , anzeigen falsches Kalendermonat; KFZ-Fahrt l�schen
      TapWebTextBox1.SelectedDate = Monber.MinDatum.ToString();
      // Ende #5190, 5211
  }

  // Beginn Defect 4887
  public bool bOnlyValidRA
  {
    get
    {
      return CheckRAAuslagen();
    }
  }

  // Error Label hinzugef�gt
  public string strLabError
  {
    set
    {
      LabError.Text = value;
      if (LabError.Text != "")
      {
        LabError.Visible = true;
      }
    }
    get
    {
      return LabError.Text;
    }
  }
  // Ende Defect 4887

    public bool Enabled
    {
        get { return panMain.Enabled; }
        set { panMain.Enabled = value; }
    }

    protected void btnInsert_Click(object sender, EventArgs e)
    {
        dbRAAuslage RAAuslage = new dbRAAuslage(Monber);

        

        //if (Page.IsValid && CheckDate(TapWebTextBox1.TextBoxText))
        if (CheckDate(TapWebTextBox1.TextBoxText) && CheckValid(TapWebTextBox2.TextBoxText, TapWebTextBox3.TextBoxText))
        {

            //Defect 4650
            //GN 19.02.2007 Barauslagen nur am Arbeitstag (Insert)
            DateTime d = Convert.ToDateTime(TapWebTextBox1.TextBoxText);

            dbArbTag tag = (dbArbTag)Monber.Tage[d.Day-1];

            bool valid = false;
            foreach (dbArbZeit z in tag.Zeiten)
            {
                if ((z.Kommen != ParamVal.Date0 && z.Gehen != ParamVal.Date0 && z.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz && !z.Deleted)) valid = true;
            }

            if (!tag.Relevanz) valid = false;

            if (valid)
            {

                foreach (Control c in panMain.Controls)
                {
                    if ((c as TapWebTextBox) != null)
                        foreach (SqlParameter bs in RAAuslage.Params.List)
                            if (((TapWebTextBox)c).DataField == bs.ParameterName)
                                bs.Value = ParamVal.SetParameter(bs, ((TapWebTextBox)c).TextBoxText);
                    if ((c as TapWebDropDownList) != null)
                        if ((c as TapWebDropDownList).Visible)
                            foreach (SqlParameter bs in RAAuslage.Params.List)
                                if (((TapWebDropDownList)c).DDLDataField == bs.ParameterName)
                                    bs.Value = ParamVal.SetParameter(bs, ((TapWebDropDownList)c).DDLSelectedValue);
                    if ((c as DropDownList) != null)
                        foreach (SqlParameter bs in RAAuslage.Params.List)
                            if (((DropDownList)c).DataTextFormatString == bs.ParameterName)
                                bs.Value = ParamVal.SetParameter(bs, ((DropDownList)c).SelectedValue);
                }
                RAAuslage.Params.EBID.Value = Monber.Params.EBID.Value.ToString();
                Monber.Reiseauslagen.Add(RAAuslage);
                phTable.Controls.Clear();
                phTable.Controls.Add(RAuslageTable());
            }
            else
            {
                Label2.Visible = false;
                Label3.Visible = false;
                label1.Visible = true;
                label1.ForeColor = System.Drawing.Color.Red;
                label1.Text = "* Barauslagen d�rfen nur an einem Arbeitstag angegeben werden.";
            }
        }
        btnInsert.Focus();
    }
    private bool CheckDate(string s)
    {
        if (!RangeCheck.IsDate(RangeCheck.FixDate(s)))
        {
            Label2.Visible = false;
            Label3.Visible = false;
            label1.Visible = true;
            label1.ForeColor = System.Drawing.Color.Red;
            label1.Text = "* Geben Sie bitte ein g�ltiges Datum an, z.B.: " + DateTime.Now.ToShortDateString();
            return false;
        }
        else
        {
            DateTime dt = Convert.ToDateTime(s);
            long dasDat = dt.Year * 1000 + dt.Month * 10;
            dt = Monber.MinDatum;
            long monberDat = dt.Year * 1000 + dt.Month * 10;
            if (dasDat == monberDat)
            {
                label1.Visible = false;
                return true;
            }
            else
            {
                Label2.Visible = false;
                Label3.Visible = false;
                label1.Visible = true;
                label1.ForeColor = System.Drawing.Color.Red;
                label1.Text = "* Geben Sie bitte ein g�ltiges Datum innerhalb des Monatsberichtes ein.";
                return false;
            }
        }
    }

    private bool CheckValid(string s1, string s2)
    {
        double x = 10101.99;
        string msg = "* Geben Sie bitte eine Zahl an, z.B.: " + x.ToString("N");
        if ((s1 == "") | !RangeCheck.IsNumeric(s1))
        {
            Label2.Visible = true;
            Label2.ForeColor = System.Drawing.Color.Red;
            Label2.Text = msg;
            return false;
        }
        else if ((s2 == "") | !RangeCheck.IsNumeric(s2))
        {
            Label2.Visible = false;
            Label3.Visible = true;
            Label3.ForeColor = System.Drawing.Color.Red;
            Label3.Text = msg;
            return false;
        }
        else
        {
            Label2.Visible = false;
            Label3.Visible = false;
            return true;
        }
    }

    private Table RAuslageTable()
    {
        xxID = 0;
        Table RAuslage = new Table();

        RAuslage.Width = Unit.Percentage(100);
        TableRow HeaderRow = new TableRow();
        TableCell c1 = new TableCell();
        c1.Text = "Datum";
        c1.HorizontalAlign = HorizontalAlign.Center;
        c1.Font.Bold = true;
        c1.CssClass = "TabHeader";
        TableCell c2 = new TableCell();
        c2.Text = "Auslagenart";
        c2.Font.Bold = true;
        c2.CssClass = "TabHeader";
        TableCell c3 = new TableCell();
        c3.Text = "Anzahl";
        c3.Font.Bold = true;
        c3.CssClass = "TabHeader";
        TableCell c4 = new TableCell();
        c4.Text = "Betrag";
        c4.Font.Bold = true;
        c4.CssClass = "TabHeader";
        TableCell c5 = new TableCell();
        c5.CssClass = "TabHeader";
        TableCell c6 = new TableCell();
        c6.CssClass = "TabHeader";

        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        HeaderRow.Cells.Add(c3);
        HeaderRow.Cells.Add(c4);
        HeaderRow.Cells.Add(c5);
        HeaderRow.Cells.Add(c6);
        RAuslage.Rows.Add(HeaderRow);
        //...
        string sarg = "";
        sarg = (string)Page.Cache["Edit-ID"];
        LinkButton lnkbtn;
        int iRAzeile = 0;
        string strCssClassRow = "TabNewDay";

        // Beginn #4418 - Generierung Auslagen
        ReiseauslagenComparer comp = new ReiseauslagenComparer();
        Monber.Reiseauslagen.Sort(comp); 
        // Ende #4418

        foreach (dbRAAuslage ra in Monber.Reiseauslagen)
        {
            if (!ra.Deleted)
            {
                HeaderRow.Visible = true;
                Argument = "R-" + iRAzeile.ToString();
                TableRow tr = new TableRow();
                TableCell d1 = new TableCell();
                d1.CssClass = strCssClassRow;
                d1.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + ParamVal.GetParameter(ra.Params.DATUM);
                d1.HorizontalAlign = HorizontalAlign.Center;
                if (isEdit && sarg.Substring(2) == iRAzeile.ToString())
                    d1.ForeColor = System.Drawing.Color.Blue;
                tr.Cells.Add(d1);

                TableCell d2 = new TableCell();
                d2.CssClass = strCssClassRow;

                //Defect 5127
                //Auch Barauslagen mit Status 40 sollen angezeigt werden.
                //vormals: d2.Text = Monber.Bearbeiter.Commons.vpGetText(Monber.Bearbeiter.Commons.Auslagenarten, ra.Params.RAKZ.Value.ToString());
                //Start der �nderung 5127
                using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
                {
                    cnx.Open();
                    // Defect 5127 Dieses Select ignoriert den Status
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    using (SqlCommand cmd = new SqlCommand("SELECT RAKZTXT FROM Y_RAKZ " + Config.Nolock + " WHERE RAKZID = 'AAI' and rakz=@RAKZ", cnx)) // Defect 5436, using eingef�hrt
                    {
                      cmd.Parameters.Add(ra.Params.RAKZ);
                      using (SqlDataReader reader = cmd.ExecuteReader()) // Defect 5436
                      {
                        if (reader.Read())
                        {
                          d2.Text = reader.GetString(0); //5127 Setzt den Text im GUI
                        }
                        cmd.Parameters.Remove(ra.Params.RAKZ);
                      }
                    }
                }
                //Ende der �nderung 5127




                if (isEdit && sarg.Substring(2) == iRAzeile.ToString())
                    d2.ForeColor = System.Drawing.Color.Blue;
                tr.Cells.Add(d2);
                TableCell d3 = new TableCell();
                d3.CssClass = strCssClassRow;
                d3.Text = ParamVal.GetParameter(ra.Params.ANZAHL);
                if (isEdit && sarg.Substring(2) == iRAzeile.ToString())
                    d3.ForeColor = System.Drawing.Color.Blue;
                tr.Cells.Add(d3);

                TableCell d4 = new TableCell();
                d4.CssClass = strCssClassRow;
                d4.Text = ParamVal.GetParameter(ra.Params.BETRAG);
                if (isEdit && sarg.Substring(2) == iRAzeile.ToString())
                    d4.ForeColor = System.Drawing.Color.Blue;
                tr.Cells.Add(d4);

                TableCell d5 = new TableCell();
                d5.CssClass = strCssClassRow;
                lnkbtn = NewTaskButton("Bearbeiten", "Edit", Argument, "Eintrag bearbeiten", TaskButton_Click);
                d5.Controls.Add(lnkbtn);
                if (isEdit && sarg.Substring(2) == iRAzeile.ToString())
                    lnkbtn.Enabled = false;
                tr.Cells.Add(d5);

                TableCell d6 = new TableCell();
                d6.CssClass = strCssClassRow;
                lnkbtn = NewTaskButton("L�schen", "Delete", Argument, "Eintrag l�schen", TaskButton_Click);
                d6.Controls.Add(lnkbtn);
                d6.HorizontalAlign = HorizontalAlign.Left;
                if (isEdit && sarg.Substring(2) == iRAzeile.ToString())
                    lnkbtn.Enabled = false;
                tr.Cells.Add(d6);
                RAuslage.Rows.Add(tr);
            }
            else
            {
                if (iRAzeile == 0)
                    HeaderRow.Visible = false;
            }
            iRAzeile++;
        }
        return RAuslage;
    }

    private LinkButton NewTaskButton(string Text, string Command, string Argument, string ToolTip, CommandEventHandler TaskButtonClick_EventHandler)
    {
        LinkButton btn = new LinkButton();
        btn.ID = nid();
        btn.SkinID = "";
        btn.Width = Unit.Percentage(100);
        btn.Text = Text;
        btn.CommandName = Command;
        btn.CommandArgument = Argument;
        btn.ToolTip = ToolTip;
        btn.Command += new CommandEventHandler(TaskButtonClick_EventHandler);
        //cList.Add(btn);
        return btn;
    }

    public int xxID = 0;
    public string nid()
    {
        xxID++;
        return "LnkBTN->" + xxID.ToString();
    }
    void TaskButton_Click(object sender, CommandEventArgs e)
    {
        string cmd = (string)e.CommandName;
        string arg = (string)e.CommandArgument;

        // Defect 4887
        // L�schen einer evtl. angezeigten Fehlermeldung
        strLabError = "";

        switch (cmd)
        {
            case "Edit":
                isEdit = true;
                btnInsert.Visible = false;
                Btn_CellSave.Visible = true;
                Btn_CellCancel.Visible = true;
                Page.Cache["Edit-ID"] = arg;
                int iEditzeile = Monber.Reiseauslagen.Count - 1;
                for (int i = Monber.Reiseauslagen.Count - 1; i >= 0; i--)
                {
                    if (arg.Substring(2) == iEditzeile.ToString())
                    {
                        foreach (Control c in panMain.Controls)
                        {
                            if ((c as TapWebTextBox) != null)
                                foreach (SqlParameter ra in (Monber.Reiseauslagen[i] as dbRAAuslage).Params.List)
                                    if (((TapWebTextBox)c).DataField == ra.ParameterName)
                                        ((TapWebTextBox)c).TextBoxText = ParamVal.GetParameter(ra);
                            if ((c as TapWebDropDownList) != null)
                                foreach (SqlParameter ra in (Monber.Reiseauslagen[i] as dbRAAuslage).Params.List)
                                    if (((TapWebDropDownList)c).DDLDataField == ra.ParameterName)
                                        ((TapWebDropDownList)c).DDLSelectedValue = ParamVal.GetParameter(ra);
                        }
                    }
                    iEditzeile--;
                }
                Btn_CellSave.Focus();
                break;
            case "Delete":
                int iDelzeile = Monber.Reiseauslagen.Count - 1;
                for (int i = Monber.Reiseauslagen.Count - 1; i >= 0; i--)
                {
                    if (arg.Substring(2) == iDelzeile.ToString())
                    {
                        dbRAAuslage raa = (dbRAAuslage)Monber.Reiseauslagen[i];
                        raa.Deleted = true;
                    }
                    iDelzeile--;
                }
                btnInsert.Focus();
                CheckRAAuslagen(); // Defect 4887: Nachdem Raauslage gel�scht wurde, neuerliche �berpr�fung
                break;
            default:
                Exception ex = new Exception("Command not recognised: " + cmd);
                throw ex;
        }
        phTable.Controls.Clear();
        if (Monber.Reiseauslagen.Count != 0)
            phTable.Controls.Add(RAuslageTable());
    }

    protected void Btn_CellSave_Click(object sender, EventArgs e)
    {
        string arg = (string)Page.Cache["Edit-ID"];
        bool valid = false; // Defect 4887

        //if (Page.IsValid && CheckDate(TapWebTextBox1.TextBoxText))
        if (CheckDate(TapWebTextBox1.TextBoxText) && CheckValid(TapWebTextBox2.TextBoxText, TapWebTextBox3.TextBoxText))
        {

            //Defect 4650
            //GN 19.02.2007 Barauslagen nur am Arbeitstag (Edit)
            DateTime d = Convert.ToDateTime(TapWebTextBox1.TextBoxText);

            dbArbTag tag = (dbArbTag)Monber.Tage[d.Day - 1];

            //bool valid = false; Defect 4887
            foreach (dbArbZeit z in tag.Zeiten)
            {
                if ((z.Kommen != ParamVal.Date0 && z.Gehen != ParamVal.Date0 && z.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz && !z.Deleted)) valid = true;
            }

            if (!tag.Relevanz) valid = false;

            isEdit = false;
            btnInsert.Visible = true;
            Btn_CellSave.Visible = false;
            Btn_CellCancel.Visible = false;
            int iZeile = Monber.Reiseauslagen.Count - 1;
            if (valid)
            {
                for (int i = Monber.Reiseauslagen.Count - 1; i >= 0; i--)
                {
                    if (arg.Substring(2) == iZeile.ToString())
                    {
                        dbRAAuslage ra = (dbRAAuslage)Monber.Reiseauslagen[i];
                        foreach (Control c in panMain.Controls)
                        {
                            if ((c as TapWebTextBox) != null)
                                foreach (SqlParameter mr in ra.Params.List)
                                    if (((TapWebTextBox)c).DataField == mr.ParameterName)
                                        mr.Value = ParamVal.SetParameter(mr, ((TapWebTextBox)c).TextBoxText);
                            if ((c as TapWebDropDownList) != null)
                                if ((c as TapWebDropDownList).Visible)
                                    foreach (SqlParameter mr in ra.Params.List)
                                        if (((TapWebDropDownList)c).DDLDataField == mr.ParameterName)
                                            mr.Value = ParamVal.SetParameter(mr, ((TapWebDropDownList)c).DDLSelectedValue);
                        }
                    }
                    iZeile--;
                }
                btnInsert.Focus();
            }
            else
            {
                Label2.Visible = false;
                Label3.Visible = false;
                label1.Visible = true;
                label1.ForeColor = System.Drawing.Color.Red;
                label1.Text = "* Barauslagen d�rfen nur an einem Arbeitstag angegeben werden.";
            }

        }
        else
        {
            isEdit = true;
            Btn_CellSave.Focus();
        }
        phTable.Controls.Clear();
        if (Monber.Reiseauslagen.Count != 0)
            phTable.Controls.Add(RAuslageTable());

        // Beginn Defect 4887
        if (valid)
        {
            // �berpr�fung ob weiter Datums-Fehler vorhanden sind
            CheckRAAuslagen();
        }
        // Ende Defect 4887
    }

    // Beginn Defect 4887
    public bool CheckRAAuslagen()
    {
        // Alle Reiseauslagen werden gepr�ft, ob
        // diese an Tagen mit Produktiv- oder GK-Stunden durchgef�hrt werden 
        // innerhalb der Arbeitszeit stattfinden.
        // Fehlerhafte Eintr�ge werden im Fehlerlabel gemeldet, evtl. gemeinsam mit Hinweisen
        // auf falsche Zeitstempel.

        dbMontBer MBericht;
        DateTime date = ParamVal.Date0;
        int day = date.Day;
        bool bOnlyGoodData = true;
        bool bWrongEBID = false;

        MBericht = (dbMontBer)Session["MBericht"];

        if (MBericht.Reiseauslagen.Count == 0) return true;

        for (int indRA = 0; indRA <= MBericht.Reiseauslagen.Count - 1; indRA++)
        {
            DateTime dtRATag = Convert.ToDateTime(((dbRAAuslage)MBericht.Reiseauslagen[indRA]).Params.DATUM.Value);

            if (((dbRAAuslage)MBericht.Reiseauslagen[indRA]).Deleted)
            {
                continue;
            }

            dbArbTag tag = (dbArbTag)MBericht.Tage[dtRATag.Day - 1];

            foreach (dbArbZeit z in tag.Zeiten)
            {
                if (!z.Deleted) // Defect 5239, aus nachfolgendem if herausgehoben
                {
                    if (tag.Relevanz &&
                        z.Kommen != ParamVal.Date0 &&
                        z.Gehen != ParamVal.Date0 &&
                        z.ZeitTyp != dbArbZeit.ArbZeitType.stdAbsenz &&
                        z.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz)
                    {
                        //TAPM-39 Typ ist Produktiv, EB soll ebenfalls �berpr�ft werden
                        int azEBID = Convert.ToInt32((z.Params as dbAZ_ARBZEITParams).EBID.Value);
                        if (azEBID == 0)
                            azEBID = Convert.ToInt32(MBericht.Params.EBID.Value);
                        int raEBID = Convert.ToInt32(((dbRAAuslage)MBericht.Reiseauslagen[indRA]).Params.EBID.Value);
                        if (azEBID == raEBID)
                        {
                            // Defect 5239, bOnlyGoodData auf true setzen, sobald ein Tag mit Arbeitszeiten gefunden wurde
                            bOnlyGoodData = true;
                            bWrongEBID = false;
                            strLabError = "";
                            break;
                        }
                        else
                        {
                            bWrongEBID = true;
                            bOnlyGoodData = false;
                            strLabError = "Zu den am " + dtRATag.ToString("dd.MM.") +
                                          " erfassten Reiseauslagen wurde keine Arbeitszeit eingegeben! (falsches Einsatzbericht)";
                        }
                    }
                    else
                    {
                        bOnlyGoodData = false;
                        strLabError = "Zu den am " + dtRATag.ToString("dd.MM.") +
                                      " erfassten Reiseauslagen wurde keine Arbeitszeit eingegeben!";
                        //TAPM-39 additional Info
                        if (bWrongEBID)
                            strLabError += " (falsches Einsatzbericht)";
                    }
                }
            }

            // Ausstieg beim ersten fehlerhaften Satz
            if (bOnlyGoodData == false)
            {
                break;
            }
        }
        return bOnlyGoodData;
    }
    // Ende Defect 4887

    protected void Btn_CellCancel_Click(object sender, EventArgs e)
    {
        btnInsert.Visible = true;
        Btn_CellSave.Visible = false;
        Btn_CellCancel.Visible = false;
        btnInsert.Focus();
    }
}
