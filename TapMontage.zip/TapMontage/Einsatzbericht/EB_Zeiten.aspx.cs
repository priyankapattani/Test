//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : EB_Zeiten.aspx.cs
//
// Description  : Erfassen der Zeiten des Einsatzberichts
//
//--------------- V1.2.0011 ---------------------------------------------------
//
// Date         : 30.September 2011
// Author       : Joldic Dzevad
// Defect#      : BAN 500256
//                Alert ausgeben falls vorhanden
//
//--------------- V1.0.0034 ---------------------------------------------------
//
// Date         : 30.August 2007
// Author       : Adam Kiefer
// Defect#      : 5416
//                Anzeige Kopfdaten
//
//=============== V1.0.0029 ===================================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using TapMontage.Misc;

public partial class Einsatzbericht_EB_Zeiten : System.Web.UI.Page
{
    dbProjekt Projekt;
    dbBearbeiter Bearbeiter;
    dbBearbeiter Monteur;
    protected void Page_Load(object sender, EventArgs e)
    {
        // Beginn #5416 - Anzeige Kopfdaten
        /* Kopfdaten einstellen */
        try
        {
            if (Session["headData"] == null)
                Session.Add("headData", "");

            Session["headData"] = "<span style=\"font-size: 20px;\">Erfassen Einsatzberichte - Auswahl</span>";
        }
        catch
        {/* Nicht behandelt! */}
        // Ende #5416

        Projekt = (dbProjekt)Session["Projekt"];
        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        Monteur = (dbBearbeiter)Session["Monteur"];
        if (Projekt == null) Projekt = new dbProjekt(null);
        if (Monteur == null) Monteur = new dbBearbeiter(-1);

        Session["Projekt"] = Projekt;
        Session["Monteur"] = Monteur;
        //EB_Select1
        EB_Select1.EditButton_Clicked = BearbeitenLink_Clicked;
        EB_Select1.NewButton_Clicked = NewButton_Clicked;
        EB_Select1.ViewButton_Clicked = AnsehenLink_Clicked;
        EB_Select1.PrintButton_Clicked = DruckenLink_Clicked;

        if (Session["Alert"] != null)
        {
            Alert.Show((string[])Session["Alert"]);
            Session.Remove("Alert");
        }
    }

    private void BearbeitenLink_Clicked(object sender, CommandEventArgs Args)
    {
        Response.Redirect("~/Einsatzbericht/EditEB.aspx?RetUrl="+Request.RawUrl);
    }
    private void AnsehenLink_Clicked(object sender, CommandEventArgs Args)
    {
        Response.Redirect("~/Einsatzbericht/EditEB.aspx?Readonly=1&RetUrl="+Request.RawUrl);
    }

    private void NewButton_Clicked()
    {
        Response.Redirect("~/Einsatzbericht/EditEB.aspx?RetUrl="+Request.RawUrl);
    }

    private void DruckenLink_Clicked(object sender, CommandEventArgs Args)
    {
        Response.Redirect("~/Einsatzbericht/PrintEB.aspx?RetUrl=" + Request.RawUrl);
    }
}
