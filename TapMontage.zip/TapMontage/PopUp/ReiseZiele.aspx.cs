﻿//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : ReiseZiele.aspx.cs
//
// Description  : PopUp zum Auswahl eines Abfahrt- bzw. Ankunftsortes
//
//=============== 1.0.0050 ================================================
//
// Date         : 16.Oktober 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500059
//                Anbindung an die neue SAP HR Schnittstelle
//
//=========================================================================
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using TapMontage.dbObjects;

public partial class PopUp_ReiseZiele : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            /*
            if (Request.Params["selectedOrt"] != null)
            {
                txtPLZOrt.Text = Request.Params["selectedOrt"].ToString();
            }
            else
            {
                txtPLZOrt.Text = "";
            }*/
            txtPLZOrt.Text = "???";
        }
    }
    protected void ListBoxReiseZiele_SelectedIndexChanged(object sender, EventArgs e)
    {
        List<string> l = new List<string>();
        string fields = Request.QueryString["backf"];

        while (fields.Contains("@"))
        {
            fields = fields.Substring(fields.IndexOf("@") + 1);
            if (fields.Contains("@"))
            {
                string field = fields.Substring(0, fields.IndexOf('@'));
                l.Add(field);
            }
            else
            {
                l.Add(fields);
            }
        }

        LiteralControl tmp = new LiteralControl();
        tmp.Text = "<script type=\"text/javascript\">";

        foreach (string s in l)
        {
            if( ListBoxReiseZiele.Text.Length > 20 )
                tmp.Text += "if(typeof window.opener." + s + " != 'undefined') {window.opener." + s + ".value = '" + ListBoxReiseZiele.Text.Substring(0,20) + "';} ";
            else
                tmp.Text += "if(typeof window.opener." + s + " != 'undefined') {window.opener." + s + ".value = '" + ListBoxReiseZiele.Text + "';} ";
        }
        tmp.Text += "window.close();";
        tmp.Text += "</Script>";
        PlaceHolder1.Controls.Add(tmp);

    }
    protected void txtPLZOrt_TextChanged(object sender, EventArgs e)
    {
        ListBoxReiseZiele.Items.Clear();

        dbBearbeiter bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        foreach (ValuePair pair in bearbeiter.Commons.AlleOrtschaften)
        {
            string filter = txtPLZOrt.Text.Trim('*', '?');
            if (pair.Value.ToUpper().Contains(filter.ToUpper()))
                ListBoxReiseZiele.Items.Add(pair.Text);
        }
    }
}
