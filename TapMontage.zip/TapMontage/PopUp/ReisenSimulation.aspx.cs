﻿//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : ReisenSimulation.aspx.cs
//
// Description  : Reisenkostennachweis und Deckblatt in pdf Format anzeigen
//
//=============== 1.0.0050 ================================================
//
// Date         : 16.Oktober 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500059
//                Anbindung an die neue SAP HR Schnittstelle
//
//=========================================================================
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Tap.Schnittstellen.TAP_RA;
using System.IO;

public partial class PopUp_ReisenSimulation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int perskey = 0;
        string mandant = "";
        string raid = "";
        bool barcode = false;
        if (Request.Params["perskey"] != null)
        {
            try
            {
                perskey = Convert.ToInt32(Request.Params["perskey"]);
            }
            catch
            {
            }
        }
        if (Request.Params["mandant"] != null)
        {
            mandant = Request.Params["mandant"].ToString();
        }
        if (Request.Params["raid"] != null)
        {
            raid = Request.Params["raid"].ToString();
        }

        if (Request.Params["barcode"] != null)
        {
            try
            {
                barcode = Convert.ToBoolean(Request.Params["barcode"]);
            }
            catch
            {
            }
        }
        
        if (perskey > 0 && mandant.Length > 0 && raid.Length > 0)
        {
            string filepath = "";
            RFCReise rfc = new RFCReise();
            RueckgabeAnClient rueck = new RueckgabeAnClient();

            if( barcode )
                rueck = rfc.GetBarCode(perskey, mandant, raid, out filepath);
            else
                rueck = rfc.GetSimulation(perskey, mandant, raid, out filepath);

            //filepath = @"D:\TAP\_PDF\SIMULATION\SIM.170022686.pdf";
            if (filepath.Length > 0)
            {
                Response.ContentType = "Application/pdf";
                //Response.WriteFile(filepath);
                //Response.WriteFile("D:\\TAP\\_PDF\\BARCODE\\RA.170120098.pdf");
                //Response.BinaryWrite("D:\\TAP\\_PDF\\BARCODE\\RA.170120098.pdf");
                //SetFocus(this);

                string[] filename = filepath.Split('\\');
                Response.AddHeader("content-disposition", "attachment; filename=" + filename[filename.Length-1]);
                FileStream sourceFile = new FileStream(filepath, FileMode.Open);
                long FileSize;
                FileSize = sourceFile.Length;
                byte[] getContent = new byte[(int)FileSize];
                sourceFile.Read(getContent, 0, (int)sourceFile.Length);
                sourceFile.Close();

                Response.BinaryWrite(getContent);
                //Response.End();
             }
            else
                Response.Write(rueck.SapReturn.Length > 0 ? rueck.SapReturn : rueck.TapReturn);
        }
        else
            Response.Write("Anfrage unvollständig");
    }
}
