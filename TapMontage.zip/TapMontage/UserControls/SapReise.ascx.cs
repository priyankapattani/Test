﻿//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : SapReise.aspx.cs
//
// Description  : User Control für einzelen TAP Reisen
//
//=============== V1.2.0009 ===============================================
//
// Date         : 24.Jänner 2011
// Author       : Joldic Dzevad
// Defect#      : BAF xxxxxx
//                Kostenstelle fehlt bei Auftragsnummernauswahl
//                
//=============== V1.2.0006 ===============================================
//
// Date         : 16.August 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530042
//                Text Angepasst
//                
//=============== V1.2.0000 ===============================================
//
// Date         : 25.Februar 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530031 
//                Datum ändern bei gewisse Reisenauslagen in neue RA Übersicht
//               (bei Bedarf über Web.Config aktivierbar)
//
//=============== V1.1.0000 ===============================================
//
// Date         : 08.Januar 2010
// Author       : Joldic Dzevad
// Defect#      : BAN 500059 
//                RfcSapHR Schnittstelle TAP Montage
//
//=============================================================================
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using System.Data.SqlClient;
using System.Collections.Generic;
using TapMontage.Misc;
using Tap.Schnittstellen.TAP_RA;
using System.IO;

public partial class UserControlSapReise : System.Web.UI.UserControl
{
    private dbBearbeiter Bearbeiter;
    private dbKG_Monat KGMonat;
    private bool istAenderbar = false;
    private short rastat = 0;
    private Dictionary<int, Table> raid_TableRAZeile = new Dictionary<int, Table>();
    Dictionary<string, TableRow> id_rowReiseZeile = new Dictionary<string, TableRow>();
    Dictionary<string, TableRow> id_rowBeleg = new Dictionary<string, TableRow>();
    //private bool bleibtOffen = false;
    public bool istErsteReiseImMonat = false;
    public bool istLetzteReiseImMonat = false;
    public int TapNummer
    {
        set
        {
            this.labelTapNummer.Text = value.ToString();
        }
        get
        {
            return Convert.ToInt32(this.labelTapNummer.Text);
        }
    }
    public bool ErrorTextColorRed
    {
        set
        {
            if (value)
                this.lblSendTrip.ForeColor = System.Drawing.Color.Red;
            else
                this.lblSendTrip.ForeColor = System.Drawing.Color.Green;
        }
    }

    public string ErrorText
    {
        set
        {
            this.lblSendTrip.Text = value;
        }
        get
        {
            return this.lblSendTrip.Text;
        }
    }

    public string SapNummer
    {
        set
        {
            this.labelSapNummer.Text = value;
        }
        get
        {
            return this.labelSapNummer.Text;
        }
    }

    public short RASTAT
    {
        set
        {
            this.rastat = value;
        }
        get
        {
            return this.rastat;
        }
    }
    /*
    public bool btnBarcodeEnabled
    {
        set
        {
            //this.btnBarcode.Enabled = value;
            this.btnBarcode.Visible = value;
        }
    }*/

    public bool btnSimEnabled
    {
        set
        {
            this.btnSimulation.Enabled = value;
        }
    }

    public bool btnSendTripEnabled
    {
        set
        {
            this.btnSendTripToSAP.Enabled = value;
        }
    }

    public int TableId = 0;
    public bool IstAenderbar
    {
        set
        {
            this.istAenderbar = value;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        KGMonat = (dbKG_Monat)Session["KGMonat"];

        dbSapReise r = new dbSapReise();
        string s = "";
        r.SapReise(Convert.ToInt32(labelTapNummer.Text), ref s);
        labelSapNummer.Text = s.PadLeft(10, '0');
        BuildTables();
        panelEdit.Visible = istAenderbar;
        panelZeile.Visible = false;
        panelBeleg.Visible = false;
        LabelError.Text = "";
        LabelError2.Text = "";
        Literal l = new Literal();
        //l.Text = "<a Onclick=\"window.open('../PopUp/ReiseZiele.aspx?backf=@form1.ctl" + string.Format("{0:00}", TableId) + "$txtAbOrt&selectedOrt=" + txtAbOrt.Text + "', 'Popup', 'width=240,height=280,left=' + (window.screenLeft+window.event.clientX-240) + ', top=' + (window.screenTop+window.event.clientY));\"><img valign=\"bottom\" src=\"../images/dreieck.gif\"/></a>";
        l.Text = "<a Onclick=\"window.open('../PopUp/ReiseZiele.aspx?backf=@form1.ctl" + string.Format("{0:00}", TableId) + "$txtAbOrt', 'Popup', 'width=240,height=280,left=' + (window.screenLeft+window.event.clientX-240) + ', top=' + (window.screenTop+window.event.clientY));\"><img valign=\"bottom\" src=\"../images/dreieck.gif\"/></a>";
        phAbOrt.Controls.Clear();
        phAbOrt.Controls.Add(l);
        l = new Literal();
        //l.Text = "<a Onclick=\"window.open('../PopUp/ReiseZiele.aspx?backf=@form1.ctl" + string.Format("{0:00}", TableId) + "$txtAnOrt&selectedOrt=" + txtAnOrt.Text + "', 'Popup', 'width=240,height=280,left=' + (window.screenLeft+window.event.clientX-240) + ', top=' + (window.screenTop+window.event.clientY));\"><img valign=\"bottom\" src=\"../images/dreieck.gif\"/></a>";
        l.Text = "<a Onclick=\"window.open('../PopUp/ReiseZiele.aspx?backf=@form1.ctl" + string.Format("{0:00}", TableId) + "$txtAnOrt', 'Popup', 'width=240,height=280,left=' + (window.screenLeft+window.event.clientX-240) + ', top=' + (window.screenTop+window.event.clientY));\"><img valign=\"bottom\" src=\"../images/dreieck.gif\"/></a>";
        phAnOrt.Controls.Clear();
        phAnOrt.Controls.Add(l);

        //l = new Literal();
        //l.Text = "<a Onclick=\"window.open('../PopUp/ReisenSimulation.aspx?raid=" + labelTapNummer.Text + "'/></a>";
        //l.Text = "<a Onclick=\"window.open('../PopUp/ReisenSimulation.aspx'</a>";
        //btnSimulation.Controls.Add(l);

        //btnSimulation.Attributes.Add("onClick", "return PrepareDownload()");
        //btnSimulation.Attributes.Add("onClick", "window.open('../PopUp/ReisenSimulation.aspx?raid="+labelTapNummer.Text+"&perskey="+KGMonat.Monteur.Params.PERSKEY.Value.ToString() + "&mandant="+KGMonat.Monteur.Params.MANDANT.Value.ToString()+"')");
        //btnBarcode.Attributes.Add("onClick", "window.open('../PopUp/ReisenSimulation.aspx?raid=" + labelTapNummer.Text + "&perskey=" + KGMonat.Monteur.Params.PERSKEY.Value.ToString() + "&mandant=" + KGMonat.Monteur.Params.MANDANT.Value.ToString() + "&barcode=true')");

        TWTBStartDatum.InputNames = "@form1.ctl" + string.Format("{0:00}", TableId) + "$TWTBStartDatum$txtTextBox";
        TWTBEndeDatum.InputNames = "@form1.ctl" + string.Format("{0:00}", TableId) + "$TWTBEndeDatum$txtTextBox";
        btnSendTripToSAP.Attributes.Add("RAID", labelTapNummer.Text);
        //btnSendTripToSAP.Text = "Sende " + labelTapNummer.Text + " nach SAP";
        if (Page.IsPostBack)
            lblSendTrip.Text = "";
        btnBarcode.Visible = !istAenderbar;
    }

    public void BuildTables()
    {
        this.TableRAZeilen.Width = Unit.Percentage(97);
        this.TableBelege.Width = Unit.Percentage(97);
        this.TableBelege.Rows.Clear();
        this.TableRAZeilen.Rows.Clear();
        this.id_rowBeleg.Clear();
        this.id_rowReiseZeile.Clear();
        TableRow rh = new TableRow();
        string xss = "TabHeader";
        rh = AddNewCell(rh, "RAID", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "LFDNR", xss, HorizontalAlign.Center);

        rh = AddNewCell(rh, "Von", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Bis", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Ereignis", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Auftrag-Nr.", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Zielort", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Reisentätigkeit", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Verkehrsmittel", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Bereitst.", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "km", xss, HorizontalAlign.Center, "gefahrene Km");
        rh = AddNewCell(rh, "MF", xss, HorizontalAlign.Center, "Anzahl Mitfahrer");
        rh = AddNewCell(rh, "SG", xss, HorizontalAlign.Center, "Schwergepäck");
        if (istAenderbar)
        {
            rh = AddNewCell(rh, "Edit", xss, HorizontalAlign.Center, "Zeile bearbeiten");
            rh = AddNewCell(rh, "Del", xss, HorizontalAlign.Center, "Zeile umegehen löschen");
        }
        rh.Cells[rh.Cells.Count - 1].ColumnSpan = 2;
        this.TableRAZeilen.Rows.Add(rh);
        id_rowReiseZeile.Add(rh.Cells[0].Text + "-" + rh.Cells[1].Text, rh);

        rh = new TableRow();
        rh = AddNewCell(rh, "RAID", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "LFDNR", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Datum", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Auftrag-Nr.", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Art", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Anzahl", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Betrag", xss, HorizontalAlign.Center);
        if (istAenderbar)
        {
            rh = AddNewCell(rh, "Edit", xss, HorizontalAlign.Center, "Zeile bearbeiten");
        }
        this.TableBelege.Rows.Add(rh);
        id_rowBeleg.Add(rh.Cells[0].Text + "-" + rh.Cells[1].Text, rh);


        this.ReiseVon.Text = "";



        xss = "TabNewDay";
        ArrayList razeilen = LeseAlleRAZeilen(Convert.ToInt32(labelTapNummer.Text));
        foreach (dbRaZeile_Params r in razeilen)
        {
            bool rr = false; //bei Rückreise, keine Reisentätigkeit schreiben
            rh = new TableRow();
            rh = AddNewCell(rh, r.RAID.Value.ToString(), xss, HorizontalAlign.NotSet);
            rh = AddNewCell(rh, r.LFDNR.Value.ToString(), xss, HorizontalAlign.NotSet);
            if (r.ZEILENKZ.Value == DBNull.Value)
            {
                rh = AddNewCell(rh, Convert.ToDateTime(r.DAT.Value).ToShortDateString(), xss, HorizontalAlign.NotSet);
                rh = AddNewCell(rh, r.BESCHREIB.Value.ToString(), xss, HorizontalAlign.NotSet);
                rh = AddNewCell(rh, AuslageArt(r.AUSLART.Value.ToString()), xss, HorizontalAlign.NotSet);
                rh = AddNewCell(rh, r.ANZNAECHTE.Value.ToString(), xss, HorizontalAlign.NotSet);
                rh = AddNewCell(rh, r.BETRAG.Value.ToString(), xss, HorizontalAlign.NotSet);
                if (istAenderbar)
                {
                    TableCell c = new TableCell();
                    c.Controls.Add(NewTaskButton("bearbeiten", "EditBeleg", rh.Cells[0].Text + "-" + rh.Cells[1].Text, "Klicken Sie hier um diese Reise zu bearbeiten.", TaskButton_Click, "~/Images/Bearbeiten_16x16.jpg"));
                    c.CssClass = xss;
                    rh.Cells.Add(c);
                }
                TableBelege.Rows.Add(rh);
                id_rowBeleg.Add(rh.Cells[0].Text + "-" + rh.Cells[1].Text, rh);
            }
            else
            {
                if (ReiseVon.Text == "")
                    this.ReiseVon.Text = VonBis(Convert.ToDateTime(r.AB.Value));
                this.ReiseBis.Text = VonBis(Convert.ToDateTime(r.AN.Value));
                rh = AddNewCell(rh, VonBis(Convert.ToDateTime(r.AB.Value)), xss, HorizontalAlign.NotSet);
                rh = AddNewCell(rh, VonBis(Convert.ToDateTime(r.AN.Value)), xss, HorizontalAlign.NotSet);
                switch (r.ZEILENKZ.Value.ToString())
                {
                    case "H":
                        rh = AddNewCell(rh, "Hinreise", xss, HorizontalAlign.NotSet);
                        break;
                    case "R":
                        rh = AddNewCell(rh, "Rückreise", xss, HorizontalAlign.NotSet);
                        rr = true;
                        break;
                    case "T":
                        rh = AddNewCell(rh, "Teilabrechnung", xss, HorizontalAlign.NotSet);
                        break;
                    case "S":
                        rh = AddNewCell(rh, "Standortwechsel", xss, HorizontalAlign.NotSet);
                        break;
                    case "W":
                        // BAF 530042 Text angepasst
                        rh = AddNewCell(rh, "Wechsel Reiseart/Bereitstellung/Kontierung", xss, HorizontalAlign.NotSet);
                        break;
                    default:
                        rh = AddNewCell(rh, r.ZEILENKZ.Value.ToString(), xss, HorizontalAlign.NotSet);
                        break;
                }
                rh = AddNewCell(rh, r.BESCHREIB.Value.ToString(), xss, HorizontalAlign.NotSet);
                rh = AddNewCell(rh, r.ANORT.Value.ToString(), xss, HorizontalAlign.NotSet);
                if (rr)
                    rh = AddNewCell(rh, "", xss, HorizontalAlign.NotSet);
                else
                    rh = AddNewCell(rh, ReiseTaetigkeit(r.REISEART.Value.ToString()), xss, HorizontalAlign.NotSet);
                rh = AddNewCell(rh, Verkersmittel(r.VERKEHRSMITTEL.Value.ToString()), xss, HorizontalAlign.NotSet);
                //if (rr)
                //   rh = AddNewCell(rh, "", xss, HorizontalAlign.NotSet);
                //else
                if (r.BEREITST.Value == DBNull.Value || r.BEREITST.Value.ToString() == "") r.BEREITST.Value = "0";
                rh = AddNewCell(rh, Bereitstellungsarten(r.BEREITST.Value.ToString()), xss, HorizontalAlign.NotSet);
                rh = AddNewCell(rh, r.GEFKM.Value.ToString(), xss, HorizontalAlign.NotSet);
                rh = AddNewCell(rh, r.MITFAHRER.Value.ToString(), xss, HorizontalAlign.NotSet);
                rh = AddNewCell(rh, r.SCHWERGP.Value.ToString() == "S" ? "ja" : "nein", xss, HorizontalAlign.NotSet);

                if (istAenderbar)
                {
                    TableCell c = new TableCell();
                    c.Controls.Add(NewTaskButton("bearbeiten", "EditRZ", rh.Cells[0].Text + "-" + rh.Cells[1].Text, "Klicken Sie hier um diese Reise zu bearbeiten.", TaskButton_Click, "~/Images/Bearbeiten_16x16.jpg"));
                    c.CssClass = xss;
                    rh.Cells.Add(c);
                    c = new TableCell();
                    LinkButton lnkbtn = NewTaskButton("bearbeiten", "DeleteRZ", rh.Cells[0].Text + "-" + rh.Cells[1].Text, "Klicken Sie hier um diese Reise zu bearbeiten.", TaskButton_Click, "~/Images/trash16x16.jpg");
                    lnkbtn.Attributes.Add("onclick", "javascript:return confirm('Achtung! Reisezeile von " + VonBis(Convert.ToDateTime(r.AB.Value)) + " bis " + VonBis(Convert.ToDateTime(r.AN.Value)) + " wird unwiderruflich gelöscht !!!')");
                    c.Controls.Add(lnkbtn);
                    c.CssClass = xss;
                    rh.Cells.Add(c);
                }
                this.TableRAZeilen.Rows.Add(rh);
                id_rowReiseZeile.Add(rh.Cells[0].Text + "-" + rh.Cells[1].Text, rh);
            }
        }
        if (TableBelege.Rows.Count == 1) //nur header
        {
            TableBelege.Visible = false;
            lblNoReceipts.Visible = true;
        }
        Session["id_rowReiseZeile"] = id_rowReiseZeile;
    }

    private LinkButton NewTaskButton(string Text, string Command, string Argument, string ToolTip, CommandEventHandler TaskButtonClick_EventHandler, string url)
    {
        LinkButton btn = new LinkButton();
        btn.ID = nid();
        btn.SkinID = "";
        btn.Width = Unit.Percentage(100);
        btn.Text = Text;
        if (url != "")
        {
            Image i = new Image();
            i.ImageUrl = url;
            btn.Controls.Add(i);
        }
        btn.CommandName = Command;
        btn.CommandArgument = Argument;
        btn.ToolTip = ToolTip;
        btn.CausesValidation = false;
        //btn.Enabled = (KGReiseZeile == null);
        btn.Command += new CommandEventHandler(TaskButtonClick_EventHandler);
        return btn;
    }

    public int xxID = 0;
    public string nid()
    {
        xxID++;
        return "LnkBTN->" + xxID.ToString();
    }

    void TaskButton_Click(object sender, CommandEventArgs e)
    {
        //string scrollPosition = "edit";
        string cmd = (string)e.CommandName;
        //int arg = Convert.ToInt16((string)e.CommandArgument);
        //DateTime dt = Convert.ToDateTime(arg);
        UserControlSapReise myCtrl = null;
        foreach (UserControlSapReise ctrl in (ArrayList)Session["MyCtrls"])
        {
            if (ctrl.TapNummer.ToString() == e.CommandArgument.ToString().Substring(0, e.CommandArgument.ToString().IndexOf('-')))
            {
                myCtrl = ctrl;
                break;
            }
        }
        if (myCtrl == null) return;
        TableRow row = null;

        switch (cmd)
        {
            case "EditRZ":
                try
                {
                    row = ((Dictionary<string, TableRow>)(myCtrl.id_rowReiseZeile))[e.CommandArgument.ToString()];
                }
                catch
                {
                    //keine Ahnung
                }
                if (row != null)
                    MapData(myCtrl, row);
                break;
            case "EditBeleg":
                try
                {
                    row = ((Dictionary<string, TableRow>)(myCtrl.id_rowBeleg))[e.CommandArgument.ToString()];
                }
                catch
                {
                    //keine Ahnung
                }
                if (row != null)
                    MapData2(myCtrl, row);
                break;

            case "DeleteRZ":
                try
                {
                    row = ((Dictionary<string, TableRow>)(myCtrl.id_rowReiseZeile))[e.CommandArgument.ToString()];
                }
                catch
                {
                    //keine Ahnung
                }
                if (row != null)
                {
                    dbRaZeile_Params rrr = ReadRZfromDB(row);
                    if (DeleteReiseZeile(row))
                    {
                        //row.Visible = false;
                        //myCtrl.TableRAZeilen.Rows.Remove(row);
                        Session["BuildTablesNew"] = myCtrl;
                        Session["SetFocus"] = myCtrl.txtFocus2;
                    }
                }
                break;
            default:
                Exception ex = new Exception("Command not recognized: " + cmd);
                throw ex;
        }
        //phRabTab.Controls.Clear();
        //phRabTab.Controls.Add(RabTab());
        //if (scrollPosition == "edit")
        //    SetFocus(BtnSave);
        //else
        //    SetFocus(scrollPosition);
        // Ende #4040, 4370
    }

    private void MapData2(UserControlSapReise ctrl, TableRow row)
    {
        dbRaZeile_Params rrr = ReadRZfromDB(row);
        if (rrr == null) return;
        Session["ReiseZeile"] = rrr;
        ctrl.panelZeile.Visible = false;
        ctrl.panelBeleg.Visible = true;
        ctrl.LabelError.Visible = false;

        ctrl.txtDatum.Text = Convert.ToDateTime(rrr.DAT.Value).ToShortDateString();
        ctrl.ddlRAAuslagen.Items.Clear();
        foreach (ValuePair vp in Bearbeiter.Commons.Auslagenarten)
        {
            ctrl.ddlRAAuslagen.Items.Add(new ListItem(vp.Text, vp.Value));
        }
        ctrl.ddlRAAuslagen.SelectedValue = (rrr.AUSLART.Value != DBNull.Value && rrr.AUSLART.Value.ToString() != "") ? rrr.AUSLART.Value.ToString() : "SONS";
        //Beginn V1.1.0001
        if (ConfigurationManager.AppSettings["EditReciptAllowed"] != null &&
            ConfigurationManager.AppSettings["EditReciptAllowed"].ToString().Contains(ctrl.ddlRAAuslagen.SelectedValue))
        {
            ctrl.txtDatum.Enabled = true;
        }
        else
        {
            ctrl.txtDatum.Enabled = false;
        }
        //Ende V1.1.0001
        ctrl.txtAnzahl.Text = (rrr.ANZNAECHTE.Value != DBNull.Value) ? rrr.ANZNAECHTE.Value.ToString() : "";
        ctrl.txtBetrag.Text = (rrr.BETRAG.Value != DBNull.Value) ? rrr.BETRAG.Value.ToString() : "0";
        ctrl.ddlProjekt2.Items.Clear();
        KGMonat.Rabrech.Auftraege.Clear();
        foreach (dbMontBer monber in KGMonat.Monteur.MBerichte)
        {
            ctrl.ddlProjekt2.Items.Add(new ListItem(monber.Projekt.Params.NAME.Value.ToString(), monber.Params.EBID.Value.ToString()));
            KGMonat.Rabrech.AddAuftrag(monber.Projekt.Params.KTOBJ.Value.ToString(), DateTime.Now);
        }
        if (rrr.EBID.Value != DBNull.Value && Convert.ToInt32(rrr.EBID.Value) != 0)
        {
            ctrl.ddlProjekt2.SelectedValue = rrr.EBID.Value.ToString();
            ctrl.ddlProjekt2.Visible = false;
            ctrl.Label16.Visible = false;
        }
        ctrl.ddlAuftrag2.Items.Clear();
        ctrl.ddlAuftrag2 = KGMonat.Rabrech.ddlAufträge(ctrl.ddlAuftrag2, rrr.BESCHREIB.Value.ToString());
        //BAF XXXXXX Kostestelle fehlt
        string kostenstelle = "10" + KGMonat.Monteur.TechParams.KST.Value.ToString();
        if (!ctrl.ddlAuftrag2.Items.Contains(new ListItem(kostenstelle, kostenstelle)))
            ctrl.ddlAuftrag2.Items.Add(new ListItem(kostenstelle + " (Kostenstelle)", kostenstelle));
        else
            ctrl.ddlAuftrag2.Items.FindByText(kostenstelle).Text += " (Kostenstelle)";
        //BAF XXXXX Ende
        ctrl.btnSendTripToSAP.Enabled = false;
        ctrl.txtBemerkung.Text = rrr.AUSLBEMERK.Value != DBNull.Value ? rrr.AUSLBEMERK.Value.ToString() : "";
        Session["SetFocus"] = ctrl.txtFocus2;
    }

    private bool DeleteReiseZeile(TableRow row)
    {
        bool ret = false;
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                using (SqlCommand cmd = new SqlCommand("DELETE FROM RAZEILE WHERE RAID=@RAID and LFDNR=@LFDNR", cnx))
                {
                    cmd.Parameters.Add(new SqlParameter("@RAID", row.Cells[0].Text));
                    cmd.Parameters.Add(new SqlParameter("@LFDNR", row.Cells[1].Text));
                    ret = cmd.ExecuteNonQuery() > 0 ? true : false;
                    cmd.Parameters.Clear();
                }
            }
            catch
            {
            }
            finally
            {
                cnx.Close();
            }
        }
        return ret;
    }

    private void MapData(UserControlSapReise ctrl, TableRow row)
    {
        dbRaZeile_Params rrr = ReadRZfromDB(row);
        if (rrr == null) return;
        Session["ReiseZeile"] = rrr;
        ctrl.panelZeile.Visible = true;
        ctrl.panelBeleg.Visible = false;
        ctrl.LabelError.Visible = false;

        ctrl.rbtnEreignis.SelectedValue = rrr.ZEILENKZ.Value.ToString();
        ctrl.rbtnEreignis.Items[0].Enabled = false;
        ctrl.rbtnEreignis.Items[1].Enabled = false;
        ctrl.rbtnEreignis.Items[2].Enabled = false;
        ctrl.rbtnEreignis.Items[3].Enabled = false;
        ctrl.rbtnEreignis.Items[4].Enabled = false;

        if ("HT".Contains(ctrl.rbtnEreignis.SelectedValue))
        {
            ctrl.rbtnEreignis.Items[0].Enabled = true;
            if (ctrl.istErsteReiseImMonat)
                ctrl.rbtnEreignis.Items[3].Enabled = true;
        }
        if ("RT".Contains(ctrl.rbtnEreignis.SelectedValue))
        {
            ctrl.rbtnEreignis.Items[1].Enabled = true;
            if (ctrl.istLetzteReiseImMonat)
                ctrl.rbtnEreignis.Items[3].Enabled = true;
        }
        if ("SW".Contains(ctrl.rbtnEreignis.SelectedValue))
        {
            ctrl.rbtnEreignis.Items[2].Enabled = true;
            ctrl.rbtnEreignis.Items[4].Enabled = true;
        }
        if (ctrl.rbtnEreignis.SelectedValue == "T")
        {
            ctrl.TWTBStartDatum.Visible = false;
            ctrl.TWTBEndeDatum.Visible = false;
            ctrl.ZeitVon.Visible = false;
            ctrl.ZeitBis.Visible = false;
            ctrl.Label18.Visible = false;
            ctrl.Label19.Visible = false;
            if (Convert.ToDateTime(rrr.DAT.Value).Month == Convert.ToDateTime(rrr.DAT.Value).AddDays(1).Month)
            {
                //es ist eine TA am anfang des monats - Rückreise nicht auswählbar
                ctrl.rbtnEreignis.Items[1].Enabled = false;
            }
            else
            {
                //es ist eine Teilabrechnung am Ende des Monats - Hinreise nicht auswählbar
                ctrl.rbtnEreignis.Items[0].Enabled = false;
            }
        }
        ctrl.TWTBStartDatum.TB.Text = Convert.ToDateTime(rrr.AB.Value).ToShortDateString();
        ctrl.TWTBStartDatum.SelectedDate = ctrl.TWTBStartDatum.TB.Text;
        ctrl.TWTBEndeDatum.TB.Text = Convert.ToDateTime(rrr.AN.Value).ToShortDateString();
        ctrl.TWTBEndeDatum.SelectedDate = ctrl.TWTBStartDatum.TB.Text;
        ctrl.ZeitVon.Text = Convert.ToDateTime(rrr.AB.Value).ToShortTimeString();
        ctrl.ZeitBis.Text = Convert.ToDateTime(rrr.AN.Value).ToShortTimeString();
        ctrl.txtAbOrt.Text = (rrr.ABORT.Value != DBNull.Value) ? rrr.ABORT.Value.ToString() : "";
        ctrl.txtAnOrt.Text = (rrr.ANORT.Value != DBNull.Value) ? rrr.ANORT.Value.ToString() : "";
        ctrl.ddlFahrzeugart.Items.Clear();
        ctrl.ddlFahrzeugart.Items.Add(new ListItem("", ""));
        foreach (ValuePair vp in Bearbeiter.Commons.Verkehrsmittel)
        {
            ctrl.ddlFahrzeugart.Items.Add(new ListItem(vp.Text + " [ " + vp.Value + " ]", vp.Value));
        }
        ctrl.ddlFahrzeugart.SelectedValue = (rrr.VERKEHRSMITTEL.Value != DBNull.Value && rrr.VERKEHRSMITTEL.Value.ToString() != "") ? rrr.VERKEHRSMITTEL.Value.ToString() : "";
        ctrl.ddlTaetigkeit.Items.Clear();
        foreach (ValuePair vp in Bearbeiter.Commons.ReisenTaetigkeiten)
        {
            ctrl.ddlTaetigkeit.Items.Add(new ListItem(vp.Text, vp.Value));
        }
        ctrl.ddlTaetigkeit.SelectedValue = (rrr.REISEART.Value != DBNull.Value) ? rrr.REISEART.Value.ToString() : "";
        ctrl.ddlBereitstellung.Items.Clear();
        foreach (ValuePair vp in Bearbeiter.Commons.Bereitstellungsarten)
        {
            ctrl.ddlBereitstellung.Items.Add(new ListItem(vp.Text, vp.Value));
        }
        ctrl.ddlBereitstellung.SelectedValue = (rrr.BEREITST.Value != DBNull.Value && rrr.BEREITST.Value.ToString() != "") ? rrr.BEREITST.Value.ToString() : "0";

        ctrl.txtGefKM.Text = (rrr.GEFKM.Value != DBNull.Value) ? rrr.GEFKM.Value.ToString() : "";
        ctrl.cbSG.Checked = (rrr.SCHWERGP.Value != DBNull.Value && rrr.SCHWERGP.Value.ToString() == "S") ? true : false;
        //ctrl.txtMitfahrer.Text = (rrr.MITFAHRER.Value != DBNull.Value) ? rrr.MITFAHRER.Value.ToString() : "";
        try
        {
            ctrl.ddlMitfahrer.SelectedValue = (rrr.MITFAHRER.Value != DBNull.Value && rrr.MITFAHRER.Value.ToString() != "") ? rrr.MITFAHRER.Value.ToString() : "0";
        }
        catch
        {
            ctrl.ddlMitfahrer.SelectedValue = "0";
        }
        KGMonat.Rabrech.Auftraege.Clear();
        ctrl.ddlProjekt.Items.Clear();
        foreach (dbMontBer monber in KGMonat.Monteur.MBerichte)
        {
            ctrl.ddlProjekt.Items.Add(new ListItem(monber.Projekt.Params.NAME.Value.ToString(), monber.Params.EBID.Value.ToString()));
            KGMonat.Rabrech.AddAuftrag(monber.Projekt.Params.KTOBJ.Value.ToString(), DateTime.Now);
        }
        ctrl.ddlProjekt.SelectedValue = (rrr.EBID.Value != DBNull.Value) ? rrr.EBID.Value.ToString() : "";
        ctrl.ddlAuftrag.Items.Clear();
        ctrl.ddlAuftrag = KGMonat.Rabrech.ddlAufträge(ctrl.ddlAuftrag, rrr.BESCHREIB.Value.ToString());
        //BAF XXXXXX Kostestelle fehlt
        string kostenstelle = "10" + KGMonat.Monteur.TechParams.KST.Value.ToString();
        if (!ctrl.ddlAuftrag.Items.Contains(new ListItem(kostenstelle, kostenstelle)))
            ctrl.ddlAuftrag.Items.Add(new ListItem(kostenstelle + " (Kostenstelle)", kostenstelle));
        else
            ctrl.ddlAuftrag.Items.FindByText(kostenstelle).Text += " (Kostenstelle)";
        //BAF XXXXX Ende
        ctrl.btnSendTripToSAP.Enabled = false;
        Session["SetFocus"] = ctrl.btnSave;
    }

    private dbRaZeile_Params ReadRZfromDB(TableRow row)
    {
        dbRaZeile_Params ret = null;
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM RAZEILE " + Config.Nolock +
                    "WHERE RAID = @RAID AND LFDNR =@LFDNR", cnx))
                {
                    cmd.Parameters.Add(new SqlParameter("@RAID", row.Cells[0].Text));
                    cmd.Parameters.Add(new SqlParameter("@LFDNR", row.Cells[1].Text));
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        cmd.Parameters.Clear();
                        while (rd.Read())
                        {
                            ret = new dbRaZeile_Params();
                            for (int i = 0; i < rd.FieldCount; i++)
                            {
                                bool match = false;
                                foreach (SqlParameter s in ret.List)
                                    if (s.ParameterName.Substring(1).ToUpper() == rd.GetName(i).ToUpper())
                                    {
                                        if (!rd.IsDBNull(i))
                                            s.Value = rd.GetValue(i);
                                        else
                                            s.Value = DBNull.Value;
                                        match = true;
                                        break;
                                    }
                                if (!match)
                                {
                                    //
                                }
                            }
                        }
                        rd.Close();
                    }
                }
            }
            catch
            {
                ret = null;
            }
            finally
            {
                cnx.Close();
            }
        }
        return ret;
    }

    private string ReiseTaetigkeit(string p)
    {
        foreach (ValuePair vp in Bearbeiter.Commons.ReisenTaetigkeiten)
        {
            if (vp.Value == p)
                return vp.Text;
        }
        return "";
    }

    private string AuslageArt(string p)
    {
        foreach (ValuePair vp in Bearbeiter.Commons.Auslagenarten)
        {
            if (vp.Value == p)
                return vp.Text;
        }
        return "";
    }

    private string Bereitstellungsarten(string p)
    {
        foreach (ValuePair vp in Bearbeiter.Commons.Bereitstellungsarten)
        {
            if (vp.Value == p)
                return vp.Text;
        }
        return "";
    }

    private string Verkersmittel(string p)
    {
        foreach (ValuePair vp in Bearbeiter.Commons.Verkehrsmittel)
        {
            if (vp.Value == p)
                return vp.Text;
        }
        return "";
    }

    private string VonBis(DateTime d)
    {
        return d.ToShortDateString() + " " + d.ToShortTimeString();
    }

    public ArrayList LeseAlleRAZeilen(int raid)
    {
        ArrayList ret = new ArrayList();
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM RAZEILE " + Config.Nolock +
                    "WHERE RAID = @RAID ORDER BY DAT ASC, AB ASC, AN ASC", cnx))
                {
                    cmd.Parameters.Add(new SqlParameter("@RAID", raid));
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        cmd.Parameters.Clear();
                        while (rd.Read())
                        {
                            dbRaZeile_Params par = new dbRaZeile_Params();
                            for (int i = 0; i < rd.FieldCount; i++)
                            {
                                bool match = false;
                                foreach (SqlParameter s in par.List)
                                    if (s.ParameterName.Substring(1).ToUpper() == rd.GetName(i).ToUpper())
                                    {
                                        if (!rd.IsDBNull(i))
                                            s.Value = rd.GetValue(i);
                                        else
                                            s.Value = DBNull.Value;
                                        match = true;
                                        break;
                                    }
                                if (!match)
                                {
                                    //
                                }
                            }
                            ret.Add(par);
                        }
                        rd.Close();
                    }
                }
            }
            catch
            {
            }
            finally
            {
                cnx.Close();
            }
        }
        return ret;
    }

    TableRow AddNewCell(TableRow r, string LabelText, string css, HorizontalAlign align)
    {
        TableCell c = new TableCell();
        //Label l = new Label();
        //l.Text = LabelText;
        //c.Controls.Add(l);
        c.Text = LabelText;
        c.CssClass = css;
        c.HorizontalAlign = align;
        if (r.Cells.Count < 2)
            c.Visible = false;
        r.Cells.Add(c);
        return r;
    }

    TableRow AddNewCell(TableRow r, string LabelText, string css, HorizontalAlign align, string tooltip)
    {
        TableCell c = new TableCell();
        //Label l = new Label();
        //l.Text = LabelText;
        //c.Controls.Add(l);
        c.Text = LabelText;
        c.CssClass = css;
        c.HorizontalAlign = align;
        c.ToolTip = tooltip;
        r.Cells.Add(c);
        return r;
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Session["ReiseZeile"] = null;
        Session["SetFocus"] = this.txtFocus2; //????
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        Session["SetFocus"] = this.txtFocus;
        dbRaZeile_Params rrr = (dbRaZeile_Params)Session["ReiseZeile"];
        TableRow row = null;
        int rowIndex = 0;
        bool istRR = false;
        foreach (TableRow r in TableRAZeilen.Rows)
        {
            rowIndex++;
            if (r.Cells[0].Text == rrr.RAID.Value.ToString() &&
                r.Cells[1].Text == rrr.LFDNR.Value.ToString())
            {
                row = r;
                break;
            }
        }
        if (row == null) return;

        if (rowIndex == TableRAZeilen.Rows.Count)
        {
            //es ist die letzte Zeile
            istRR = true;
        }
        rrr.ZEILENKZ.Value = rbtnEreignis.SelectedValue;

        DateTime abfahrt = ParamVal.Date0;
        DateTime ankunft = ParamVal.Date0;

        if (rbtnEreignis.SelectedValue == "T")
        {
            if (istRR)
            {
                rrr.AB.Value = rrr.AN.Value = abfahrt = ankunft = KGMonat.MaxDatum.AddSeconds(-KGMonat.MaxDatum.Second);
                rrr.DAT.Value = KGMonat.MaxDatum.Date;
                ReiseBis.Text = VonBis(abfahrt);
                rrr.ANORT.Value = rrr.ABORT.Value = this.txtAnOrt.Text = this.txtAbOrt.Text;
                rrr.ANID.Value = rrr.ABID.Value;
            }
            else
            {
                rrr.AB.Value = rrr.AN.Value = abfahrt = ankunft = KGMonat.MinDatum.AddMinutes(-1);
                rrr.DAT.Value = KGMonat.MinDatum;
                ReiseVon.Text = VonBis(abfahrt);
                rrr.ABORT.Value = rrr.ANORT.Value = this.txtAbOrt.Text = this.txtAnOrt.Text;
                rrr.ABID.Value = rrr.ANID.Value;
            }
        }
        else
        {
            TWTBStartDatum.TB.Text = RangeCheck.FixDate(TWTBStartDatum.TB.Text);
            TWTBEndeDatum.TB.Text = RangeCheck.FixDate(TWTBEndeDatum.TB.Text);
            ZeitVon.Text = RangeCheck.FixTime(ZeitVon.Text);
            ZeitBis.Text = RangeCheck.FixTime(ZeitBis.Text);
            if (!RangeCheck.IsDate(TWTBStartDatum.TB.Text) || !RangeCheck.IsTime(ZeitVon.Text))
            {
                LabelError.Text = "Datum/Zeit ungültig";
                LabelError.Visible = true;
                panelZeile.Visible = true;
                return;
            }
            if (!RangeCheck.IsDate(TWTBEndeDatum.TB.Text) || !RangeCheck.IsTime(ZeitBis.Text))
            {
                LabelError.Text = "Datum/Zeit ungültig";
                LabelError.Visible = true;
                panelZeile.Visible = true;
                return;
            }
            try
            {
                abfahrt = Convert.ToDateTime(TWTBStartDatum.TextBoxText + " " + ZeitVon.Text);
                ankunft = Convert.ToDateTime(TWTBEndeDatum.TextBoxText + " " + ZeitBis.Text);
                if (ankunft < abfahrt)
                {
                    LabelError.Text = "Geben Sie bitte eine Abfahrtszeit ein, die nicht später als die Ankunftszeit ist.";
                    LabelError.Visible = true;
                    panelZeile.Visible = true;
                    return;
                }
                row.Cells[2].Text = VonBis(abfahrt);
                row.Cells[3].Text = VonBis(ankunft);
                rrr.AB.Value = abfahrt;
                rrr.AN.Value = ankunft;
                rrr.DAT.Value = abfahrt.Date;
            }
            catch
            {
                LabelError.Text = "Geben Sie bitte eine Abfahrtszeit ein, die nicht später als die Ankunftszeit ist.";
                LabelError.Visible = true;
                panelZeile.Visible = true;
                return;
            }
        }

        if (abfahrt != ankunft && "WT".Contains(rbtnEreignis.SelectedValue))
        {
            LabelError.Text = "Abfahrt und Ankunft bei Wechsel Reiseart/Bereitstellung/Kontierung müssen identisch sein";
            LabelError.Visible = true;
            panelZeile.Visible = true;
            return;
        }

        if (this.txtAnOrt.Text != this.txtAbOrt.Text && "WT".Contains(rbtnEreignis.SelectedValue))
        {
            LabelError.Text = "Abfahrts- und Ankunftsort bei Wechsel Reiseart/Bereitstellung/Kontierung  und Teilabrechung müssen identisch sein";
            LabelError.Visible = true;
            panelZeile.Visible = true;
            return;
        }

        //km, MF & SG
        if ("WT".Contains(rbtnEreignis.SelectedValue))
        {
            //this.ddlMitfahrer.SelectedValue = "0";
            //this.txtGefKM.Text = "0";
            //this.cbSG.Checked = false;
            rrr.SCHWERGP.Value = "";
            rrr.GEFKM.Value = "0";
            rrr.MITFAHRER.Value = "0";
        }
        else
        {
            if (this.txtGefKM.Text != "")
            {
                int testKM = -1;
                try
                {
                    testKM = Convert.ToInt32(this.txtGefKM.Text);
                }
                catch
                {
                }
                if (testKM < 0 || testKM > 2000)
                {
                    LabelError.Text = "Bitte gefahrene KM zwischen 0 und 2000 erfasssen";
                    LabelError.Visible = true;
                    panelZeile.Visible = true;
                    return;
                }
                rrr.GEFKM.Value = testKM;
            }
            else
                this.txtGefKM.Text = "0";
            rrr.SCHWERGP.Value = this.cbSG.Checked ? "S" : "";
            rrr.MITFAHRER.Value = this.ddlMitfahrer.SelectedValue;
        }
        //Abort
        if (this.txtAbOrt.Text.Trim() == "" && "HRS".Contains(rbtnEreignis.SelectedValue))
        {
            LabelError.Text = "Bitte Abfahrtsort auswählen";
            LabelError.Visible = true;
            panelZeile.Visible = true;
            return;
        }
        else
            rrr.ABORT.Value = this.txtAbOrt.Text;

        //Anort
        if (this.txtAnOrt.Text.Trim() == "" && "HRS".Contains(rbtnEreignis.SelectedValue))
        {
            LabelError.Text = "Bitte Ankunftsort auswählen";
            LabelError.Visible = true;
            panelZeile.Visible = true;
            return;
        }
        else
            rrr.ANORT.Value = this.txtAnOrt.Text;

        //verkehrsmittel
        if (this.ddlFahrzeugart.SelectedValue == "" && "HRS".Contains(rbtnEreignis.SelectedValue))
        {
            LabelError.Text = "Bitte Fahrzeugart auswählen";
            LabelError.Visible = true;
            panelZeile.Visible = true;
            return;
        }
        else
            rrr.VERKEHRSMITTEL.Value = this.ddlFahrzeugart.SelectedValue;

        //Reisentätigkeit
        if (this.ddlTaetigkeit.SelectedValue == "" && "HSTW".Contains(rbtnEreignis.SelectedValue))
        {
            LabelError.Text = "Bitte Reisentätigkeit auswählen";
            LabelError.Visible = true;
            panelZeile.Visible = true;
            return;
        }
        else
            rrr.REISEART.Value = this.ddlTaetigkeit.SelectedValue;

        //Bereitstellung
        if (this.ddlBereitstellung.SelectedValue == "")// && "HSWT".Contains(rbtnEreignis.SelectedValue))
        {
            LabelError.Text = "Bitte die Bereitstellung auswählen";
            LabelError.Visible = true;
            panelZeile.Visible = true;
            return;
        }
        else
            rrr.BEREITST.Value = this.ddlBereitstellung.SelectedValue;

        //Auftragsnr
        rrr.BESCHREIB.Value = this.ddlAuftrag.SelectedValue;

        //mit anderen Reisezeilen
        foreach (TableRow r in TableRAZeilen.Rows)
        {
            if (r != row && r.Cells[0].CssClass != "TabHeader")
            {
                //abfahrt vom reisezele
                if (abfahrt < Convert.ToDateTime(r.Cells[2].Text))
                {
                    //ankunft muss ebenfalls vor reisezeile sein
                    //ansonst  -> Fehler
                    if (ankunft > Convert.ToDateTime(r.Cells[2].Text))
                    {
                        LabelError.Text = "Überschneidung mit anderen Reisenzeiten";
                        LabelError.Visible = true;
                        panelZeile.Visible = true;
                        return;
                    }
                }
                //abfahrt nach der reisezeile
                if (abfahrt >= Convert.ToDateTime(r.Cells[2].Text))
                {
                    // von muss grösser als bis sein
                    if (abfahrt < Convert.ToDateTime(r.Cells[3].Text))
                    {
                        LabelError.Text = "Überschneidung mit anderen Reisenzeiten";
                        LabelError.Visible = true;
                        panelZeile.Visible = true;
                        return;
                    }
                }
                //break;
            }
        }
        //Ist reise innerhhalb Reisenbeginn und Reiseende
        if ((abfahrt < Convert.ToDateTime(ReiseVon.Text)) ||
            (ankunft > Convert.ToDateTime(ReiseBis.Text)))
        {
            LabelError.Text = "Reisezeit ausserhalb der Reisenbereich (Von-Bis)";
            LabelError.Visible = true;
            panelZeile.Visible = true;
            return;
        }



        //mit der Arbitszeiten
        ArrayList ueberschneidungen = new ArrayList();
        if (abfahrt != ankunft)
        {
            if (ReadAZ((int)KGMonat.Monteur.Params.PERSKEY.Value, abfahrt, ankunft, ref ueberschneidungen))
            {
                if (ueberschneidungen.Count > 0)
                {
                    LabelError.Text = ueberschneidungen[ueberschneidungen.Count - 1].ToString();
                    LabelError.Visible = true;
                    panelZeile.Visible = true;
                    return;
                }
            }
            else
            {
                if (ueberschneidungen.Count > 0)
                    LabelError.Text = ueberschneidungen[ueberschneidungen.Count - 1].ToString();
                else
                    LabelError.Text = "Reisezeile könnte mit Arbeitszeiten nichts vergliechen werden, bitte versuchen sie es erneut";
                LabelError.Visible = true;
                panelZeile.Visible = true;
                return;
            }
        }

        int ebid = 0;
        try
        {
            ebid = Convert.ToInt32(ddlProjekt.SelectedValue);
        }
        catch
        {
        }

        if (ebid == 0)
        {
            LabelError.Text = "Bitte Projekt auswählen !!!";
            LabelError.Visible = true;
            panelZeile.Visible = true;
            return;
        }
        else
            rrr.EBID.Value = ebid;
        //reisenverlauf
        //mal sehen ob es notwendig ist
        string exception = "";
        if (UpdateReiseZeile(rrr, ref exception))
        {
            row.Cells[2].Text = VonBis(abfahrt);
            row.Cells[3].Text = VonBis(ankunft);
            switch (rrr.ZEILENKZ.Value.ToString())
            {
                case "H":
                    row.Cells[4].Text = "Hinreise";
                    break;
                case "R":
                    row.Cells[4].Text = "Rückreise";
                    break;
                case "T":
                    row.Cells[4].Text = "Teilabrechnung";
                    break;
                case "S":
                    row.Cells[4].Text = "Standortwechsel";
                    break;
                case "W":
                    row.Cells[4].Text = "Wechsel Reiseart/Bereitstellung/Kontierung";//BAF 530042 Text angepasst
                    break;
                default:
                    row.Cells[4].Text = rrr.ZEILENKZ.Value.ToString();
                    break;
            }
            row.Cells[5].Text = rrr.BESCHREIB.Value.ToString();
            row.Cells[6].Text = rrr.ANORT.Value.ToString();
            row.Cells[7].Text = this.ReiseTaetigkeit(rrr.REISEART.Value.ToString());
            row.Cells[8].Text = this.Verkersmittel(rrr.VERKEHRSMITTEL.Value.ToString());
            row.Cells[9].Text = this.Bereitstellungsarten(rrr.BEREITST.Value.ToString());
            row.Cells[10].Text = rrr.GEFKM.Value.ToString();
            row.Cells[11].Text = (rrr.MITFAHRER.Value != DBNull.Value) ? rrr.MITFAHRER.Value.ToString() : "0";
            row.Cells[12].Text = rrr.SCHWERGP.Value.ToString() == "S" ? "ja" : "nein";
        }
        else
        {
            this.LabelError.Text = "Änderung könnte nicht durchgeführt werden (RAZEILE), bitte noch einmal versuchen";
            if (exception.Length > 0)
                this.LabelError.Text += "\n\r EX: " + exception;
            this.LabelError.Visible = true;
            this.panelZeile.Visible = true;
            return;
        }


        if (UpdateRaKopf(this.TapNummer, dbRaKopf.RaStati.InArbeit))
            this.rastat = (short)dbRaKopf.RaStati.InArbeit;
        else
        {
            this.LabelError.Text = "Änderung könnte nicht durchgeführt werden (RAKOPF), bitte noch einmal versuchen";
            this.LabelError.Visible = true;
            this.panelZeile.Visible = true;
            return;
        }
        //jeztz auf richtige Stelle verschieben
        TableRAZeilen.Rows.Remove(row);
        int index = 0;
        foreach (TableRow r in TableRAZeilen.Rows)
        {
            if (r != row && r.Cells[0].CssClass != "TabHeader")
            {
                if (abfahrt < Convert.ToDateTime(r.Cells[2].Text))
                {
                    //TableRAZeilen.Rows.AddAt(index, row);
                    break;
                }
            }
            index++;
        }
        TableRAZeilen.Rows.AddAt(index, row);
        Session["SetFocus"] = this.txtFocus2;
        Session["ReiseZeile"] = null;
    }

    private bool ReadAZ(int p, DateTime abfahrt, DateTime ankunft, ref ArrayList azListe)
    {
        bool ret = false;
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                //passt nicht ... ab Montag weiter
                using (SqlCommand cmd = new SqlCommand("SELECT BEGINN, ENDE FROM ARBZEIT " + Config.Nolock +
                    "WHERE PERSKEY = @PERSKEY AND @VON < ENDE AND @BIS > BEGINN", cnx))
                {
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", p));
                    cmd.Parameters.Add(new SqlParameter("@VON", abfahrt));
                    cmd.Parameters.Add(new SqlParameter("@BIS", ankunft));
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        cmd.Parameters.Clear();
                        while (rd.Read())
                        {
                            //sollte es keine Überschneidungen geben, dann gibt es keine Datensätze
                            azListe.Add("Reisezeile überschneidet sich mit der Arbeitszeit von " + rd.GetDateTime(0).ToShortTimeString() +
                                " bis " + rd.GetDateTime(1).ToShortTimeString());
                            break;
                        }
                        rd.Close();
                        ret = true;
                    }
                }
            }
            catch (Exception e)
            {
                azListe.Add(e.Message);
                ret = false;
            }
            finally
            {
                cnx.Close();
            }
        }
        return ret;

    }

    private bool UpdateReiseZeile(dbRaZeile_Params rrr, ref string exception)
    {
        bool ret = false;
        dbRaZeile_Params rrneu = new dbRaZeile_Params();
        foreach (SqlParameter ss in rrr.List)
        {
            foreach (SqlParameter st in rrneu.List)
            {
                if (st.ParameterName == ss.ParameterName)
                {
                    st.Value = ss.Value;
                    break;
                }
            }
        }
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                using (SqlCommand cmd = new SqlCommand("update RAZEILE set ZNR=@ZNR,ZEILENKZ=@ZEILENKZ,VERKEHRSMITTEL=@VERKEHRSMITTEL, " +
                    "DAT=@DAT,AB=@AB,AN=@AN,LKZ=@LKZ,REISEART=@REISEART,BEREITST=@BEREITST,AUSLART=@AUSLART,ANZNAECHTE=@ANZNAECHTE," +
                    "BETRAG=@BETRAG,WAEHR=@WAEHR,AUSLBEMERK=@AUSLBEMERK,PROZ=@PROZ,BESCHREIB=@BESCHREIB,ZWECK=@ZWECK,ABORT=@ABORT," +
                    "ANORT=@ANORT,ABKM=@ABKM,GEFKM=@GEFKM,SCHWERGP=@SCHWERGP,MWST=@MWST,VERMBETRAG=@VERMBETRAG,VERMWAEHR=@VERMWAEHR," +
                    "VERMSONST=@VERMSONST,DATLA=@DATLA,AENPERSKEY=@AENPERSKEY,DATNEU=@DATNEU,INTF_ID=@INTF_ID,ABID=@ABID,ANID=@ANID," +
                    "EBID=@EBID, MITFAHRER=@MITFAHRER where RAID=@RAID and LFDNR=@LFDNR", cnx))
                {
                    foreach (SqlParameter s in rrneu.List)
                    {
                        if (s.ParameterName != "@RAKZTXT" && s.ParameterName != "@BSTXT")
                            cmd.Parameters.Add(s);
                    }
                    cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                    ret = true;
                }
            }
            catch (Exception ex)
            {
                exception = ex.Message;
            }
            finally
            {
                cnx.Close();
            }
        }
        return ret;
    }
    protected void btnSendTripToSAP_Click(object sender, EventArgs e)
    {
        Button b = (Button)sender;
        string raid = b.Attributes["RAID"];
        RueckgabeAnClient ret = SendTripToSAP(Convert.ToInt32(KGMonat.Monteur.Params.PERSKEY.Value), KGMonat.Monteur.Params.MANDANT.Value.ToString(), raid);

        if (ret.SapReisennummer.Trim('0').Length == 0)
        {
            //error
            lblSendTrip.Text = ret.SapReturn.Length > 0 ? ret.SapReturn : ret.TapReturn;
            lblSendTrip.ForeColor = System.Drawing.Color.Red;
        }
        else
        {
            //no error
            lblSendTrip.Text = ret.SapReturn.Length > 0 ? ret.SapReturn : ret.TapReturn;
            lblSendTrip.ForeColor = System.Drawing.Color.Green;
            labelSapNummer.Text = ret.SapReisennummer;
            if (UpdateRaKopf(this.TapNummer, dbRaKopf.RaStati.Freigegeben))
                this.rastat = (short)dbRaKopf.RaStati.Freigegeben;
        }
        Session["SetFocus"] = this.txtFocus2; // sender as Button;
    }

    public bool UpdateRaKopf(int p, dbRaKopf.RaStati raStati)
    {
        bool ret = false;
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                using (SqlCommand cmd = new SqlCommand("update RAKOPF " + Config.Rowlock + " set RASTAT = @RASTAT where RAID=@RAID", cnx))
                {
                    cmd.Parameters.Add(new SqlParameter("@RAID", p));
                    cmd.Parameters.Add(new SqlParameter("@RASTAT", raStati));
                    cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                    ret = true;
                }
            }
            catch
            {
                ret = false;
            }
            finally
            {
                cnx.Close();
            }
        }
        return ret;
    }

    public RueckgabeAnClient SendTripToSAP(int perskey, string Mandant, string raid)
    {
        RFCReise rfcReise = new RFCReise();
        return rfcReise.SendTripToSAP(perskey, Mandant, raid, false);
    }
    protected void btnSave2_Click(object sender, EventArgs e)
    {
        string exception = "";
        Session["SetFocus"] = this.txtFocus2;
        dbRaZeile_Params rrr = (dbRaZeile_Params)Session["ReiseZeile"];
        TableRow row = null;
        foreach (TableRow r in this.TableBelege.Rows)
        {
            if (r.Cells[0].Text == rrr.RAID.Value.ToString() &&
                r.Cells[1].Text == rrr.LFDNR.Value.ToString())
            {
                row = r;
                break;
            }
        }
        if (row == null) return;

        int ebid = 0;
        try
        {
            ebid = Convert.ToInt32(this.ddlProjekt2.SelectedValue);
        }
        catch
        {
        }

        if (ebid == 0)
        {
            this.LabelError2.Text = "Bitte Projekt auswählen !!!";
            this.LabelError2.Visible = true;
            this.panelBeleg.Visible = true;
            return;
        }
        else
            rrr.EBID.Value = ebid;

        rrr.BESCHREIB.Value = this.ddlAuftrag2.SelectedValue;

        rrr.AUSLBEMERK.Value = this.txtBemerkung.Text;

        if (rrr.AUSLART.Value.ToString() == "SONS" && rrr.AUSLBEMERK.Value.ToString() == "")
        {
            this.LabelError2.Text = "Bitte die Bemerkung ausfühlen (Grund für sonst. Auslage)";
            this.LabelError2.Visible = true;
            this.panelBeleg.Visible = true;
            return;
        }

        try
        {
            rrr.DAT.Value = Convert.ToDateTime(this.txtDatum.Text);
            DateTime reiseVon = Convert.ToDateTime(this.ReiseVon.Text).Date;
            DateTime reiseBis = Convert.ToDateTime(this.ReiseBis.Text);
            if (Convert.ToDateTime(this.txtDatum.Text) < reiseVon ||
                Convert.ToDateTime(this.txtDatum.Text) > reiseBis)
            {
                throw new Exception();
            }

        }
        catch
        {
            this.LabelError2.Text = "Datum ist nicht korrekt eingegeben";
            this.LabelError2.Visible = true;
            this.panelBeleg.Visible = true;
            return;
        }

        if (UpdateReiseZeile(rrr, ref exception))
        {
            row.Cells[3].Text = rrr.BESCHREIB.Value.ToString();
            row.Cells[2].Text = Convert.ToDateTime(rrr.DAT.Value).ToShortDateString();
        }
        else
        {
            this.LabelError2.Text = "Änderung könnte nicht durchgeführt werden (RAZEILE), bitte noch einmal versuchen";
            this.LabelError2.Visible = true;
            this.panelBeleg.Visible = true;
            return;
        }
        if (UpdateRaKopf(this.TapNummer, dbRaKopf.RaStati.InArbeit))
            this.rastat = (short)dbRaKopf.RaStati.InArbeit;
        else
        {
            this.LabelError2.Text = "Änderung könnte nicht durchgeführt werden (RAKOPF), bitte noch einmal versuchen";
            this.LabelError2.Visible = true;
            this.panelBeleg.Visible = true;
            return;
        }

        this.TableBelege.Rows.Remove(row);
        int index = 0;
        foreach (TableRow r in this.TableBelege.Rows)
        {
            if (r != row && r.Cells[0].CssClass != "TabHeader")
            {
                if (Convert.ToDateTime(this.txtDatum.Text) < Convert.ToDateTime(r.Cells[2].Text))
                {
                    //TableRAZeilen.Rows.AddAt(index, row);
                    break;
                }
            }
            index++;
        }
        this.TableBelege.Rows.AddAt(index, row);
        Session["ReiseZeile"] = null;
    }
    protected void rbtnEreignis_SelectedIndexChanged(object sender, EventArgs e)
    {
        dbRaZeile_Params rrr = (dbRaZeile_Params)Session["ReiseZeile"];
        if ("T".Contains(this.rbtnEreignis.SelectedValue))
        {
            this.TWTBStartDatum.Visible = false;
            this.TWTBEndeDatum.Visible = false;
            this.ZeitVon.Visible = false;
            this.ZeitBis.Visible = false;
            this.Label18.Visible = false;
            this.Label19.Visible = false;
        }
        else
        {
            this.TWTBStartDatum.Visible = true;
            this.TWTBEndeDatum.Visible = true;
            this.TWTBStartDatum.SelectedDate = this.TWTBStartDatum.TB.Text;
            this.TWTBEndeDatum.SelectedDate = this.TWTBEndeDatum.TB.Text;
            this.ZeitVon.Visible = true;
            this.ZeitBis.Visible = true;
            this.Label18.Visible = true;
            this.Label19.Visible = true;
        }
        if ("WT".Contains(this.rbtnEreignis.SelectedValue))
        {
            //km + sg
            this.Label8.Visible = false;
            this.Label9.Visible = false;
            this.txtGefKM.Visible = false;
            this.cbSG.Visible = false;
            this.ddlMitfahrer.Visible = false;
        }
        else
        {
            //km + sg
            this.Label8.Visible = true;
            this.Label9.Visible = true;
            this.txtGefKM.Visible = true;
            this.cbSG.Visible = true;
            this.ddlMitfahrer.Visible = true;
        }
        this.panelZeile.Visible = true;
        Session["SetFocus"] = this.txtFocus; //????*/
    }
    protected void btnCancel2_Click(object sender, EventArgs e)
    {
        Session["ReiseZeile"] = null;
        Session["SetFocus"] = this.txtFocus2; //????
    }
    protected void btnSimulation_Click(object sender, EventArgs e)
    {
        Session["SetFocus"] = this.txtFocus2; //????

        string filepath = "";
        RFCReise rfc = new RFCReise();
        RueckgabeAnClient rueck = new RueckgabeAnClient();

        try
        {
            rueck = rfc.GetSimulation(Convert.ToInt32(KGMonat.Monteur.Params.PERSKEY.Value),
                KGMonat.Monteur.Params.MANDANT.Value.ToString(),
                this.labelTapNummer.Text, out filepath);

            //filepath = @"D:\TAP\_PDF\SIMULATION\SIM.170022686.pdf";
            if (filepath.Length > 0)
            {
                Response.ContentType = "Application/pdf";
                //Response.WriteFile(filepath);

                string[] filename = filepath.Split('\\');
                Response.AddHeader("content-disposition", "attachment; filename=" + filename[filename.Length - 1]);
                FileStream sourceFile = new FileStream(filepath, FileMode.Open);
                long FileSize;
                FileSize = sourceFile.Length;
                byte[] getContent = new byte[(int)FileSize];
                sourceFile.Read(getContent, 0, (int)sourceFile.Length);
                sourceFile.Close();
                Response.BinaryWrite(getContent);
                //Response.End();
            }
            else
            {
                lblSendTrip.Text = rueck.SapReturn.Length > 0 ? rueck.SapReturn : rueck.TapReturn;
                lblSendTrip.ForeColor = System.Drawing.Color.Red;
            }
        }
        catch (Exception Ex)
        {
            lblSendTrip.Text = Ex.Message;
            lblSendTrip.ForeColor = System.Drawing.Color.Red;
        }
    }
    protected void btnBarcode_Click(object sender, EventArgs e)
    {
        Session["SetFocus"] = this.txtFocus2; //????

        string filepath = "";
        RFCReise rfc = new RFCReise();
        RueckgabeAnClient rueck = new RueckgabeAnClient();

        try
        {
            rueck = rfc.ForceBarCode(Convert.ToInt32(KGMonat.Monteur.Params.PERSKEY.Value),
                KGMonat.Monteur.Params.MANDANT.Value.ToString(),
                this.labelTapNummer.Text, out filepath);

            //filepath = @"D:\TAP\_PDF\SIMULATION\SIM.170022686.pdf";
            if (filepath.Length > 0)
            {
                Response.ContentType = "Application/pdf";
                //Response.WriteFile(filepath);

                string[] filename = filepath.Split('\\');
                Response.AddHeader("content-disposition", "attachment; filename=" + filename[filename.Length - 1]);
                FileStream sourceFile = new FileStream(filepath, FileMode.Open);
                long FileSize;
                FileSize = sourceFile.Length;
                byte[] getContent = new byte[(int)FileSize];
                sourceFile.Read(getContent, 0, (int)sourceFile.Length);
                sourceFile.Close();
                Response.BinaryWrite(getContent);
                //Response.End();
            }
            else
            {
                lblSendTrip.Text = rueck.SapReturn.Length > 0 ? rueck.SapReturn : rueck.TapReturn;
                lblSendTrip.ForeColor = System.Drawing.Color.Red;
            }
        }
        catch (Exception Ex)
        {
            lblSendTrip.Text = Ex.Message;
            lblSendTrip.ForeColor = System.Drawing.Color.Red;
        }

    }
}